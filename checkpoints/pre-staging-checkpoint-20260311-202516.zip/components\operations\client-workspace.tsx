"use client";

import Link from "next/link";
import { useState } from "react";
import { ArrowRight, CalendarCheck2, Heart, UserCircle2, WalletCards } from "lucide-react";
import { StatCard } from "@/components/dashboard/stat-card";
import { ClientEngagementPanel } from "@/components/engagement/client-engagement-panel";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FeedbackBanner } from "@/components/ui/feedback-banner";
import { Skeleton } from "@/components/ui/skeleton";
import { demoBarbers, demoClients, demoLocations, demoWaitlist } from "@/lib/data/demo";
import { useLiveOperationsSnapshot } from "@/lib/operations/live-client";
import { dateLabel } from "@/lib/utils";
import { getAppointmentViewModel } from "@/lib/utils/operations";

function actionCardClassName(highlight = false) {
  return [
    "group block rounded-[24px] border px-4 py-4 text-left text-sm transition",
    highlight
      ? "border-[#7CFF00]/24 bg-[linear-gradient(135deg,rgba(124,255,0,0.14),rgba(11,11,11,0.96))] text-white shadow-[0_18px_40px_rgba(124,255,0,0.08)]"
      : "border-white/8 bg-black/20 text-white/75 hover:border-[#7CFF00]/24 hover:bg-black/35 hover:text-white"
  ].join(" ");
}

function MetricSkeleton() {
  return (
    <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
      <Skeleton className="h-3 w-24" />
      <Skeleton className="mt-4 h-10 w-20" />
      <Skeleton className="mt-4 h-4 w-32" />
    </div>
  );
}

function AppointmentSkeleton() {
  return (
    <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-3">
          <Skeleton className="h-5 w-32" />
          <Skeleton className="h-4 w-44" />
        </div>
        <Skeleton className="h-8 w-32 rounded-full" />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Skeleton className="h-10 w-28 rounded-full" />
        <Skeleton className="h-10 w-24 rounded-full" />
      </div>
    </div>
  );
}

export function ClientWorkspace({ clientId, locationIds }: { clientId: string; locationIds: string[] }) {
  const operationsQuery = useLiveOperationsSnapshot("client");
  const [statusUpdate, setStatusUpdate] = useState<{ tone: "success" | "info" | "error"; message: string } | null>(null);

  const client = demoClients.find((entry) => entry.id === clientId) ?? demoClients[0];
  const appointments = [...(operationsQuery.data?.appointments ?? [])]
    .filter((appointment) => appointment.clientId === client.id)
    .sort((left, right) => new Date(left.start).getTime() - new Date(right.start).getTime());
  const upcomingAppointments = appointments.filter((appointment) => appointment.status === "booked" || appointment.status === "checked_in" || appointment.status === "in_service");
  const pastAppointments = appointments.filter((appointment) => appointment.status === "completed" || appointment.status === "cancelled" || appointment.status === "no_show");
  const favoriteBarber = demoBarbers.find((entry) => entry.id === client.favoriteBarberId);
  const favoriteLocations = Array.from(new Set([...(favoriteBarber?.locationIds ?? []), ...locationIds]))
    .map((locationId) => demoLocations.find((entry) => entry.id === locationId))
    .filter((location): location is NonNullable<typeof location> => Boolean(location));
  const waitlistEntries = demoWaitlist.filter((entry) => entry.clientId === client.id);
  const upcomingView = upcomingAppointments[0] ? getAppointmentViewModel(upcomingAppointments[0], operationsQuery.data?.clients ?? []) : undefined;
  const modeLabel = operationsQuery.data?.mode === "supabase" ? "Supabase realtime active" : "Quick-start demo state";
  const isInitialLoading = operationsQuery.isLoading && !operationsQuery.data;

  function handleAppointmentAction(action: "reschedule" | "cancel" | "rebook") {
    const messages = {
      reschedule: "Reschedule is ready from here. Open booking to choose a new time without leaving your client workspace.",
      cancel: "Cancellation request captured in this MVP view. Policy-aware cancellation sync is the next production step.",
      rebook: "Rebooking shortcut ready. Tap Book now to lock in your next visit in seconds."
    };

    setStatusUpdate({ tone: action === "rebook" ? "success" : "info", message: messages[action] });
  }

  return (
    <div className="space-y-4" data-testid="client-workspace">
      <section className="grid gap-4 xl:grid-cols-[1.08fr_0.92fr]">
        <Card className="rounded-[32px] p-6">
          <div className="rounded-[28px] border border-[#7CFF00]/16 bg-[linear-gradient(180deg,rgba(124,255,0,0.12),rgba(124,255,0,0.03))] p-6">
            <p className="surface-label text-[#d7ffab]">{modeLabel}</p>
            <h3 className="mt-3 text-4xl font-semibold sm:text-5xl" data-display="true">Book now</h3>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-white/68">
              Keep your grooming routine locked in with a client-only experience built for fast booking, simple updates, and effortless rebooking.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/booking/new" className="inline-flex items-center gap-2 rounded-full border border-[#cfff93]/40 bg-[linear-gradient(135deg,#7cff00_0%,#b7ff58_100%)] px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-black shadow-[0_14px_34px_rgba(124,255,0,0.24)] transition hover:translate-y-[-1px] hover:shadow-[0_18px_38px_rgba(124,255,0,0.28)]">
                Book now
                <ArrowRight className="h-4 w-4" />
              </Link>
              <span className="status-pill text-white/72">Client-only dashboard</span>
            </div>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              <Link href="/booking/new?mode=specific" className={actionCardClassName(true)}>
                <p className="font-medium uppercase tracking-[0.18em] text-[#cfff93]">Book specific barber</p>
                <p className="mt-2 text-sm text-white/64">Pick your go-to barber and lock in a precise slot.</p>
              </Link>
              <Link href="/booking/new?mode=next-available" className={actionCardClassName()}>
                <p className="font-medium uppercase tracking-[0.18em] text-[#cfff93]">Book next available</p>
                <p className="mt-2 text-sm text-white/64">Grab the fastest open chair without extra steps.</p>
              </Link>
              <Link href="/booking/new?schedule=1" className={actionCardClassName()}>
                <p className="font-medium uppercase tracking-[0.18em] text-[#cfff93]">Schedule appointment</p>
                <p className="mt-2 text-sm text-white/64">Choose your date, service, and timing with full control.</p>
              </Link>
              <Link href="/booking/new?waitlist=1" className={actionCardClassName()}>
                <p className="font-medium uppercase tracking-[0.18em] text-[#cfff93]">Join waitlist</p>
                <p className="mt-2 text-sm text-white/64">Raise your hand for open slots when they appear.</p>
              </Link>
            </div>
            <div className="mt-5 space-y-3">
              {statusUpdate ? <FeedbackBanner tone={statusUpdate.tone} message={statusUpdate.message} /> : null}
              <Link href="/discover" className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/20 px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-white/78 transition hover:border-[#7CFF00]/20 hover:text-[#d7ffab]">
                Explore barbers
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="surface-label">My appointments</p>
              <p className="mt-2 text-sm text-white/58">See what is coming up, make changes, and rebook without touching any internal shop tools.</p>
            </div>
            <CalendarCheck2 className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 rounded-[24px] border border-white/8 bg-black/20 p-4">
            <p className="surface-label">Next up</p>
            {isInitialLoading ? (
              <div className="mt-3 space-y-3">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-4 w-52" />
                <Skeleton className="h-4 w-48" />
              </div>
            ) : upcomingView ? (
              <>
                <p className="mt-3 text-lg font-semibold">{upcomingView.service?.name}</p>
                <p className="mt-1 text-sm text-white/55">{upcomingView.barber?.name} | {dateLabel(upcomingView.appointment.start)}</p>
                <p className="mt-3 text-sm text-white/68">You are all set. If plans change, reschedule or cancel from the list below.</p>
              </>
            ) : (
              <p className="mt-3 text-sm leading-7 text-white/58">No upcoming appointment on the books. Use the booking shortcuts to grab your next visit fast.</p>
            )}
          </div>
          <div className="mt-4 space-y-4">
            <div>
              <p className="text-sm text-white/50">Upcoming</p>
              <div className="mt-3 space-y-3">
                {isInitialLoading ? (
                  <>
                    <AppointmentSkeleton />
                    <AppointmentSkeleton />
                  </>
                ) : upcomingAppointments.length ? upcomingAppointments.map((appointment) => {
                  const view = getAppointmentViewModel(appointment, operationsQuery.data?.clients ?? []);
                  return (
                    <div key={appointment.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:-translate-y-0.5 hover:border-[#7CFF00]/16 hover:bg-black/30">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <p className="font-medium">{view.service?.name}</p>
                          <p className="mt-1 text-sm text-white/55">{view.barber?.name} | {dateLabel(appointment.start)}</p>
                        </div>
                        <StatusBadge appointment={appointment} />
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button type="button" variant="secondary" className="h-10 rounded-full px-4 text-[11px] uppercase tracking-[0.22em]" onClick={() => handleAppointmentAction("reschedule")}>
                          Reschedule
                        </Button>
                        <Button type="button" variant="secondary" className="h-10 rounded-full px-4 text-[11px] uppercase tracking-[0.22em] text-rose-100 hover:border-rose-300/20 hover:text-white" onClick={() => handleAppointmentAction("cancel")}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  );
                }) : (
                  <div className="empty-state-panel rounded-[24px] p-5 text-sm text-white/55">
                    Upcoming bookings will appear here once you lock in your next visit.
                  </div>
                )}
              </div>
            </div>
            <div>
              <p className="text-sm text-white/50">Past</p>
              <div className="mt-3 space-y-3">
                {isInitialLoading ? (
                  <>
                    <AppointmentSkeleton />
                    <AppointmentSkeleton />
                  </>
                ) : pastAppointments.length ? pastAppointments.slice(-3).reverse().map((appointment) => {
                  const view = getAppointmentViewModel(appointment, operationsQuery.data?.clients ?? []);
                  return (
                    <div key={appointment.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:-translate-y-0.5 hover:border-[#7CFF00]/16 hover:bg-black/30">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <p className="font-medium">{view.service?.name}</p>
                          <p className="mt-1 text-sm text-white/55">{view.barber?.name} | {dateLabel(appointment.start)}</p>
                        </div>
                        <StatusBadge appointment={appointment} />
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button type="button" variant="secondary" className="h-10 rounded-full px-4 text-[11px] uppercase tracking-[0.22em]" onClick={() => handleAppointmentAction("rebook")}>
                          Rebook
                        </Button>
                      </div>
                    </div>
                  );
                }) : (
                  <div className="empty-state-panel rounded-[24px] p-5 text-sm text-white/55">
                    Past visits and rebooking shortcuts will build up here over time.
                  </div>
                )}
              </div>
            </div>
          </div>
        </Card>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {isInitialLoading ? (
          <>
            <MetricSkeleton />
            <MetricSkeleton />
            <MetricSkeleton />
            <MetricSkeleton />
          </>
        ) : (
          <>
            <StatCard label="Upcoming visits" value={String(upcomingAppointments.length)} detail="Stay ahead of your next chair time" />
            <StatCard label="Past visits" value={String(pastAppointments.length)} detail="Rebooking stays close whenever you need it" />
            <StatCard label="Loyalty points" value={String(client.loyaltyPoints)} detail="Rewards and membership layers are scaffolded for growth" />
            <StatCard label="Waitlist entries" value={String(waitlistEntries.length)} detail="Open-slot opportunities stay visible here" />
          </>
        )}
      </section>

      <ClientEngagementPanel />

      <section className="grid gap-4 xl:grid-cols-3">
        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Favorites</p>
            <Heart className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 space-y-3">
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
              <p className="font-medium">Saved barber</p>
              <p className="mt-2 text-sm text-white/55">{favoriteBarber?.name ?? "No favorite barber yet"}</p>
            </div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
              <p className="font-medium">Favorite shops</p>
              <div className="mt-2 space-y-2 text-sm text-white/55">
                {favoriteLocations.length ? favoriteLocations.map((location) => (
                  <p key={location.id}>{location.name}</p>
                )) : <p>Set during booking</p>}
              </div>
            </div>
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Account basics</p>
            <UserCircle2 className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 space-y-3 text-sm text-white/72">
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Profile: {client.name}</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Phone: {client.phone}</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Email: {client.email}</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Notifications: SMS reminders preferred</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Preferred location: {favoriteLocations[0]?.name ?? "Set during booking"}</div>
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Future-ready extras</p>
            <WalletCards className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 space-y-3 text-sm text-white/72">
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Loyalty rewards placeholder</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Saved styles placeholder</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Membership placeholder</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">Referral credits placeholder</div>
            <div className="rounded-[24px] border border-dashed border-white/10 bg-black/15 p-4 text-white/58">
              Growth features stay visible without adding internal shop clutter to the client view.
            </div>
          </div>
        </Card>
      </section>
    </div>
  );
}