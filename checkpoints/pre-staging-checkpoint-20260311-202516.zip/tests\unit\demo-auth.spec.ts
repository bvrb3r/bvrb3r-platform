import { findDemoUserByEmail, getDefaultRouteForUser, resolveDemoUser } from "@/lib/auth/demo-auth";

describe("demo account mapping", () => {
  it.each([
    ["owner@bvrb3r.demo", "owner", "/dashboard/owner"],
    ["manager@bvrb3r.demo", "manager", "/dashboard/manager"],
    ["frontdesk@bvrb3r.demo", "front_desk", "/dashboard/front-desk"],
    ["wave@bvrb3r.demo", "commission_barber", "/dashboard/barber"],
    ["blaze@bvrb3r.demo", "booth_rent_barber", "/dashboard/barber"],
    ["client@bvrb3r.demo", "client", "/dashboard/client"]
  ])("maps %s to %s and %s", (email, role, route) => {
    const user = findDemoUserByEmail(email);

    expect(user?.email).toBe(email);
    expect(user?.role).toBe(role);
    expect(user ? getDefaultRouteForUser(user) : null).toBe(route);
  });

  it("resolves url-encoded demo emails", () => {
    const user = findDemoUserByEmail("manager%40bvrb3r.demo");

    expect(user?.email).toBe("manager@bvrb3r.demo");
    expect(user?.role).toBe("manager");
  });

  it("prefers the selected demo account over the fallback email", () => {
    const user = resolveDemoUser("wave@bvrb3r.demo", "owner@bvrb3r.demo");

    expect(user.email).toBe("wave@bvrb3r.demo");
    expect(user.role).toBe("commission_barber");
    expect(user.name).toBe("Wave Carter");
  });
});