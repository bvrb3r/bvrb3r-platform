import Link from "next/link";
import { SignalZero, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function OfflinePage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl items-center px-4 py-10 sm:px-6">
      <Card className="w-full rounded-[36px] p-6 sm:p-10">
        <div className="mx-auto flex max-w-2xl flex-col items-start gap-5">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#7CFF00]/18 bg-[#7CFF00]/10 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-[#d7ffab]">
            <SignalZero className="h-4 w-4" />
            Offline-safe mode
          </div>
          <div>
            <h1 className="text-4xl font-semibold sm:text-5xl" data-display="true">Connection lost. The app shell is still here.</h1>
            <p className="mt-4 max-w-xl text-sm leading-7 text-white/68">
              You can keep browsing cached BVRB3R screens, but live booking, check-in, checkout, and realtime marketplace updates need a connection before they can safely continue.
            </p>
          </div>
          <div className="grid w-full gap-3 sm:grid-cols-2">
            <div className="rounded-[26px] border border-white/8 bg-black/20 p-5">
              <p className="surface-label">Still available</p>
              <p className="mt-3 text-sm leading-7 text-white/66">Shell navigation, branded UI, and any previously cached read views.</p>
            </div>
            <div className="rounded-[26px] border border-white/8 bg-black/20 p-5">
              <p className="surface-label">Needs connection</p>
              <p className="mt-3 text-sm leading-7 text-white/66">Operational writes, booking creation, checkout capture, follow actions, and live discovery refreshes.</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <Link href="/">
              <Button className="h-12 px-6">
                <Sparkles className="h-4 w-4" />
                Return home
              </Button>
            </Link>
            <Link
              href="/discover"
              className="inline-flex h-12 items-center gap-2 rounded-full border border-white/10 bg-black/25 px-5 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition hover:border-[#7CFF00]/24 hover:text-[#d7ffab]"
            >
              Keep browsing
            </Link>
          </div>
        </div>
      </Card>
    </main>
  );
}
