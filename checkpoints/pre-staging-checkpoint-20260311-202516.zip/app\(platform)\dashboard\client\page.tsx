import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { ClientWorkspace } from "@/components/operations/client-workspace";
import { getAuthorizedUser } from "@/lib/auth/guards";

export default async function ClientDashboardPage() {
  const user = await getAuthorizedUser(["client"]);

  return (
    <DashboardShell
      user={user}
      activeHref="/dashboard/client"
      title="Book fast, stay informed"
      subtitle="Handle appointments, waitlist options, favorites, and rebooking from one clean client-only experience with no internal shop noise."
    >
      <ClientWorkspace clientId={user.clientId ?? ""} locationIds={user.locationIds} />
    </DashboardShell>
  );
}