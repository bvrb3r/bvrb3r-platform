"use client";

import { useState } from "react";
import { Gift, Link2, MailPlus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FeedbackBanner } from "@/components/ui/feedback-banner";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useClientReferralSummary, useCreateReferralInviteMutation, type EngagementApiError } from "@/lib/engagement/client";
import { useMarketplaceAnalyticsMutation, type MarketplaceApiError } from "@/lib/marketplace/client";
import { getReadableActionError } from "@/lib/utils/feedback";

function ReferralSkeleton() {
  return (
    <div className="space-y-4">
      <Card className="rounded-[32px] p-6"><Skeleton className="h-48 w-full rounded-[24px]" /></Card>
      <div className="grid gap-4 xl:grid-cols-3">
        <Card className="rounded-[32px] p-6"><Skeleton className="h-40 w-full rounded-[24px]" /></Card>
        <Card className="rounded-[32px] p-6 xl:col-span-2"><Skeleton className="h-40 w-full rounded-[24px]" /></Card>
      </div>
    </div>
  );
}

export function ReferralsWorkspace() {
  const summaryQuery = useClientReferralSummary();
  const inviteMutation = useCreateReferralInviteMutation();
  const analyticsMutation = useMarketplaceAnalyticsMutation();
  const [email, setEmail] = useState("");
  const [feedback, setFeedback] = useState<{ tone: "success" | "info" | "error"; message: string } | null>(null);

  async function handleShareLink() {
    if (!summaryQuery.data) {
      return;
    }

    setFeedback(null);
    try {
      if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
        await navigator.share({
          title: "Join BVRB3R Marketplace",
          text: summaryQuery.data.shareMessage,
          url: summaryQuery.data.inviteLink
        });
      } else if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(summaryQuery.data.inviteLink);
      }

      await analyticsMutation.mutateAsync({
        eventType: "referral_shared",
        sourceKind: "client_dashboard",
        sourceReference: summaryQuery.data.referralCode?.code,
        metadata: { channel: typeof navigator !== "undefined" && typeof navigator.share === "function" ? "native_share" : "copy_link" }
      });
      setFeedback({ tone: "success", message: "Referral link is ready to share. Growth analytics captured the action." });
    } catch (error) {
      setFeedback({ tone: "error", message: getReadableActionError(error as MarketplaceApiError) });
    }
  }

  async function handleInvite() {
    if (!email.trim()) {
      setFeedback({ tone: "error", message: "Enter an email address to send a referral invite." });
      return;
    }

    setFeedback(null);
    try {
      await inviteMutation.mutateAsync({ referredClientEmail: email.trim() });
      setEmail("");
      setFeedback({ tone: "success", message: "Referral invite logged. Reward points unlock when the first marketplace booking closes." });
    } catch (error) {
      setFeedback({ tone: "error", message: getReadableActionError(error as EngagementApiError) });
    }
  }

  if (summaryQuery.isLoading && !summaryQuery.data) {
    return <ReferralSkeleton />;
  }

  if (summaryQuery.isError || !summaryQuery.data) {
    return (
      <Card className="rounded-[32px] p-6">
        <FeedbackBanner tone="error" message="Something went wrong while loading referrals. Please try again." />
      </Card>
    );
  }

  const summary = summaryQuery.data;

  return (
    <div className="space-y-4" data-testid="referrals-workspace">
      <Card className="rounded-[32px] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="surface-label text-[#d7ffab]">Client growth loop</p>
            <h3 className="mt-3 text-4xl font-semibold sm:text-5xl" data-display="true">Invite the next client into BVRB3R</h3>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-white/64">
              Referrals turn satisfied clients into a natural growth engine. Share your code, track invite progress, and earn points as new bookings close through the network.
            </p>
          </div>
          <div className="rounded-[24px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4 text-sm text-white/68">
            <p className="surface-label text-[#d7ffab]">Referral code</p>
            <p className="mt-3 text-2xl font-semibold" data-display="true">{summary.referralCode?.code ?? "BVRB3R"}</p>
            <p className="mt-2 text-white/58">Worth {summary.referralCode?.rewardPoints ?? 0} points when the invited guest converts.</p>
          </div>
        </div>

        <div className="mt-5 space-y-3">
          {feedback ? <FeedbackBanner tone={feedback.tone} message={feedback.message} /> : null}
        </div>

        <div className="mt-6 grid gap-3 md:grid-cols-2 xl:grid-cols-[1.05fr_0.95fr]">
          <div className="rounded-[24px] border border-white/8 bg-black/20 p-5">
            <p className="surface-label">Share your invite link</p>
            <p className="mt-3 text-sm leading-7 text-white/62">{summary.shareMessage}</p>
            <div className="mt-4 rounded-[20px] border border-white/8 bg-black/25 px-4 py-4 text-sm text-white/72">{summary.inviteLink}</div>
            <div className="mt-4 flex flex-wrap gap-3">
              <Button type="button" className="h-11 rounded-full px-5" onClick={() => void handleShareLink()} disabled={analyticsMutation.isPending}>
                <Link2 className="h-4 w-4" />
                {analyticsMutation.isPending ? "Sharing..." : "Share link"}
              </Button>
            </div>
          </div>
          <div className="rounded-[24px] border border-white/8 bg-black/20 p-5">
            <p className="surface-label">Send a direct invite</p>
            <p className="mt-3 text-sm leading-7 text-white/62">Log a referral invite by email so the reward path is visible before automated campaigns arrive.</p>
            <div className="mt-4 flex flex-col gap-3 sm:flex-row">
              <Input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="friend@example.com" className="sm:flex-1" />
              <Button type="button" variant="secondary" className="h-11 rounded-full px-5" onClick={() => void handleInvite()} disabled={inviteMutation.isPending}>
                <MailPlus className="h-4 w-4" />
                {inviteMutation.isPending ? "Sending..." : "Send invite"}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <section className="grid gap-4 xl:grid-cols-3">
        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Invite pipeline</p>
            <Users className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 grid gap-3">
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Invited</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{summary.totals.invited}</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Completed</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{summary.totals.completed}</p>
            </div>
            <div className="rounded-[22px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4">
              <p className="surface-label text-[#d7ffab]">Credited</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{summary.totals.credited}</p>
            </div>
          </div>
        </Card>

        <Card className="rounded-[32px] p-6 xl:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Referral rewards and activity</p>
            <Gift className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Reward points earned</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{summary.totals.rewardPointsEarned}</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Share-ready code</p>
              <p className="mt-3 text-2xl font-semibold">{summary.referralCode?.code ?? "BVRB3R"}</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4 md:col-span-2">
              <p className="surface-label">Why it matters</p>
              <p className="mt-3 text-sm leading-7 text-white/62">Referrals become one of the marketplace loops that lift repeat usage, loyalty participation, and future ranking confidence.</p>
            </div>
          </div>
          <div className="mt-4 space-y-3">
            {summary.recentReferrals.length ? summary.recentReferrals.map((referral) => (
              <div key={referral.id} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="font-medium">{referral.referredClientEmail}</p>
                  <span className="status-pill text-[#d7ffab]">{referral.status}</span>
                </div>
                <p className="mt-2 text-sm text-white/60">Reward value {referral.rewardPoints} points</p>
              </div>
            )) : (
              <div className="empty-state-panel rounded-[22px] p-5 text-sm text-white/58">Referral activity will appear here as you invite more clients into the marketplace.</div>
            )}
          </div>
        </Card>
      </section>
    </div>
  );
}
