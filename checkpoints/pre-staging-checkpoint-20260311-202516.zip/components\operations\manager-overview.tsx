"use client";

import { ClipboardCheck, PackageSearch, ShieldCheck, TriangleAlert, UsersRound } from "lucide-react";
import { StatCard } from "@/components/dashboard/stat-card";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { demoBarbers, demoLocations, demoTasks, inventoryItems } from "@/lib/data/demo";
import { useLiveOperationsSnapshot } from "@/lib/operations/live-client";
import { getManagerOperationsSummary } from "@/lib/operations/metrics";
import { currency, dateLabel } from "@/lib/utils";
import { getAppointmentViewModel } from "@/lib/utils/operations";

function MetricSkeleton() {
  return (
    <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
      <Skeleton className="h-3 w-24" />
      <Skeleton className="mt-4 h-10 w-20" />
      <Skeleton className="mt-4 h-4 w-36" />
    </div>
  );
}

function BoardRowSkeleton() {
  return (
    <div className="rounded-[26px] border border-white/8 bg-black/20 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="space-y-3">
          <Skeleton className="h-6 w-40" />
          <Skeleton className="h-4 w-52" />
        </div>
        <Skeleton className="h-8 w-32 rounded-full" />
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <Skeleton className="h-12 w-full rounded-[20px]" />
        <Skeleton className="h-12 w-full rounded-[20px]" />
        <Skeleton className="h-12 w-full rounded-[20px]" />
      </div>
    </div>
  );
}

function UtilityCardSkeleton() {
  return (
    <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="space-y-3">
          <Skeleton className="h-4 w-28" />
          <Skeleton className="h-5 w-36" />
        </div>
        <Skeleton className="h-8 w-28 rounded-full" />
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <Skeleton className="h-20 w-full rounded-[20px]" />
        <Skeleton className="h-20 w-full rounded-[20px]" />
        <Skeleton className="h-20 w-full rounded-[20px]" />
      </div>
    </div>
  );
}

export function ManagerOverview({ locationIds }: { locationIds: string[] }) {
  const operationsQuery = useLiveOperationsSnapshot("manager");
  const appointments = [...(operationsQuery.data?.appointments ?? [])]
    .filter((appointment) => locationIds.length === 0 || locationIds.includes(appointment.locationId))
    .sort((left, right) => new Date(left.start).getTime() - new Date(right.start).getTime());
  const ownerAnalytics = operationsQuery.data?.ownerAnalytics ?? [];
  const walkIns = (operationsQuery.data?.walkIns ?? []).filter((entry) => locationIds.length === 0 || locationIds.includes(entry.locationId));
  const workflowEvents = operationsQuery.data?.workflowEvents ?? [];
  const summary = getManagerOperationsSummary(appointments, ownerAnalytics, walkIns);
  const modeLabel = operationsQuery.data?.mode === "supabase" ? "Supabase realtime active" : "Quick-start demo state";
  const activeLocations = demoLocations.filter((location) => locationIds.includes(location.id));
  const dayAppointments = appointments.filter((appointment) => appointment.start.slice(0, 10) === summary.latestDate);
  const noShowCount = dayAppointments.filter((appointment) => appointment.status === "no_show").length;
  const lateWatchCount = dayAppointments.filter((appointment) => appointment.note.toLowerCase().includes("late")).length;
  const completedCount = dayAppointments.filter((appointment) => appointment.status === "completed").length;
  const activeBarbers = demoBarbers.filter((barber) => barber.locationIds.some((locationId) => locationIds.includes(locationId)));
  const floorBarbers = activeBarbers
    .map((barber) => {
      const barberAppointments = dayAppointments.filter((appointment) => appointment.barberId === barber.id);
      const liveCount = barberAppointments.filter((appointment) => appointment.status === "checked_in" || appointment.status === "in_service").length;
      const bookedCount = barberAppointments.filter((appointment) => appointment.status === "booked").length;
      const completed = barberAppointments.filter((appointment) => appointment.status === "completed").length;
      const utilization = barberAppointments.length ? Math.round(((liveCount + completed) / barberAppointments.length) * 100) : 0;

      return {
        barber,
        liveCount,
        bookedCount,
        completed,
        utilization,
        nextAppointment: barberAppointments[0]
      };
    })
    .sort((left, right) => right.liveCount - left.liveCount || right.completed - left.completed);
  const availableBarbers = floorBarbers.filter((entry) => entry.liveCount === 0);
  const frontDeskEvents = workflowEvents.filter((event) => event.actorRole === "front_desk").slice(0, 4);
  const operationalTasks = demoTasks.filter((task) => locationIds.includes(task.locationId));
  const relevantInventory = inventoryItems.filter((item) => locationIds.includes(item.locationId));
  const inventoryAlerts = relevantInventory.filter((item) => item.stock <= item.reorderAt);
  const isInitialLoading = operationsQuery.isLoading && !operationsQuery.data;

  return (
    <div className="space-y-4" data-testid="manager-overview">
      <section className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="surface-label">Shop command center</p>
              <h3 className="mt-3 text-4xl font-semibold sm:text-5xl" data-display="true">Run the floor with confidence</h3>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-white/62">
                You can see every chair, every queue handoff, and every operational signal needed to keep the shop moving, while owner-only policy and billing controls stay protected.
              </p>
            </div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 text-sm text-white/68">
              <div className="inline-flex items-center gap-2 rounded-full border border-[#7CFF00]/20 bg-[#7CFF00]/10 px-3 py-2 text-[10px] uppercase tracking-[0.22em] text-[#d7ffab]">
                <ShieldCheck className="h-4 w-4" />
                {modeLabel}
              </div>
              <p className="mt-4 text-[11px] uppercase tracking-[0.22em] text-white/42">
                Coverage {activeLocations.map((location) => location.name).join(" | ") || "Assigned location"}
              </p>
            </div>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {isInitialLoading ? (
              <>
                <MetricSkeleton />
                <MetricSkeleton />
                <MetricSkeleton />
              </>
            ) : (
              <>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <p className="surface-label">Needs attention now</p>
                  <p className="mt-3 text-3xl font-semibold" data-display="true">{summary.readyForCheckoutCount + walkIns.length + lateWatchCount}</p>
                  <p className="mt-2 text-sm text-white/58">Checkout waits, walk-ins, and late arrivals are the next floor actions.</p>
                </div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <p className="surface-label">Route walk-ins to</p>
                  <p className="mt-3 text-lg font-semibold">{availableBarbers.map((entry) => entry.barber.name).join(", ") || "All chairs occupied"}</p>
                  <p className="mt-2 text-sm text-white/58">Available chairs update from live status changes and schedule flow.</p>
                </div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <p className="surface-label">Front desk pulse</p>
                  <p className="mt-3 text-3xl font-semibold" data-display="true">{frontDeskEvents.length}</p>
                  <p className="mt-2 text-sm text-white/58">Recent desk actions are mirrored here so the floor stays aligned.</p>
                </div>
              </>
            )}
          </div>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-1">
          {isInitialLoading ? (
            <>
              <MetricSkeleton />
              <MetricSkeleton />
              <MetricSkeleton />
            </>
          ) : (
            <>
              <StatCard label="Appointments today" value={String(dayAppointments.length)} detail={`${summary.checkedInCount} checked in and ${summary.inServiceCount} in service right now`} />
              <StatCard label="Barbers on shift" value={String(activeBarbers.length)} detail={`${floorBarbers.filter((entry) => entry.liveCount > 0).length} chairs currently active on the floor`} />
              <StatCard label="Revenue pulse" value={currency(summary.revenueToday)} detail={`${summary.readyForCheckoutCount} tickets still waiting on checkout capture`} />
            </>
          )}
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="surface-label">Full shop schedule</p>
              <p className="mt-2 text-sm text-white/58">Scan booked, checked-in, in-service, and completed tickets without leaving the floor view.</p>
            </div>
            <span className="status-pill text-[#d7ffab]">{completedCount} completed today</span>
          </div>
          <div className="mt-4 space-y-3">
            {isInitialLoading ? (
              <>
                <BoardRowSkeleton />
                <BoardRowSkeleton />
                <BoardRowSkeleton />
              </>
            ) : dayAppointments.length ? dayAppointments.slice(0, 8).map((appointment) => {
              const view = getAppointmentViewModel(appointment, operationsQuery.data?.clients ?? []);
              return (
                <div key={appointment.id} className="rounded-[26px] border border-white/8 bg-black/20 p-4 transition hover:-translate-y-0.5 hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-lg font-semibold">{view.client?.name ?? appointment.clientId}</p>
                      <p className="mt-1 text-sm text-white/52">{view.barber?.name ?? appointment.barberId} | {view.service?.name}</p>
                    </div>
                    <StatusBadge appointment={appointment} />
                  </div>
                  <div className="mt-4 grid gap-3 text-sm text-white/62 sm:grid-cols-3">
                    <div className="rounded-[20px] border border-white/8 bg-black/25 px-3 py-3">{dateLabel(appointment.start)}</div>
                    <div className="rounded-[20px] border border-white/8 bg-black/25 px-3 py-3">{appointment.chair}</div>
                    <div className="rounded-[20px] border border-white/8 bg-black/25 px-3 py-3">{appointment.note}</div>
                  </div>
                </div>
              );
            }) : (
              <div className="empty-state-panel rounded-[26px] p-6 text-sm leading-7 text-white/58">
                The floor schedule will populate here once appointments are assigned to this shop.
              </div>
            )}
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Barber utilization</p>
            <UsersRound className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 space-y-3">
            {isInitialLoading ? (
              <>
                <UtilityCardSkeleton />
                <UtilityCardSkeleton />
                <UtilityCardSkeleton />
              </>
            ) : floorBarbers.length ? floorBarbers.map((entry) => (
              <div key={entry.barber.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-medium">{entry.barber.name}</p>
                    <p className="mt-1 text-sm text-white/52">{entry.barber.compensationModel === "commission" ? "Commission barber" : "Booth-rent barber"}</p>
                  </div>
                  <span className="status-pill text-[#d7ffab]">{entry.utilization}% utilized</span>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <div className="rounded-[20px] border border-white/8 bg-black/25 p-3">
                    <p className="surface-label">Live chairs</p>
                    <p className="mt-2 text-2xl font-semibold" data-display="true">{entry.liveCount}</p>
                  </div>
                  <div className="rounded-[20px] border border-white/8 bg-black/25 p-3">
                    <p className="surface-label">Booked later</p>
                    <p className="mt-2 text-2xl font-semibold" data-display="true">{entry.bookedCount}</p>
                  </div>
                  <div className="rounded-[20px] border border-white/8 bg-black/25 p-3">
                    <p className="surface-label">Completed</p>
                    <p className="mt-2 text-2xl font-semibold" data-display="true">{entry.completed}</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-white/55">Next seat: {entry.nextAppointment ? `${dateLabel(entry.nextAppointment.start)} | ${entry.nextAppointment.chair}` : "Open chair right now"}</p>
              </div>
            )) : (
              <div className="empty-state-panel rounded-[24px] p-5 text-sm text-white/55">
                Barber utilization cards will appear here when staff are assigned to this shop.
              </div>
            )}
          </div>
        </Card>
      </section>

      <section className="grid gap-4 xl:grid-cols-[1fr_0.95fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="surface-label">Queue and desk activity</p>
              <p className="mt-2 text-sm text-white/58">Watch walk-ins, late arrivals, no-shows, and front-desk handoffs in one place.</p>
            </div>
            <div className="flex flex-wrap gap-2 text-[11px] uppercase tracking-[0.22em]">
              <span className="status-pill text-white/66">{noShowCount} no-shows</span>
              <span className="status-pill text-white/66">{lateWatchCount} late flags</span>
              <span className="status-pill text-white/66">{summary.queueAverageMinutes} min queue avg</span>
            </div>
          </div>
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <div className="space-y-3">
              {isInitialLoading ? (
                <>
                  <UtilityCardSkeleton />
                  <UtilityCardSkeleton />
                </>
              ) : walkIns.length ? walkIns.map((entry) => (
                <div key={entry.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-medium">{entry.clientName}</p>
                    <span className="status-pill text-[#d7ffab]">{entry.status}</span>
                  </div>
                  <p className="mt-1 text-sm text-white/55">{entry.requestedService}</p>
                  <p className="mt-3 text-sm text-white/58">Wait time {entry.waitMinutes} minutes</p>
                </div>
              )) : (
                <div className="empty-state-panel rounded-[24px] p-5 text-sm text-white/55">
                  Walk-ins will show here as front desk and floor traffic changes.
                </div>
              )}
            </div>
            <div className="space-y-3">
              {isInitialLoading ? (
                <>
                  <UtilityCardSkeleton />
                  <UtilityCardSkeleton />
                </>
              ) : frontDeskEvents.length ? frontDeskEvents.map((event) => (
                <div key={`${event.appointmentReference}-${event.createdAt}`} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <p className="font-medium">{event.title}</p>
                  <p className="mt-1 text-sm text-white/55">{event.detail}</p>
                  <p className="mt-3 text-[11px] uppercase tracking-[0.22em] text-[#cfff93]">Front desk | {event.createdAt}</p>
                </div>
              )) : (
                <div className="empty-state-panel rounded-[24px] p-5 text-sm text-white/55">
                  Front desk activity will appear here as check-ins and checkout handoffs happen.
                </div>
              )}
            </div>
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Approvals and operational alerts</p>
            <ClipboardCheck className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 space-y-3">
            {isInitialLoading ? (
              <>
                <UtilityCardSkeleton />
                <UtilityCardSkeleton />
                <UtilityCardSkeleton />
              </>
            ) : (
              <>
                {operationalTasks.map((task) => (
                  <div key={task.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <p className="font-medium">{task.title}</p>
                      <span className="status-pill text-[#d7ffab]">{task.priority} priority</span>
                    </div>
                    <p className="mt-1 text-sm text-white/55">Assignee: {task.assignee}</p>
                    <p className="mt-3 text-[11px] uppercase tracking-[0.22em] text-white/38">{task.status}</p>
                  </div>
                ))}
                <div className="rounded-[24px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4 transition hover:border-[#7CFF00]/28 hover:bg-[#7CFF00]/10">
                  <div className="flex items-center justify-between gap-3">
                    <p className="surface-label text-[#d7ffab]">Inventory watch</p>
                    <PackageSearch className="h-5 w-5 text-[#d7ffab]" />
                  </div>
                  <div className="mt-3 space-y-2 text-sm text-white/72">
                    {(inventoryAlerts.length ? inventoryAlerts : relevantInventory).map((item) => (
                      <div key={item.id} className="flex items-center justify-between gap-3 rounded-[18px] border border-white/8 bg-black/20 px-3 py-3">
                        <span>{item.name}</span>
                        <span className="status-pill text-[#d7ffab]">{item.stock} on hand</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 text-sm leading-6 text-white/65">
                  Limited approvals stay here for discounts, service adjustments, and floor notes. Owner account settings, billing, and compensation policy controls remain protected.
                </div>
                <div className="rounded-[24px] border border-amber-400/18 bg-amber-400/10 p-4 text-sm text-amber-100">
                  <div className="flex items-center gap-2">
                    <TriangleAlert className="h-4 w-4" />
                    {summary.readyForCheckoutCount} completed ticket{summary.readyForCheckoutCount === 1 ? "" : "s"} still need a checkout handoff.
                  </div>
                </div>
              </>
            )}
          </div>
        </Card>
      </section>
    </div>
  );
}