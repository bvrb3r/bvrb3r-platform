import { Card } from "@/components/ui/card";

const tiers = [
  { name: "Launch", price: "$199/mo", body: "Single-location MVP stack for up to 6 barbers." },
  { name: "Scale", price: "$449/mo", body: "Multi-location control, expanded analytics, and advanced workflows." },
  { name: "Flagship", price: "Custom", body: "Franchise, school, mobile bus, and branded commerce expansion." }
];

export default function PricingPage() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-10 lg:px-10 lg:py-16">
      <div className="max-w-2xl">
        <p className="text-sm uppercase tracking-[0.28em] text-[#baff69]">Pricing placeholder</p>
        <h1 className="mt-3 text-4xl font-semibold tracking-[-0.03em] md:text-5xl">Premium software pricing for a premium barbershop operation.</h1>
      </div>
      <div className="mt-10 grid gap-4 md:grid-cols-3">
        {tiers.map((tier) => (
          <Card key={tier.name} className="rounded-[30px] p-6">
            <p className="text-sm text-white/50">{tier.name}</p>
            <h2 className="mt-4 text-3xl font-semibold">{tier.price}</h2>
            <p className="mt-4 text-sm text-white/65">{tier.body}</p>
          </Card>
        ))}
      </div>
    </section>
  );
}