import { NextResponse } from "next/server";
import { requireEngagementActor } from "@/lib/engagement/auth";
import { getNotificationDeliveryProvider } from "@/lib/engagement/delivery-provider";
import { getOwnerIntelligenceSummary } from "@/lib/engagement/engine";
import { engagementErrorResponse } from "@/lib/engagement/http";
import { getEngagementProvider } from "@/lib/engagement/provider";
import { buildOwnerMarketplaceActivationSummary } from "@/lib/marketplace/activation";
import { getMarketplaceActivationProvider } from "@/lib/marketplace/activation-provider";
import { buildMarketplaceOwnerMetrics } from "@/lib/marketplace/growth";
import { getMarketplaceProvider } from "@/lib/marketplace/provider";
import { getLiveOperationsProvider } from "@/lib/operations/live-provider";
import { getOwnerTrustSummary } from "@/lib/trust/engine";
import { getTrustProvider } from "@/lib/trust/provider";

export async function GET() {
  try {
    const actor = await requireEngagementActor(["owner"]);
    const [engagementProvider, operationsProvider, marketplaceProvider, trustProvider, activationProvider, deliveryProvider] = await Promise.all([
      getEngagementProvider(),
      getLiveOperationsProvider(),
      getMarketplaceProvider(),
      getTrustProvider(),
      getMarketplaceActivationProvider(),
      getNotificationDeliveryProvider()
    ]);
    const [state, snapshot, runtime, trustState, activationState, deliveries] = await Promise.all([
      engagementProvider.readState(),
      operationsProvider.readSnapshot({ role: actor.role, clientId: actor.clientId, barberId: actor.barberId, locationIds: actor.locationIds, email: actor.userEmail }),
      marketplaceProvider.readRuntime(),
      trustProvider.readState(),
      activationProvider.readState(),
      deliveryProvider.readDeliveries()
    ]);
    return NextResponse.json({
      summary: {
        ...getOwnerIntelligenceSummary(state, snapshot, actor.locationIds ?? []),
        marketplace: { ...buildMarketplaceOwnerMetrics(runtime), referralInvites: state.referralEvents.length },
        trust: getOwnerTrustSummary(trustState, actor.locationIds ?? []),
        activation: buildOwnerMarketplaceActivationSummary({ activationState, deliveries })
      }
    });
  } catch (error) {
    return engagementErrorResponse(error);
  }
}
