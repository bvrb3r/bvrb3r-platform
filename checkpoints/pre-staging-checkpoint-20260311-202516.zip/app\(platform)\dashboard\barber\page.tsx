import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { BarberWorkspace } from "@/components/operations/barber-workspace";
import { getAuthorizedUser } from "@/lib/auth/guards";

export default async function BarberDashboardPage() {
  const user = await getAuthorizedUser(["commission_barber", "booth_rent_barber"]);
  return (
    <DashboardShell
      user={user}
      activeHref="/dashboard/barber"
      title="My chair, my clients, my money"
      subtitle="Run your day from first check-in to final payout visibility with a role-aware barber workspace built around your own appointments and earnings only."
    >
      <BarberWorkspace barberId={user.barberId ?? ""} />
    </DashboardShell>
  );
}