import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { Card } from "@/components/ui/card";
import { getAuthorizedUser } from "@/lib/auth/guards";
import { demoClients } from "@/lib/data/demo";

export default async function ClientsPage() {
  const user = await getAuthorizedUser(["owner", "manager", "front_desk"]);
  return (
    <DashboardShell user={user} activeHref="/clients" title="Client records" subtitle="Profiles, retention tags, notes, and service history visibility for the front desk and management team.">
      <Card className="rounded-[32px] p-6">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div>
            <p className="surface-label">Client roster</p>
            <p className="mt-2 text-sm text-white/58">Scan relationships, notes, and retention status without exposing restricted financial tools.</p>
          </div>
          <span className="status-pill text-[#d7ffab]">Role-safe records</span>
        </div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {demoClients.map((client) => (
            <div key={client.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4">
              <p className="font-medium">{client.name}</p>
              <p className="mt-1 text-sm text-white/50">{client.email}</p>
              <p className="mt-3 text-[11px] uppercase tracking-[0.18em] text-[#baff69]">{client.retentionTag} | {client.loyaltyPoints} pts</p>
              <p className="mt-3 text-sm text-white/65">{client.notes[0]}</p>
            </div>
          ))}
        </div>
      </Card>
    </DashboardShell>
  );
}