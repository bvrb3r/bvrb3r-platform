﻿/* eslint-disable @typescript-eslint/no-explicit-any */
import { getNotificationDeliveryProvider } from "@/lib/engagement/delivery-provider";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { isSupabaseEnabled } from "@/lib/config/runtime";
import { demoBarbers, demoClients, demoUsers } from "@/lib/data/demo";
import {
  createInitialEngagementState,
  createReferralInvite as createReferralInviteInState,
  followBarber as followBarberInState,
  recordEngagementEvent as recordEngagementEventInState,
  unfollowBarber as unfollowBarberInState,
  type EngagementActor,
  type RecordEngagementEventInput
} from "@/lib/engagement/engine";
import { getEngagementState, setEngagementState } from "@/lib/engagement/state";
import type {
  BarberFollowRecord,
  EngagementNotificationRecord,
  EngagementState,
  LoyaltyAccountRecord,
  LoyaltyTier
} from "@/types/engagement";

type SupabaseClient = NonNullable<ReturnType<typeof createSupabaseAdminClient>>;

export interface EngagementProvider {
  kind: "demo" | "supabase";
  readState(): Promise<EngagementState>;
  followBarber(
    actor: EngagementActor,
    input: Pick<BarberFollowRecord, "barberId" | "notifyOnAvailability" | "notifyOnPortfolio">
  ): Promise<ReturnType<typeof followBarberInState>>;
  unfollowBarber(actor: EngagementActor, barberId: string): Promise<{ unfollowedBarberId: string }>;
  createReferralInvite(actor: EngagementActor, input: { referredClientEmail: string }): Promise<ReturnType<typeof createReferralInviteInState>>;
  recordEvent(actor: EngagementActor, input: RecordEngagementEventInput): Promise<ReturnType<typeof recordEngagementEventInState>>;
  rewardCompletedBooking(input: { clientId: string; appointmentId: string }): Promise<void>;
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

function pointsToTier(points: number): LoyaltyTier {
  return points >= 250 ? "elite" : points >= 120 ? "vip" : "core";
}

function getClientEmail(clientId: string) {
  return demoClients.find((client) => client.id === clientId)?.email ?? `${clientId}@client.bvrb3r.local`;
}

function getBarberEmail(barberId: string) {
  const barber = demoBarbers.find((entry) => entry.id === barberId);
  return demoUsers.find((user) => user.id === barber?.userId)?.email ?? `${barberId}@barber.bvrb3r.local`;
}

function diffById<T extends { id: string }>(previous: T[], next: T[]) {
  const previousIds = new Set(previous.map((row) => row.id));
  return next.filter((row) => !previousIds.has(row.id));
}

function changedAccounts(previous: LoyaltyAccountRecord[], next: LoyaltyAccountRecord[]) {
  return next.filter((record) => {
    const current = previous.find((entry) => entry.clientId === record.clientId);
    return !current
      || current.pointsBalance !== record.pointsBalance
      || current.lifetimePoints !== record.lifetimePoints
      || current.referralCredits !== record.referralCredits
      || current.tier !== record.tier;
  });
}

async function syncNotificationDeliveries(previous: EngagementState, next: EngagementState) {
  const newNotifications = diffById(previous.notifications, next.notifications);
  if (!newNotifications.length) {
    return;
  }

  const deliveryProvider = await getNotificationDeliveryProvider();
  await deliveryProvider.syncNotifications(newNotifications);
}
async function hasRows(supabase: SupabaseClient, table: string) {
  const result = await supabase.from(table).select("*").limit(1);
  if (result.error) {
    throw result.error;
  }

  return (result.data ?? []).length > 0;
}

function toNotification(row: any): EngagementNotificationRecord | null {
  if (!row.notification_type || !row.audience_role || !row.audience_email) {
    return null;
  }

  return {
    id: row.dedupe_key ?? `${row.notification_type}-${row.audience_email}-${row.created_at}`,
    userEmail: row.audience_email,
    role: row.audience_role,
    clientId: row.client_reference ?? undefined,
    barberId: row.barber_reference ?? undefined,
    locationId: row.location_reference ?? undefined,
    channel: row.channel,
    type: row.notification_type,
    title: row.title,
    body: row.body,
    status: row.status,
    createdAt: row.created_at,
    scheduledFor: row.scheduled_for ?? undefined
  };
}

async function ensureSupabaseSeeded(supabase: SupabaseClient) {
  if (await hasRows(supabase, "notification_preferences")) {
    return;
  }

  const state = createInitialEngagementState();
  const writes = await Promise.all([
    supabase.from("notification_preferences").upsert(
      state.notificationPreferences.map((record) => ({
        id: record.id,
        role: record.role,
        user_email: record.userEmail,
        client_reference: record.clientId ?? null,
        barber_reference: record.barberId ?? null,
        in_app_enabled: record.inAppEnabled,
        sms_enabled: record.smsEnabled,
        email_enabled: record.emailEnabled,
        push_enabled: record.pushEnabled,
        updated_at: record.updatedAt,
        created_at: record.updatedAt
      })),
      { onConflict: "role,user_email" }
    ),
    supabase.from("loyalty_accounts").upsert(
      state.loyaltyAccounts.map((record) => ({
        id: record.id,
        client_reference: record.clientId,
        client_email: getClientEmail(record.clientId),
        points: record.pointsBalance,
        available_points: record.pointsBalance,
        lifetime_points: record.lifetimePoints,
        referral_credits: record.referralCredits,
        vip_status: record.tier,
        updated_at: record.updatedAt
      })),
      { onConflict: "client_reference" }
    ),
    supabase.from("loyalty_transactions").upsert(
      state.loyaltyTransactions.map((record) => ({
        client_reference: record.clientId,
        client_email: getClientEmail(record.clientId),
        reason: record.reason,
        points_delta: record.pointsDelta,
        label: record.label,
        reference_id: record.referenceId ?? null,
        metadata: {},
        created_at: record.createdAt,
        dedupe_key: record.id
      })),
      { onConflict: "dedupe_key" }
    ),
    supabase.from("referral_codes").upsert(
      state.referralCodes.map((record) => ({
        id: record.id,
        client_reference: record.clientId,
        client_email: getClientEmail(record.clientId),
        code: record.code,
        reward_points: record.rewardPoints,
        active: record.active,
        created_at: record.createdAt
      })),
      { onConflict: "code" }
    ),
    supabase.from("referral_events").insert(
      state.referralEvents.map((record) => ({
        id: record.id,
        referral_code_id: record.referralCodeId,
        referrer_client_reference: record.referrerClientId,
        referrer_client_email: getClientEmail(record.referrerClientId),
        referred_client_email: record.referredClientEmail,
        status: record.status,
        reward_points: record.rewardPoints,
        metadata: {},
        created_at: record.createdAt,
        completed_at: record.completedAt ?? null
      }))
    ),
    supabase.from("barber_follows").upsert(
      state.barberFollows.map((record) => ({
        client_reference: record.clientId,
        client_email: getClientEmail(record.clientId),
        barber_reference: record.barberId,
        barber_email: getBarberEmail(record.barberId),
        notify_on_availability: record.notifyOnAvailability,
        notify_on_portfolio: record.notifyOnPortfolio,
        created_at: record.createdAt
      })),
      { onConflict: "client_reference,barber_reference" }
    ),
    supabase.from("engagement_events").upsert(
      state.engagementEvents.map((record) => ({
        actor_role: record.actorRole,
        actor_reference: record.actorId,
        actor_email: record.actorRole === "client" ? getClientEmail(record.actorId) : record.actorRole === "owner" ? "owner@bvrb3r.demo" : getBarberEmail(record.actorId),
        target_type: record.targetType,
        target_reference: record.targetId,
        target_email: record.targetType === "client" ? getClientEmail(record.targetId) : record.targetType === "barber" ? getBarberEmail(record.targetId) : null,
        event_type: record.eventType,
        metadata: record.metadata,
        created_at: record.createdAt,
        dedupe_key: record.id
      })),
      { onConflict: "dedupe_key" }
    ),
    supabase.from("rebooking_cycles").insert(
      state.rebookingCycles.map((record) => ({
        id: record.id,
        client_reference: record.clientId,
        client_email: getClientEmail(record.clientId),
        barber_reference: record.barberId ?? null,
        service_reference: record.serviceId ?? null,
        average_cycle_days: record.averageCycleDays,
        confidence: record.confidence,
        last_completed_at: record.lastCompletedAt,
        next_suggested_at: record.nextSuggestedAt,
        updated_at: record.nextSuggestedAt
      }))
    ),
    supabase.from("rebooking_recommendations").insert(
      state.rebookingRecommendations.map((record) => ({
        id: record.id,
        client_reference: record.clientId,
        client_email: getClientEmail(record.clientId),
        barber_reference: record.barberId ?? null,
        service_reference: record.serviceId ?? null,
        message: record.message,
        remind_at: record.remindAt,
        status: record.status,
        reason: record.reason,
        metadata: {},
        created_at: record.remindAt
      }))
    ),
    supabase.from("notifications").upsert(
      state.notifications.map((record) => ({
        audience_role: record.role,
        audience_email: record.userEmail,
        client_reference: record.clientId ?? null,
        client_email: record.clientId ? getClientEmail(record.clientId) : null,
        barber_reference: record.barberId ?? null,
        barber_email: record.barberId ? getBarberEmail(record.barberId) : null,
        location_reference: record.locationId ?? null,
        channel: record.channel,
        notification_type: record.type,
        title: record.title,
        body: record.body,
        status: record.status,
        metadata: {},
        created_at: record.createdAt,
        scheduled_for: record.scheduledFor ?? null,
        dedupe_key: record.id
      })),
      { onConflict: "dedupe_key" }
    ),
    supabase.from("reputation_scores").upsert(
      state.reputationScores.map((record) => ({
        barber_reference: record.barberId,
        barber_email: getBarberEmail(record.barberId),
        review_score: record.reviewScore,
        punctuality_score: record.punctualityScore,
        completion_score: record.completionScore,
        retention_score: record.retentionScore,
        overall_score: record.overallScore,
        reputation_tier: record.tier,
        updated_at: record.updatedAt
      })),
      { onConflict: "barber_reference" }
    ),
    supabase.from("ranking_snapshots").insert(
      state.rankingSnapshots.map((record) => ({
        id: record.id,
        barber_reference: record.barberId,
        barber_email: getBarberEmail(record.barberId),
        dimension: record.dimension,
        rank_position: record.rankPosition,
        score: record.score,
        label: record.label,
        metadata: {},
        observed_at: record.observedAt,
        created_at: record.observedAt
      }))
    ),
    supabase.from("growth_recommendations").insert(
      state.growthRecommendations.map((record) => ({
        id: record.id,
        barber_reference: record.barberId,
        barber_email: getBarberEmail(record.barberId),
        title: record.title,
        description: record.description,
        focus_area: record.focusArea,
        priority: record.priority,
        status: record.status,
        action_label: record.actionLabel,
        metadata: {},
        created_at: record.createdAt,
        updated_at: record.createdAt
      }))
    )
  ]);

  for (const write of writes) {
    if (write.error) {
      throw write.error;
    }
  }
}

async function readSupabaseState(supabase: SupabaseClient): Promise<EngagementState> {
  await ensureSupabaseSeeded(supabase);
  const base = createInitialEngagementState();
  const [
    notificationPreferences,
    accounts,
    transactions,
    referralCodes,
    referralEvents,
    follows,
    events,
    rebookingCycles,
    rebookingRecommendations,
    notifications,
    reputationScores,
    rankingSnapshots,
    growthRecommendations
  ] = await Promise.all([
    supabase.from("notification_preferences").select("id, role, user_email, client_reference, barber_reference, in_app_enabled, sms_enabled, email_enabled, push_enabled, updated_at").order("updated_at", { ascending: false }),
    supabase.from("loyalty_accounts").select("id, client_reference, points, available_points, lifetime_points, referral_credits, vip_status, updated_at"),
    supabase.from("loyalty_transactions").select("client_reference, reason, points_delta, label, reference_id, created_at, dedupe_key").order("created_at", { ascending: false }),
    supabase.from("referral_codes").select("id, client_reference, code, reward_points, active, created_at").order("created_at", { ascending: false }),
    supabase.from("referral_events").select("id, referral_code_id, referrer_client_reference, referred_client_email, status, reward_points, created_at, completed_at").order("created_at", { ascending: false }),
    supabase.from("barber_follows").select("client_reference, barber_reference, notify_on_availability, notify_on_portfolio, created_at").order("created_at", { ascending: false }),
    supabase.from("engagement_events").select("actor_role, actor_reference, target_type, target_reference, event_type, metadata, created_at, dedupe_key").order("created_at", { ascending: false }),
    supabase.from("rebooking_cycles").select("id, client_reference, barber_reference, service_reference, average_cycle_days, confidence, last_completed_at, next_suggested_at").order("next_suggested_at", { ascending: true }),
    supabase.from("rebooking_recommendations").select("id, client_reference, barber_reference, service_reference, message, remind_at, status, reason, created_at").order("created_at", { ascending: false }),
    supabase.from("notifications").select("audience_role, audience_email, client_reference, barber_reference, location_reference, channel, notification_type, title, body, status, created_at, scheduled_for, dedupe_key").not("notification_type", "is", null).order("created_at", { ascending: false }),
    supabase.from("reputation_scores").select("barber_reference, review_score, punctuality_score, completion_score, retention_score, overall_score, reputation_tier, updated_at"),
    supabase.from("ranking_snapshots").select("id, barber_reference, dimension, rank_position, score, label, observed_at").order("observed_at", { ascending: false }),
    supabase.from("growth_recommendations").select("id, barber_reference, title, description, focus_area, priority, status, action_label, created_at").order("created_at", { ascending: false })
  ]);

  for (const result of [notificationPreferences, accounts, transactions, referralCodes, referralEvents, follows, events, rebookingCycles, rebookingRecommendations, notifications, reputationScores, rankingSnapshots, growthRecommendations]) {
    if (result.error) {
      throw result.error;
    }
  }

  return {
    ...base,
    notificationPreferences: (notificationPreferences.data ?? []).map((row: any) => ({
      id: row.id ?? `pref-${row.role}-${row.user_email}`,
      userEmail: row.user_email,
      role: row.role,
      clientId: row.client_reference ?? undefined,
      barberId: row.barber_reference ?? undefined,
      inAppEnabled: row.in_app_enabled,
      smsEnabled: row.sms_enabled,
      emailEnabled: row.email_enabled,
      pushEnabled: row.push_enabled,
      updatedAt: row.updated_at
    })),
    loyaltyAccounts: (accounts.data ?? []).map((row: any) => ({
      id: row.id ?? `loyalty-${row.client_reference}`,
      clientId: row.client_reference,
      pointsBalance: Number(row.available_points ?? row.points ?? 0),
      lifetimePoints: Number(row.lifetime_points ?? row.available_points ?? row.points ?? 0),
      referralCredits: Number(row.referral_credits ?? 0),
      tier: (row.vip_status as LoyaltyTier | null) ?? pointsToTier(Number(row.available_points ?? row.points ?? 0)),
      updatedAt: row.updated_at ?? new Date().toISOString()
    })),
    loyaltyTransactions: (transactions.data ?? []).map((row: any) => ({
      id: row.dedupe_key ?? `${row.reason}-${row.reference_id ?? row.created_at}`,
      clientId: row.client_reference,
      reason: row.reason,
      pointsDelta: row.points_delta,
      label: row.label,
      referenceId: row.reference_id ?? undefined,
      createdAt: row.created_at
    })),
    referralCodes: (referralCodes.data ?? []).map((row: any) => ({
      id: row.id,
      clientId: row.client_reference,
      code: row.code,
      rewardPoints: row.reward_points,
      active: row.active,
      createdAt: row.created_at
    })),
    referralEvents: (referralEvents.data ?? []).map((row: any) => ({
      id: row.id,
      referralCodeId: row.referral_code_id,
      referrerClientId: row.referrer_client_reference,
      referredClientEmail: row.referred_client_email,
      status: row.status,
      rewardPoints: row.reward_points,
      createdAt: row.created_at,
      completedAt: row.completed_at ?? undefined
    })),
    barberFollows: (follows.data ?? []).map((row: any) => ({
      id: `follow-${row.client_reference}-${row.barber_reference}`,
      clientId: row.client_reference,
      barberId: row.barber_reference,
      notifyOnAvailability: row.notify_on_availability,
      notifyOnPortfolio: row.notify_on_portfolio,
      createdAt: row.created_at
    })),
    engagementEvents: (events.data ?? []).map((row: any) => ({
      id: row.dedupe_key ?? `${row.event_type}-${row.actor_reference}-${row.created_at}`,
      actorRole: row.actor_role,
      actorId: row.actor_reference,
      targetType: row.target_type,
      targetId: row.target_reference,
      eventType: row.event_type,
      metadata: row.metadata ?? {},
      createdAt: row.created_at
    })),
    rebookingCycles: (rebookingCycles.data ?? []).map((row: any) => ({
      id: row.id,
      clientId: row.client_reference,
      barberId: row.barber_reference ?? undefined,
      serviceId: row.service_reference ?? undefined,
      averageCycleDays: row.average_cycle_days,
      confidence: row.confidence,
      lastCompletedAt: row.last_completed_at,
      nextSuggestedAt: row.next_suggested_at
    })),
    rebookingRecommendations: (rebookingRecommendations.data ?? []).map((row: any) => ({
      id: row.id,
      clientId: row.client_reference,
      barberId: row.barber_reference ?? undefined,
      serviceId: row.service_reference ?? undefined,
      message: row.message,
      remindAt: row.remind_at,
      status: row.status,
      reason: row.reason,
      createdAt: row.created_at
    })),
    notifications: (notifications.data ?? []).map((row: any) => toNotification(row)).filter((row): row is EngagementNotificationRecord => Boolean(row)),
    reputationScores: (reputationScores.data ?? []).map((row: any) => ({
      barberId: row.barber_reference,
      reviewScore: Number(row.review_score ?? 0),
      punctualityScore: Number(row.punctuality_score ?? 0),
      completionScore: Number(row.completion_score ?? 0),
      retentionScore: Number(row.retention_score ?? 0),
      overallScore: Number(row.overall_score ?? 0),
      tier: row.reputation_tier,
      updatedAt: row.updated_at
    })),
    rankingSnapshots: (rankingSnapshots.data ?? []).map((row: any) => ({
      id: row.id ?? `${row.dimension}-${row.barber_reference}-${row.observed_at}`,
      barberId: row.barber_reference,
      dimension: row.dimension,
      rankPosition: row.rank_position,
      score: Number(row.score ?? 0),
      label: row.label,
      observedAt: row.observed_at
    })),
    growthRecommendations: (growthRecommendations.data ?? []).map((row: any) => ({
      id: row.id ?? `${row.barber_reference}-${row.focus_area}-${row.created_at}`,
      barberId: row.barber_reference,
      title: row.title,
      description: row.description,
      focusArea: row.focus_area,
      priority: row.priority,
      status: row.status,
      actionLabel: row.action_label,
      createdAt: row.created_at
    }))
  };
}

async function persistDiff(supabase: SupabaseClient, previous: EngagementState, next: EngagementState) {
  const accountRows = changedAccounts(previous.loyaltyAccounts, next.loyaltyAccounts).map((record) => ({
    client_reference: record.clientId,
    client_email: getClientEmail(record.clientId),
    points: record.pointsBalance,
    available_points: record.pointsBalance,
    lifetime_points: record.lifetimePoints,
    referral_credits: record.referralCredits,
    vip_status: record.tier,
    updated_at: record.updatedAt
  }));
  if (accountRows.length) {
    const result = await supabase.from("loyalty_accounts").upsert(accountRows, { onConflict: "client_reference" });
    if (result.error) {
      throw result.error;
    }
  }

  const transactionRows = diffById(previous.loyaltyTransactions, next.loyaltyTransactions).map((record) => ({
    client_reference: record.clientId,
    client_email: getClientEmail(record.clientId),
    reason: record.reason,
    points_delta: record.pointsDelta,
    label: record.label,
    reference_id: record.referenceId ?? null,
    metadata: {},
    created_at: record.createdAt,
    dedupe_key: record.id
  }));
  if (transactionRows.length) {
    const result = await supabase.from("loyalty_transactions").upsert(transactionRows, { onConflict: "dedupe_key" });
    if (result.error) {
      throw result.error;
    }
  }

  const referralRows = diffById(previous.referralEvents, next.referralEvents).map((record) => ({
    id: record.id,
    referral_code_id: record.referralCodeId,
    referrer_client_reference: record.referrerClientId,
    referrer_client_email: getClientEmail(record.referrerClientId),
    referred_client_email: record.referredClientEmail,
    status: record.status,
    reward_points: record.rewardPoints,
    metadata: {},
    created_at: record.createdAt,
    completed_at: record.completedAt ?? null
  }));
  if (referralRows.length) {
    const result = await supabase.from("referral_events").upsert(referralRows, { onConflict: "id" });
    if (result.error) {
      throw result.error;
    }
  }

  const followRows = diffById(previous.barberFollows, next.barberFollows).map((record) => ({
    client_reference: record.clientId,
    client_email: getClientEmail(record.clientId),
    barber_reference: record.barberId,
    barber_email: getBarberEmail(record.barberId),
    notify_on_availability: record.notifyOnAvailability,
    notify_on_portfolio: record.notifyOnPortfolio,
    created_at: record.createdAt
  }));
  if (followRows.length) {
    const result = await supabase.from("barber_follows").upsert(followRows, { onConflict: "client_reference,barber_reference" });
    if (result.error) {
      throw result.error;
    }
  }

  const eventRows = diffById(previous.engagementEvents, next.engagementEvents).map((record) => ({
    actor_role: record.actorRole,
    actor_reference: record.actorId,
    actor_email: record.actorRole === "client" ? getClientEmail(record.actorId) : record.actorRole === "owner" ? "owner@bvrb3r.demo" : getBarberEmail(record.actorId),
    target_type: record.targetType,
    target_reference: record.targetId,
    target_email: record.targetType === "client" ? getClientEmail(record.targetId) : record.targetType === "barber" ? getBarberEmail(record.targetId) : null,
    event_type: record.eventType,
    metadata: record.metadata,
    created_at: record.createdAt,
    dedupe_key: record.id
  }));
  if (eventRows.length) {
    const result = await supabase.from("engagement_events").upsert(eventRows, { onConflict: "dedupe_key" });
    if (result.error) {
      throw result.error;
    }
  }

  const notificationRows = diffById(previous.notifications, next.notifications).map((record) => ({
    audience_role: record.role,
    audience_email: record.userEmail,
    client_reference: record.clientId ?? null,
    client_email: record.clientId ? getClientEmail(record.clientId) : null,
    barber_reference: record.barberId ?? null,
    barber_email: record.barberId ? getBarberEmail(record.barberId) : null,
    location_reference: record.locationId ?? null,
    channel: record.channel,
    notification_type: record.type,
    title: record.title,
    body: record.body,
    status: record.status,
    metadata: {},
    created_at: record.createdAt,
    scheduled_for: record.scheduledFor ?? null,
    dedupe_key: record.id
  }));
  if (notificationRows.length) {
    const result = await supabase.from("notifications").upsert(notificationRows, { onConflict: "dedupe_key" });
    if (result.error) {
      throw result.error;
    }
  }

  await syncNotificationDeliveries(previous, next);
}

function applyCompletedBookingReward(state: EngagementState, input: { clientId: string; appointmentId: string }) {
  if (state.loyaltyTransactions.some((record) => record.referenceId === input.appointmentId && record.reason === "completed_booking")) {
    return state;
  }

  const existing = state.loyaltyAccounts.find((record) => record.clientId === input.clientId);
  const now = new Date().toISOString();
  const nextBalance = Math.max(0, (existing?.pointsBalance ?? 0) + 25);

  return {
    ...state,
    loyaltyAccounts: [
      {
        id: existing?.id ?? `loyalty-${input.clientId}`,
        clientId: input.clientId,
        pointsBalance: nextBalance,
        lifetimePoints: (existing?.lifetimePoints ?? 0) + 25,
        referralCredits: existing?.referralCredits ?? 0,
        tier: pointsToTier(nextBalance),
        updatedAt: now
      },
      ...state.loyaltyAccounts.filter((record) => record.clientId !== input.clientId)
    ],
    loyaltyTransactions: [
      {
        id: `completed-booking-${input.appointmentId}`,
        clientId: input.clientId,
        reason: "completed_booking" as const,
        pointsDelta: 25,
        label: "Completed booked appointment",
        referenceId: input.appointmentId,
        createdAt: now
      },
      ...state.loyaltyTransactions
    ]
  };
}

function createDemoProvider(): EngagementProvider {
  return {
    kind: "demo",
    async readState() {
      return clone(getEngagementState());
    },
    async followBarber(actor, input) {
      const previous = getEngagementState();
      const result = followBarberInState(previous, actor, input);
      setEngagementState(result.state);
      await syncNotificationDeliveries(previous, result.state);
      return result;
    },
    async unfollowBarber(actor, barberId) {
      const result = unfollowBarberInState(getEngagementState(), actor, barberId);
      setEngagementState(result.state);
      return { unfollowedBarberId: result.unfollowedBarberId };
    },
    async createReferralInvite(actor, input) {
      const previous = getEngagementState();
      const result = createReferralInviteInState(previous, actor, input);
      setEngagementState(result.state);
      await syncNotificationDeliveries(previous, result.state);
      return result;
    },
    async recordEvent(actor, input) {
      const previous = getEngagementState();
      const result = recordEngagementEventInState(previous, actor, input);
      setEngagementState(result.state);
      await syncNotificationDeliveries(previous, result.state);
      return result;
    },
    async rewardCompletedBooking(input) {
      const previous = getEngagementState();
      const next = applyCompletedBookingReward(previous, input);
      setEngagementState(next);
      await syncNotificationDeliveries(previous, next);
    }
  };
}

function createSupabaseProvider(supabase: SupabaseClient): EngagementProvider {
  return {
    kind: "supabase",
    async readState() {
      return readSupabaseState(supabase);
    },
    async followBarber(actor, input) {
      const previous = await readSupabaseState(supabase);
      const result = followBarberInState(previous, actor, input);
      await persistDiff(supabase, previous, result.state);
      return result;
    },
    async unfollowBarber(actor, barberId) {
      const previous = await readSupabaseState(supabase);
      const result = unfollowBarberInState(previous, actor, barberId);
      const remove = await supabase.from("barber_follows").delete().eq("client_reference", actor.clientId ?? "").eq("barber_reference", barberId);
      if (remove.error) {
        throw remove.error;
      }
      return { unfollowedBarberId: result.unfollowedBarberId };
    },
    async createReferralInvite(actor, input) {
      const previous = await readSupabaseState(supabase);
      const result = createReferralInviteInState(previous, actor, input);
      await persistDiff(supabase, previous, result.state);
      return result;
    },
    async recordEvent(actor, input) {
      const previous = await readSupabaseState(supabase);
      const result = recordEngagementEventInState(previous, actor, input);
      await persistDiff(supabase, previous, result.state);
      return result;
    },
    async rewardCompletedBooking(input) {
      const previous = await readSupabaseState(supabase);
      const next = applyCompletedBookingReward(previous, input);
      await persistDiff(supabase, previous, next);
    }
  };
}

export async function getEngagementProvider(): Promise<EngagementProvider> {
  if (!isSupabaseEnabled()) {
    return createDemoProvider();
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return createDemoProvider();
  }

  return createSupabaseProvider(supabase);
}











