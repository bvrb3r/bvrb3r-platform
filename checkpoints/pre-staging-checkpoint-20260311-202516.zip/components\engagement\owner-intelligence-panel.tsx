"use client";

import { useState } from "react";
import { Globe2, HandCoins, RefreshCcw, ShieldCheck, Smartphone, UploadCloud, Users } from "lucide-react";
import { usePwa } from "@/components/pwa/pwa-provider";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FeedbackBanner } from "@/components/ui/feedback-banner";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useOwnerEngagementIntelligence } from "@/lib/engagement/client";
import { useMobileActivationSummary } from "@/lib/mobile/client";
import { useCreateFeaturedPlacementMutation, useUpdateCityRolloutMutation } from "@/lib/marketplace/activation-client";
import { useCreateVerificationUploadMutation, useSubmitShopVerificationMutation } from "@/lib/trust/client";
import { currency } from "@/lib/utils";
import { getReadableActionError } from "@/lib/utils/feedback";

function PanelSkeleton() {
  return (
    <Card className="rounded-[32px] p-6">
      <Skeleton className="h-5 w-48" />
      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-5">
        <Skeleton className="h-28 w-full rounded-[24px]" />
        <Skeleton className="h-28 w-full rounded-[24px]" />
        <Skeleton className="h-28 w-full rounded-[24px]" />
        <Skeleton className="h-28 w-full rounded-[24px]" />
        <Skeleton className="h-28 w-full rounded-[24px]" />
      </div>
    </Card>
  );
}

export function OwnerIntelligencePanel() {
  const summaryQuery = useOwnerEngagementIntelligence();
  const mobileSummaryQuery = useMobileActivationSummary();
  const pwa = usePwa();
  const uploadMutation = useCreateVerificationUploadMutation();
  const submitShopVerificationMutation = useSubmitShopVerificationMutation();
  const featureMutation = useCreateFeaturedPlacementMutation();
  const rolloutMutation = useUpdateCityRolloutMutation();
  const [feedback, setFeedback] = useState<{ tone: "success" | "error" | "info"; message: string } | null>(null);
  const [shopDocumentName, setShopDocumentName] = useState("bvrb3r-business-license.pdf");

  async function handleEnablePush() {
    const result = await pwa.enablePush();
    setFeedback({ tone: result.ok ? "success" : "error", message: result.message });
  }

  async function handleDisablePush() {
    await pwa.disablePush();
    setFeedback({ tone: "success", message: "Owner mobile alerts were turned off for this device." });
  }

  if (summaryQuery.isLoading && !summaryQuery.data) {
    return <PanelSkeleton />;
  }

  if (summaryQuery.isError || !summaryQuery.data) {
    return (
      <Card className="rounded-[32px] p-6">
        <FeedbackBanner tone="error" message="Something went wrong while loading owner engagement intelligence. Please try again." />
      </Card>
    );
  }

  const summary = summaryQuery.data;
  const activation = summary.activation;
  const mobileSummary = mobileSummaryQuery.data;
  const isPending = uploadMutation.isPending || submitShopVerificationMutation.isPending || featureMutation.isPending || rolloutMutation.isPending;

  async function handleShopVerification() {
    setFeedback(null);
    try {
      const upload = await uploadMutation.mutateAsync({
        ownerType: "shop",
        ownerId: "shop-bvrb3r",
        category: "business_verification",
        fileName: shopDocumentName,
        contentType: "application/pdf",
        fileSizeBytes: 410000
      });
      await submitShopVerificationMutation.mutateAsync({
        shopId: "shop-bvrb3r",
        category: "business_verification",
        businessName: "The BVRB3R Shop(TM)",
        documentPath: upload.upload.storagePath
      });
      setFeedback({ tone: "success", message: "Shop verification was submitted with a private document reference for trust review." });
    } catch (error) {
      setFeedback({ tone: "error", message: getReadableActionError(error as Error) });
    }
  }

  async function handleFeaturedPlacement() {
    setFeedback(null);
    try {
      await featureMutation.mutateAsync({
        scopeType: "barber",
        scopeId: "barber-wave",
        label: "Featured barber in Tampa Bay",
        placementScope: "discover_hero",
        citySlug: "tampa-bay",
        priority: 1,
        startsAt: new Date().toISOString(),
        endsAt: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString()
      });
      setFeedback({ tone: "success", message: "Featured placement inventory updated for the current launch market." });
    } catch (error) {
      setFeedback({ tone: "error", message: getReadableActionError(error as Error) });
    }
  }

  async function handleCityRollout() {
    setFeedback(null);
    try {
      await rolloutMutation.mutateAsync({
        citySlug: "st-petersburg",
        activationState: "live",
        launchVisible: true,
        densityScore: 72,
        marketNotes: "Promoted to live after density, referrals, and discovery demand crossed the launch threshold."
      });
      setFeedback({ tone: "success", message: "City rollout updated. Discovery can now treat the market as launch-visible." });
    } catch (error) {
      setFeedback({ tone: "error", message: getReadableActionError(error as Error) });
    }
  }

  return (
    <section className="space-y-4" data-testid="owner-intelligence-panel">
      {feedback ? <FeedbackBanner tone={feedback.tone} message={feedback.message} /> : null}

      <Card className="rounded-[32px] p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="surface-label text-[#d7ffab]">Owner intelligence</p>
            <h3 className="mt-3 text-3xl font-semibold sm:text-4xl" data-display="true">Retention, loyalty, referrals, and marketplace lift</h3>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-white/64">The operating system now has a monetization, trust, and mobile activation layer for featured placement, boosted discovery, rollout density, and delivery-aware marketplace reporting.</p>
          </div>
          <span className="status-pill text-[#d7ffab]">{summary.assignedLocationIds.length} locations in scope</span>
        </div>

        <div className="mt-6 grid gap-3 md:grid-cols-2 xl:grid-cols-5">
          <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Revenue in scope</p><p className="mt-3 text-3xl font-semibold" data-display="true">{currency(summary.network.revenue)}</p><p className="mt-2 text-sm text-white/58">Current business-date revenue from the owner analytics rails</p></div>
          <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Marketplace bookings</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.marketplace.bookingsCreated}</p><p className="mt-2 text-sm text-white/58">Bookings created through discover, profile, or haircut-now flows</p></div>
          <div className="rounded-[24px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4"><p className="surface-label text-[#d7ffab]">Loyalty participants</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.retention.loyaltyParticipants}</p><p className="mt-2 text-sm text-white/62">Clients already inside the BVRB3R Points economy</p></div>
          <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Referral conversions</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.retention.referralConversions}</p><p className="mt-2 text-sm text-white/58">Completed or credited referral events in owner scope</p></div>
          <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Chair utilization</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.network.chairUtilization}%</p><p className="mt-2 text-sm text-white/58">Utilization scaffold tied to active chair throughput</p></div>
        </div>
      </Card>

      <section className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3"><p className="surface-label">Retention signals</p><RefreshCcw className="h-5 w-5 text-[#baff69]" /></div>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Repeat client rate</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.retention.repeatClientRate}%</p></div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Rebooking effectiveness</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.retention.rebookingEffectiveness}%</p></div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Points issued</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.retention.loyaltyPointsIssued}</p><p className="mt-2 text-sm text-white/58">Ready to feed conversion reporting and ranking weight later.</p></div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Referral invites</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.marketplace.referralInvites}</p><p className="mt-2 text-sm text-white/58">Tracked invites flowing through the client growth loop.</p></div>
          </div>
          <div className="mt-4 rounded-[22px] border border-white/8 bg-black/20 px-4 py-4 text-sm text-white/64">Discovery impressions {summary.marketplace.discoveryImpressions} | Profile views {summary.marketplace.profileViews} | Shares {summary.marketplace.shareCount} | Haircut-now signals {summary.marketplace.haircutNowImpressions}</div>
          <div className="mt-4 space-y-3">{summary.bookingTrends.map((trend) => <div key={trend.label} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4"><div className="flex items-center justify-between gap-3"><p className="font-medium">{trend.label}</p><span className="status-pill text-[#d7ffab]">{trend.value}</span></div></div>)}</div>
        </Card>

        <div className="grid gap-4">
          <Card className="rounded-[32px] p-6">
            <div className="flex items-center justify-between gap-3"><p className="surface-label">Top barbers in scope</p><Users className="h-5 w-5 text-[#baff69]" /></div>
            <div className="mt-4 space-y-3">{summary.topBarbers.map((barber) => <div key={barber.barberId} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4"><div className="flex items-center justify-between gap-3"><p className="font-medium">{barber.barberName}</p><span className="status-pill text-[#d7ffab]">{currency(barber.revenue)}</span></div><div className="mt-3 grid gap-3 text-sm text-white/60 sm:grid-cols-3"><div className="rounded-[18px] border border-white/8 bg-black/25 px-3 py-3">Followers {barber.followerCount}</div><div className="rounded-[18px] border border-white/8 bg-black/25 px-3 py-3">Reputation {barber.reputationScore.toFixed(1)}</div><div className="rounded-[18px] border border-white/8 bg-black/25 px-3 py-3">Revenue {currency(barber.revenue)}</div></div></div>)}</div>
          </Card>

          <Card className="rounded-[32px] p-6">
            <div className="flex items-center justify-between gap-3"><p className="surface-label">Notification hooks</p><HandCoins className="h-5 w-5 text-[#baff69]" /></div>
            <div className="mt-4 space-y-3">{summary.recentNotifications.length ? summary.recentNotifications.map((notification) => <div key={notification.id} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4"><div className="flex items-center justify-between gap-3"><p className="font-medium">{notification.title}</p><span className="status-pill text-[#d7ffab]">{notification.type.replaceAll("_", " ")}</span></div><p className="mt-2 text-sm leading-7 text-white/60">{notification.body}</p></div>) : <div className="empty-state-panel rounded-[22px] p-5 text-sm text-white/58">Owner-facing engagement alerts will appear here as the growth engine begins firing live notifications.</div>}</div>
            <div className="mt-4 rounded-[22px] border border-white/8 bg-black/20 px-4 py-4 text-sm text-white/64">Nearby-client instant booking alerts, loyalty milestone nudges, referral monitoring, verification updates, and push-ready activation all route through the same delivery ledger.</div>
            <div className="mt-4 rounded-[22px] border border-white/8 bg-black/20 px-4 py-4 text-sm text-white/64">Top growth sources: {summary.marketplace.topSources.length ? summary.marketplace.topSources.map((source) => `${source.sourceKind} ${source.count}`).join(" | ") : "Building source attribution"}</div>
          </Card>
        </div>
      </section>

      {summary.trust ? (
        <section className="grid gap-4 xl:grid-cols-[0.95fr_1.05fr]">
          <Card className="rounded-[32px] p-6">
            <div className="flex items-center justify-between gap-3"><p className="surface-label">Trust and verification command</p><ShieldCheck className="h-5 w-5 text-[#baff69]" /></div>
            <div className="mt-4 grid gap-3 sm:grid-cols-4">
              <div className="rounded-[22px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4"><p className="surface-label text-[#d7ffab]">Open reports</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.openReports}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Open disputes</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.openDisputes}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">High-risk flags</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.highRiskFlags}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Integrity alerts</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.reviewIntegrityAlerts}</p></div>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Staff verified</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.staffVerification.verified}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Pending</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.staffVerification.pending}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Expired or rejected</p><p className="mt-3 text-3xl font-semibold" data-display="true">{summary.trust.staffVerification.expired + summary.trust.staffVerification.rejected}</p></div>
            </div>
            <div className="mt-4 flex flex-wrap gap-2">{summary.trust.shopTrustBadges.length ? summary.trust.shopTrustBadges.map((badge) => <span key={badge} className="status-pill text-[#d7ffab]">{badge}</span>) : <span className="status-pill text-white/72">Shop trust badges will appear here as verification clears.</span>}</div>
            <div className="mt-4 space-y-3">{summary.trust.shopStatuses.map((shop) => <div key={shop.shopId} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4"><div className="flex flex-wrap items-center justify-between gap-3"><p className="font-medium">{shop.shopName}</p><span className={`status-pill ${shop.status === "verified" ? "text-[#d7ffab]" : shop.status === "pending" ? "text-amber-200" : "text-white/72"}`}>{shop.badgeLabel}</span></div><p className="mt-2 text-sm text-white/58">Verified categories: {shop.verifiedCategories.length ? shop.verifiedCategories.map((category) => category.replaceAll("_", " ")).join(" | ") : "Verification still in progress"}</p></div>)}</div>
          </Card>

          <Card className="rounded-[32px] p-6">
            <div className="flex items-center justify-between gap-3"><p className="surface-label">Activation and monetization</p><Globe2 className="h-5 w-5 text-[#baff69]" /></div>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Boost impressions</p><p className="mt-3 text-3xl font-semibold">{activation?.monetizationTotals.boostImpressions ?? 0}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Featured bookings</p><p className="mt-3 text-3xl font-semibold">{activation?.monetizationTotals.featuredBookings ?? 0}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Delivered alerts</p><p className="mt-3 text-3xl font-semibold">{activation?.deliverySummary.delivered ?? 0}</p></div>
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><p className="surface-label">Push status</p><p className="mt-3 text-3xl font-semibold">{mobileSummary?.pushEnabled ? "Live" : pwa.pushPermission === "granted" ? "Ready" : "Off"}</p><p className="mt-2 text-sm text-white/58">{mobileSummary?.activeSubscriptionCount ?? 0} executive device route{(mobileSummary?.activeSubscriptionCount ?? 0) === 1 ? "" : "s"}</p></div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="surface-label">Native-ready routes</p><Smartphone className="h-4 w-4 text-[#baff69]" /></div><p className="mt-3 text-3xl font-semibold">{mobileSummary?.deepLinks.length ?? 0}</p><p className="mt-2 text-sm text-white/58">Owner, discovery, and leaderboard links are ready for app-open behavior.</p></div>
              <div className="rounded-[22px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4"><p className="surface-label text-[#d7ffab]">Offline read lanes</p><p className="mt-3 text-3xl font-semibold">{mobileSummary?.offlineSupport.cachedRoutes.length ?? 0}</p><p className="mt-2 text-sm text-white/62">High-level metrics stay readable while live actions remain safely online-only.</p></div>
            </div>
            <div className="mt-4 flex flex-wrap gap-3">
              {mobileSummary?.pushEnabled ? <Button className="h-11 px-5" variant="secondary" onClick={() => void handleDisablePush()}>Turn off owner alerts</Button> : <Button className="h-11 px-5" variant="secondary" onClick={() => void handleEnablePush()}>Enable owner alerts</Button>}
              <span className="status-pill text-white/62">Marketplace highlights, trust alerts, and activation signals can now route through the mobile layer.</span>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
                <div className="flex items-center justify-between gap-3"><p className="surface-label">Shop verification upload</p><UploadCloud className="h-4 w-4 text-[#baff69]" /></div>
                <Input className="mt-4" value={shopDocumentName} onChange={(event) => setShopDocumentName(event.target.value)} />
                <Button className="mt-4 h-11 w-full" disabled={isPending} onClick={() => void handleShopVerification()}>{uploadMutation.isPending || submitShopVerificationMutation.isPending ? "Submitting verification..." : "Submit shop verification"}</Button>
              </div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
                <p className="surface-label">Launch-market controls</p>
                <div className="mt-4 space-y-3">
                  <Button className="h-11 w-full" variant="secondary" disabled={isPending} onClick={() => void handleFeaturedPlacement()}>{featureMutation.isPending ? "Scheduling featured slot..." : "Activate featured barber slot"}</Button>
                  <Button className="h-11 w-full" variant="secondary" disabled={isPending} onClick={() => void handleCityRollout()}>{rolloutMutation.isPending ? "Updating rollout..." : "Promote St. Pete to live"}</Button>
                </div>
              </div>
            </div>
            <div className="mt-4 space-y-3">{activation?.boostCampaigns.length ? activation.boostCampaigns.slice(0, 3).map((campaign) => <div key={campaign.id} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4"><div className="flex items-center justify-between gap-3"><p className="font-medium">{campaign.placementLabel}</p><span className="status-pill text-[#d7ffab]">{currency(campaign.spendCents / 100)}</span></div><p className="mt-2 text-sm text-white/58">{campaign.trustReason}</p></div>) : <div className="empty-state-panel rounded-[22px] p-5 text-sm text-white/58">Boost campaigns will appear here once premium placement inventory is active.</div>}</div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">{activation?.topMarkets.map((market) => <div key={market.citySlug} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4"><div className="flex items-center justify-between gap-3"><p className="font-medium">{market.cityLabel}</p><span className="status-pill text-[#d7ffab]">{market.activationState}</span></div><p className="mt-2 text-sm text-white/58">Density {market.densityScore}</p></div>)}</div>
          </Card>
        </section>
      ) : null}
    </section>
  );
}
