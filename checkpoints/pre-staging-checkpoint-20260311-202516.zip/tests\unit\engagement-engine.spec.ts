import { describe, expect, it } from "vitest";
import {
  EngagementPermissionError,
  createInitialEngagementState,
  followBarber,
  getBarberEngagementSummary,
  getClientEngagementSummary,
  getOwnerIntelligenceSummary,
  recordEngagementEvent
} from "@/lib/engagement/engine";
import { createInitialLiveOperationsSnapshot } from "@/lib/operations/live-state";

describe("engagement engine", () => {
  it("creates barber follows and queues a notification hook", () => {
    const state = createInitialEngagementState();
    const result = followBarber(state, {
      role: "client",
      clientId: "client-jordan",
      userEmail: "client@bvrb3r.demo",
      locationIds: ["loc-ybor"]
    }, {
      barberId: "barber-fade",
      notifyOnAvailability: true,
      notifyOnPortfolio: true
    });

    expect(result.follow.barberId).toBe("barber-fade");
    expect(result.state.barberFollows.some((follow) => follow.clientId === "client-jordan" && follow.barberId === "barber-fade")).toBe(true);
    expect(result.notification.type).toBe("new_follower");
  });

  it("awards loyalty points for a barber review event", () => {
    const state = createInitialEngagementState();
    const result = recordEngagementEvent(state, {
      role: "client",
      clientId: "client-jordan",
      userEmail: "client@bvrb3r.demo",
      locationIds: ["loc-ybor"]
    }, {
      eventType: "barber_reviewed",
      targetType: "barber",
      targetId: "barber-wave",
      metadata: { rating: 5 }
    });

    const account = result.state.loyaltyAccounts.find((entry) => entry.clientId === "client-jordan");
    expect(account?.pointsBalance).toBeGreaterThan(state.loyaltyAccounts.find((entry) => entry.clientId === "client-jordan")?.pointsBalance ?? 0);
    expect(result.state.notifications.some((notification) => notification.type === "review_alert" && notification.barberId === "barber-wave")).toBe(true);
  });

  it("blocks disallowed engagement events by role", () => {
    const state = createInitialEngagementState();

    expect(() => recordEngagementEvent(state, {
      role: "client",
      clientId: "client-jordan",
      userEmail: "client@bvrb3r.demo"
    }, {
      eventType: "payout_released",
      targetType: "barber",
      targetId: "barber-wave"
    })).toThrow(EngagementPermissionError);
  });

  it("builds the client engagement summary with rebooking and rewards", () => {
    const snapshot = createInitialLiveOperationsSnapshot();
    const summary = getClientEngagementSummary(createInitialEngagementState(), snapshot, "client-jordan");

    expect(summary.rebookingRecommendation).not.toBeNull();
    expect(summary.followedBarbers.length).toBeGreaterThan(0);
    expect(summary.rewards.some((reward) => reward.unlocked)).toBe(true);
  });

  it("builds the barber engagement summary with earnings and growth recommendations", () => {
    const snapshot = createInitialLiveOperationsSnapshot();
    const summary = getBarberEngagementSummary(createInitialEngagementState(), snapshot, "barber-wave");

    expect(summary.earnings.today).toBeGreaterThanOrEqual(0);
    expect(summary.rankings.length).toBeGreaterThan(0);
    expect(summary.growthRecommendations.length).toBeGreaterThan(0);
  });

  it("builds owner intelligence with loyalty and referral signals", () => {
    const snapshot = createInitialLiveOperationsSnapshot();
    const summary = getOwnerIntelligenceSummary(createInitialEngagementState(), snapshot, ["loc-ybor", "loc-hyde"]);

    expect(summary.retention.loyaltyParticipants).toBeGreaterThan(0);
    expect(summary.retention.referralConversions).toBeGreaterThan(0);
    expect(summary.topBarbers.length).toBeGreaterThan(0);
  });
});