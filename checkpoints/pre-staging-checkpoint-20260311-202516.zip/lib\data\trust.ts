import type { BarberVerificationRecord, DisputeEventRecord, DisputeRecord, ModerationActionRecord, ReliabilityScoreRecord, ReportEventRecord, ReviewModerationRecord, RiskFlagRecord, SafetyReportRecord, ShopVerificationRecord, TrustBadgeRecord, VerificationDocumentRecord } from "@/types/trust";

export const demoBarberVerifications: BarberVerificationRecord[] = [
  { id: "verify-wave-identity", barberId: "barber-wave", category: "identity_verification", legalName: "Wave Carter", verificationStatus: "verified", verificationSubmittedAt: "2026-02-10T09:00:00-05:00", verificationReviewedAt: "2026-02-10T15:30:00-05:00", verificationNotes: "Identity match approved.", documentPath: "verification/barber-wave/identity.pdf", updatedAt: "2026-02-10T15:30:00-05:00" },
  { id: "verify-wave-license", barberId: "barber-wave", category: "license_verification", legalName: "Wave Carter", licenseType: "Florida Barber License", licenseNumber: "FL-BR-884201", issuingState: "FL", expirationDate: "2027-06-30", verificationStatus: "verified", verificationSubmittedAt: "2026-02-10T09:10:00-05:00", verificationReviewedAt: "2026-02-10T16:00:00-05:00", verificationNotes: "License verified and current.", documentPath: "verification/barber-wave/license.pdf", updatedAt: "2026-02-10T16:00:00-05:00" },
  { id: "verify-wave-payout", barberId: "barber-wave", category: "payout_verification", legalName: "Wave Carter", verificationStatus: "verified", verificationSubmittedAt: "2026-02-10T09:20:00-05:00", verificationReviewedAt: "2026-02-11T10:00:00-05:00", verificationNotes: "Payout profile cleared.", updatedAt: "2026-02-11T10:00:00-05:00" },
  { id: "verify-wave-shop", barberId: "barber-wave", category: "shop_affiliation_verification", legalName: "Wave Carter", verificationStatus: "verified", verificationSubmittedAt: "2026-02-10T09:25:00-05:00", verificationReviewedAt: "2026-02-11T10:05:00-05:00", verificationNotes: "Affiliation confirmed with The BVRB3R Shop(TM).", updatedAt: "2026-02-11T10:05:00-05:00" },
  { id: "verify-fade-identity", barberId: "barber-fade", category: "identity_verification", legalName: "Fade Monroe", verificationStatus: "pending", verificationSubmittedAt: "2026-03-06T11:10:00-05:00", verificationNotes: "Waiting on manual identity review.", documentPath: "verification/barber-fade/identity.pdf", updatedAt: "2026-03-06T11:10:00-05:00" },
  { id: "verify-fade-license", barberId: "barber-fade", category: "license_verification", legalName: "Fade Monroe", licenseType: "Florida Barber License", licenseNumber: "FL-BR-781144", issuingState: "FL", expirationDate: "2026-11-30", verificationStatus: "verified", verificationSubmittedAt: "2026-02-18T09:00:00-05:00", verificationReviewedAt: "2026-02-18T14:20:00-05:00", verificationNotes: "License current.", updatedAt: "2026-02-18T14:20:00-05:00" },
  { id: "verify-blaze-identity", barberId: "barber-blaze", category: "identity_verification", legalName: "Blaze King", verificationStatus: "verified", verificationSubmittedAt: "2026-02-08T08:30:00-05:00", verificationReviewedAt: "2026-02-08T13:20:00-05:00", verificationNotes: "Identity verified.", updatedAt: "2026-02-08T13:20:00-05:00" },
  { id: "verify-blaze-license", barberId: "barber-blaze", category: "license_verification", legalName: "Blaze King", licenseType: "Florida Barber License", licenseNumber: "FL-BR-902713", issuingState: "FL", expirationDate: "2027-04-30", verificationStatus: "verified", verificationSubmittedAt: "2026-02-08T08:35:00-05:00", verificationReviewedAt: "2026-02-08T13:30:00-05:00", verificationNotes: "License approved.", updatedAt: "2026-02-08T13:30:00-05:00" },
  { id: "verify-blaze-payout", barberId: "barber-blaze", category: "payout_verification", legalName: "Blaze King", verificationStatus: "verified", verificationSubmittedAt: "2026-02-08T08:45:00-05:00", verificationReviewedAt: "2026-02-09T09:10:00-05:00", verificationNotes: "Payout routing approved.", updatedAt: "2026-02-09T09:10:00-05:00" },
  { id: "verify-blaze-shop", barberId: "barber-blaze", category: "shop_affiliation_verification", legalName: "Blaze King", verificationStatus: "verified", verificationSubmittedAt: "2026-02-08T08:50:00-05:00", verificationReviewedAt: "2026-02-09T09:15:00-05:00", verificationNotes: "Affiliation confirmed with flagship floor.", updatedAt: "2026-02-09T09:15:00-05:00" },
  { id: "verify-luxe-identity", barberId: "barber-luxe", category: "identity_verification", legalName: "Luxe Reed", verificationStatus: "verified", verificationSubmittedAt: "2026-02-12T09:15:00-05:00", verificationReviewedAt: "2026-02-12T16:00:00-05:00", verificationNotes: "Identity approved.", updatedAt: "2026-02-12T16:00:00-05:00" },
  { id: "verify-luxe-license", barberId: "barber-luxe", category: "license_verification", legalName: "Luxe Reed", licenseType: "Florida Barber License", licenseNumber: "FL-BR-664120", issuingState: "FL", expirationDate: "2026-12-31", verificationStatus: "verified", verificationSubmittedAt: "2026-02-12T09:20:00-05:00", verificationReviewedAt: "2026-02-12T16:10:00-05:00", verificationNotes: "License confirmed.", updatedAt: "2026-02-12T16:10:00-05:00" }
];

export const demoShopVerifications: ShopVerificationRecord[] = [
  { id: "shop-verify-business", shopId: "shop-bvrb3r", category: "business_verification", businessName: "The BVRB3R Shop(TM) & Co.", verificationStatus: "verified", verificationSubmittedAt: "2026-01-15T10:00:00-05:00", verificationReviewedAt: "2026-01-18T13:00:00-05:00", verificationNotes: "Business registration confirmed.", documentPath: "verification/shop-bvrb3r/business.pdf", updatedAt: "2026-01-18T13:00:00-05:00" },
  { id: "shop-verify-ownership", shopId: "shop-bvrb3r", category: "ownership_verification", businessName: "The BVRB3R Shop(TM) & Co.", verificationStatus: "verified", verificationSubmittedAt: "2026-01-15T10:20:00-05:00", verificationReviewedAt: "2026-01-18T14:15:00-05:00", verificationNotes: "Ownership documentation approved.", documentPath: "verification/shop-bvrb3r/ownership.pdf", updatedAt: "2026-01-18T14:15:00-05:00" }
];

export const demoVerificationDocuments: VerificationDocumentRecord[] = [
  { id: "doc-wave-license", ownerType: "barber", ownerId: "barber-wave", category: "license_verification", storagePath: "verification/barber-wave/license.pdf", uploadedAt: "2026-02-10T09:10:00-05:00", expiresAt: "2027-06-30" },
  { id: "doc-fade-identity", ownerType: "barber", ownerId: "barber-fade", category: "identity_verification", storagePath: "verification/barber-fade/identity.pdf", uploadedAt: "2026-03-06T11:10:00-05:00" },
  { id: "doc-shop-business", ownerType: "shop", ownerId: "shop-bvrb3r", category: "business_verification", storagePath: "verification/shop-bvrb3r/business.pdf", uploadedAt: "2026-01-15T10:00:00-05:00" }
];

export const demoTrustBadges: TrustBadgeRecord[] = [
  { id: "badge-wave-trusted", scopeType: "barber", scopeId: "barber-wave", badge: "trusted_pro", label: "Trusted Pro", publicVisible: true, grantedAt: "2026-02-15T10:00:00-05:00" },
  { id: "badge-blaze-trusted", scopeType: "barber", scopeId: "barber-blaze", badge: "trusted_pro", label: "Trusted Pro", publicVisible: true, grantedAt: "2026-02-16T10:00:00-05:00" },
  { id: "badge-shop-verified", scopeType: "shop", scopeId: "shop-bvrb3r", badge: "verified_shop", label: "Verified Shop", publicVisible: true, grantedAt: "2026-01-18T14:20:00-05:00" },
  { id: "badge-fade-rising", scopeType: "barber", scopeId: "barber-fade", badge: "rising_barber", label: "Rising Barber", publicVisible: true, grantedAt: "2026-03-03T10:00:00-05:00" }
];

export const demoReviewModeration: ReviewModerationRecord[] = [
  { id: "review-mod-1", reviewId: "review-1", barberId: "barber-wave", clientId: "client-jordan", appointmentId: "appt-1", eligible: true, moderationStatus: "approved", suspiciousFlags: [], abuseReported: false, integrityScore: 99, reviewedAt: "2026-03-06T13:00:00-05:00", createdAt: "2026-03-06T12:30:00-05:00", updatedAt: "2026-03-06T13:00:00-05:00" },
  { id: "review-mod-2", reviewId: "review-2", barberId: "barber-blaze", clientId: "client-nova", appointmentId: "appt-4", eligible: true, moderationStatus: "approved", suspiciousFlags: [], abuseReported: false, integrityScore: 98, reviewedAt: "2026-03-05T15:20:00-05:00", createdAt: "2026-03-05T15:00:00-05:00", updatedAt: "2026-03-05T15:20:00-05:00" },
  { id: "review-mod-3", reviewId: "review-3", barberId: "barber-fade", clientId: "client-malik", appointmentId: "appt-5", eligible: true, moderationStatus: "approved", suspiciousFlags: [], abuseReported: false, integrityScore: 95, reviewedAt: "2026-03-02T11:15:00-05:00", createdAt: "2026-03-02T11:00:00-05:00", updatedAt: "2026-03-02T11:15:00-05:00" },
  { id: "review-mod-4", reviewId: "review-4", barberId: "barber-luxe", clientId: "client-zoe", appointmentId: "appt-7", eligible: true, moderationStatus: "approved", suspiciousFlags: [], abuseReported: false, integrityScore: 92, reviewedAt: "2026-03-01T17:10:00-05:00", createdAt: "2026-03-01T16:50:00-05:00", updatedAt: "2026-03-01T17:10:00-05:00" },
  { id: "review-mod-fade-watch", reviewId: "review-flagged-demo", barberId: "barber-fade", clientId: "client-sage", eligible: false, moderationStatus: "flagged", suspiciousFlags: ["duplicate_pattern", "no_completed_booking_match"], abuseReported: true, integrityScore: 52, reviewedAt: "2026-03-07T10:30:00-05:00", createdAt: "2026-03-07T10:00:00-05:00", updatedAt: "2026-03-07T10:30:00-05:00" }
];

export const demoSafetyReports: SafetyReportRecord[] = [
  { id: "report-no-show-lyric", reporterRole: "owner", reporterId: "user-owner", reporterEmail: "owner@bvrb3r.demo", subjectType: "client", subjectId: "client-lyric", category: "no_show_abuse", details: "Repeated late cancellations and a recent no-show are being tracked before stronger booking restrictions are applied.", status: "open", locationId: "loc-ybor", createdAt: "2026-03-07T18:25:00-05:00", updatedAt: "2026-03-07T18:25:00-05:00" },
  { id: "report-booking-dispute-ava", reporterRole: "client", reporterId: "client-ava", reporterEmail: "ava@example.com", subjectType: "booking", subjectId: "appt-7", category: "payment_dispute", details: "Client asked for review of a timing mismatch between confirmation and service completion notes.", status: "under_review", locationId: "loc-hyde", createdAt: "2026-03-08T09:40:00-05:00", updatedAt: "2026-03-08T10:05:00-05:00" }
];
export const demoReportEvents: ReportEventRecord[] = [
  { id: "report-event-1", reportId: "report-no-show-lyric", actorRole: "owner", actorId: "user-owner", actionLabel: "Case opened", notes: "Watchlist created for repeated no-show behavior.", createdAt: "2026-03-07T18:26:00-05:00" },
  { id: "report-event-2", reportId: "report-booking-dispute-ava", actorRole: "owner", actorId: "user-owner", actionLabel: "Review started", notes: "Payment and service notes pulled for moderation review.", createdAt: "2026-03-08T10:06:00-05:00" }
];
export const demoDisputes: DisputeRecord[] = [
  { id: "dispute-no-show-lyric", disputeType: "no_show", disputeStatus: "under_review", submittedByRole: "client", submittedById: "client-lyric", involvedPartyType: "booking", involvedPartyId: "appt-8", appointmentId: "appt-8", locationId: "loc-ybor", summary: "Client is asking for a courtesy review of retained deposit policy after a no-show.", createdAt: "2026-03-08T08:15:00-05:00", updatedAt: "2026-03-08T09:30:00-05:00" },
  { id: "dispute-quality-zoe", disputeType: "service_quality", disputeStatus: "resolved", submittedByRole: "client", submittedById: "client-zoe", involvedPartyType: "barber", involvedPartyId: "barber-luxe", appointmentId: "appt-7", locationId: "loc-hyde", summary: "Client requested a post-service credit review around confirmation timing.", resolutionNotes: "Owner approved courtesy add-on credit instead of refund.", createdAt: "2026-03-02T09:00:00-05:00", updatedAt: "2026-03-03T11:00:00-05:00" }
];
export const demoDisputeEvents: DisputeEventRecord[] = [
  { id: "dispute-event-1", disputeId: "dispute-no-show-lyric", actorRole: "owner", actorId: "user-owner", actionLabel: "Policy review opened", notes: "Deposit retention policy and reminder logs attached.", createdAt: "2026-03-08T09:31:00-05:00" },
  { id: "dispute-event-2", disputeId: "dispute-quality-zoe", actorRole: "owner", actorId: "user-owner", actionLabel: "Resolved with courtesy credit", notes: "No refund processed. Client retained.", createdAt: "2026-03-03T11:00:00-05:00" }
];
export const demoRiskFlags: RiskFlagRecord[] = [
  { id: "risk-client-lyric", entityType: "client", entityId: "client-lyric", signalType: "repeated_no_show", severity: "high", score: 82, publicImpact: false, open: true, notes: "Two recent late cancellations plus one retained-deposit no-show.", createdAt: "2026-03-07T18:20:00-05:00" },
  { id: "risk-review-fade", entityType: "review", entityId: "review-flagged-demo", signalType: "suspicious_review_pattern", severity: "medium", score: 58, publicImpact: true, open: true, notes: "Flagged review pattern held out of ranking until manually cleared.", createdAt: "2026-03-07T10:30:00-05:00" }
];
export const demoModerationActions: ModerationActionRecord[] = [
  { id: "moderation-action-1", targetType: "review", targetId: "review-flagged-demo", actionLabel: "Held from public display", actorRole: "platform", actorId: "trust-ops", createdAt: "2026-03-07T10:35:00-05:00" },
  { id: "moderation-action-2", targetType: "dispute", targetId: "dispute-quality-zoe", actionLabel: "Closed with courtesy resolution", actorRole: "owner", actorId: "user-owner", createdAt: "2026-03-03T11:00:00-05:00" }
];
export const demoReliabilityScores: ReliabilityScoreRecord[] = [
  { barberId: "barber-wave", completionRate: 98, onTimeRate: 97, rebookingRate: 84, reviewIntegrityScore: 99, overallTrustScore: 96, updatedAt: "2026-03-08T18:00:00-05:00" },
  { barberId: "barber-fade", completionRate: 91, onTimeRate: 89, rebookingRate: 68, reviewIntegrityScore: 81, overallTrustScore: 82, updatedAt: "2026-03-08T18:00:00-05:00" },
  { barberId: "barber-blaze", completionRate: 97, onTimeRate: 95, rebookingRate: 80, reviewIntegrityScore: 98, overallTrustScore: 94, updatedAt: "2026-03-08T18:00:00-05:00" },
  { barberId: "barber-luxe", completionRate: 93, onTimeRate: 90, rebookingRate: 74, reviewIntegrityScore: 92, overallTrustScore: 88, updatedAt: "2026-03-08T18:00:00-05:00" }
];
