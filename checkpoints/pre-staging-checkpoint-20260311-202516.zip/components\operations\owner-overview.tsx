"use client";

import { ArrowUpRight, Building2, ReceiptText, ShieldCheck, TriangleAlert, WalletCards } from "lucide-react";
import { RevenueChart } from "@/components/dashboard/revenue-chart";
import { OwnerIntelligencePanel } from "@/components/engagement/owner-intelligence-panel";
import { StatCard } from "@/components/dashboard/stat-card";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { auditLogs, boothRentLedger, demoBarbers, demoLocations } from "@/lib/data/demo";
import { useLiveOperationsSnapshot } from "@/lib/operations/live-client";
import { buildOwnerRevenueSeriesFromAnalytics, getOwnerAnalyticsSummary } from "@/lib/operations/metrics";
import { currency } from "@/lib/utils";

function MetricSkeleton() {
  return (
    <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
      <Skeleton className="h-3 w-24" />
      <Skeleton className="mt-4 h-10 w-20" />
      <Skeleton className="mt-4 h-4 w-32" />
    </div>
  );
}

export function OwnerOverview() {
  const operationsQuery = useLiveOperationsSnapshot("owner");
  const ownerAnalytics = operationsQuery.data?.ownerAnalytics ?? [];
  const workflowEvents = operationsQuery.data?.workflowEvents ?? [];
  const metrics = getOwnerAnalyticsSummary(ownerAnalytics);
  const series = buildOwnerRevenueSeriesFromAnalytics(ownerAnalytics);
  const modeLabel = operationsQuery.data?.mode === "supabase" ? "Supabase realtime active" : "Quick-start demo state";
  const pendingPayoutTotal = demoBarbers
    .filter((barber) => barber.compensationModel === "commission")
    .reduce((sum, barber) => sum + (barber.upcomingPayout ?? 0), 0);
  const openRentEntries = boothRentLedger.filter((entry) => entry.status !== "paid");
  const overdueRentCount = boothRentLedger.filter((entry) => entry.status === "overdue").length;
  const rentExposure = openRentEntries.reduce((sum, entry) => sum + entry.amount, 0);
  const locationPerformance = demoLocations
    .map((location) => {
      const row = ownerAnalytics.find((entry) => entry.locationReference === location.id && entry.businessDate === metrics.businessDate);

      return {
        location,
        revenue: row?.revenueTotal ?? 0,
        completed: row?.completedServicesCount ?? 0,
        outstanding: row?.outstandingBalance ?? 0
      };
    })
    .sort((left, right) => right.revenue - left.revenue);
  const isInitialLoading = operationsQuery.isLoading && !operationsQuery.data;

  return (
    <div className="space-y-4" data-testid="owner-overview">
      <section className="grid gap-4 xl:grid-cols-[1.15fr_0.85fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="surface-label">Executive snapshot</p>
              {isInitialLoading ? <Skeleton className="mt-3 h-14 w-48" /> : <h3 className="mt-3 text-4xl font-semibold sm:text-5xl" data-display="true">{currency(metrics.revenueToday)}</h3>}
              <p className="mt-3 max-w-2xl text-sm leading-7 text-white/62">
                Today&apos;s posted revenue across the business. Checkout activity, compensation snapshots, and owner analytics are reading from persisted operations data.
              </p>
            </div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 px-4 py-4 text-sm text-white/68">
              <div className="inline-flex items-center gap-2 rounded-full border border-[#7CFF00]/20 bg-[#7CFF00]/10 px-3 py-2 text-[10px] uppercase tracking-[0.24em] text-[#d7ffab]">
                <ShieldCheck className="h-4 w-4" />
                {modeLabel}
              </div>
              <p className="mt-4 text-[11px] uppercase tracking-[0.22em] text-white/42">Business date {metrics.businessDate}</p>
            </div>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {isInitialLoading ? (
              <>
                <MetricSkeleton />
                <MetricSkeleton />
                <MetricSkeleton />
              </>
            ) : (
              <>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                  <p className="surface-label">Completed services</p>
                  <p className="mt-3 text-3xl font-semibold" data-display="true">{metrics.completedServicesToday}</p>
                  <p className="mt-2 text-sm text-white/58">Paid tickets {metrics.paidAppointmentsToday}</p>
                </div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                  <p className="surface-label">Tips captured</p>
                  <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.tipsToday)}</p>
                  <p className="mt-2 text-sm text-white/58">Guest spend is landing cleanly</p>
                </div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                  <p className="surface-label">Open exposure</p>
                  <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.outstandingBalance)}</p>
                  <p className="mt-2 text-sm text-white/58">Booked tickets still waiting on final capture</p>
                </div>
              </>
            )}
          </div>
        </Card>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-1">
          {isInitialLoading ? (
            <>
              <MetricSkeleton />
              <MetricSkeleton />
              <MetricSkeleton />
            </>
          ) : (
            <>
              <Card className="rounded-[32px] p-6">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="surface-label">Compensation watch</p>
                    <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(pendingPayoutTotal)}</p>
                    <p className="mt-2 text-sm leading-6 text-white/60">Pending commission payouts across the team, separate from booth-rent collections.</p>
                  </div>
                  <WalletCards className="h-5 w-5 text-[#baff69]" />
                </div>
              </Card>
              <Card className="rounded-[32px] p-6">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="surface-label">Booth-rent watch</p>
                    <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(rentExposure)}</p>
                    <p className="mt-2 text-sm leading-6 text-white/60">{openRentEntries.length} ledger entries open, including {overdueRentCount} overdue item{overdueRentCount === 1 ? "" : "s"}.</p>
                  </div>
                  <ReceiptText className="h-5 w-5 text-[#baff69]" />
                </div>
              </Card>
              <Card className="rounded-[32px] p-6">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="surface-label">Owner-only controls</p>
                    <p className="mt-3 text-lg font-semibold">Billing, permissions, compensation rules, and structural settings stay grouped here.</p>
                    <p className="mt-3 text-sm leading-6 text-white/58">Managers can run the shop. Only ownership can change financial policy and protected configuration.</p>
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-[#d7ffab]" />
                </div>
              </Card>
            </>
          )}
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {isInitialLoading ? (
          <>
            <MetricSkeleton />
            <MetricSkeleton />
            <MetricSkeleton />
            <MetricSkeleton />
          </>
        ) : (
          <>
            <StatCard label="Revenue today" value={currency(metrics.revenueToday)} detail={`${metrics.completedServicesToday} completed services posted today`} />
            <StatCard label="Tips today" value={currency(metrics.tipsToday)} detail={`${metrics.paidAppointmentsToday} paid appointments closed cleanly`} />
            <StatCard label="Balance still open" value={currency(metrics.outstandingBalance)} detail={`${metrics.bookedToday} booked or open tickets still in motion`} />
            <StatCard label="Active locations" value={String(locationPerformance.length)} detail="Owner view spans every assigned shop footprint" />
          </>
        )}
      </section>

      <OwnerIntelligencePanel />

      <section className="grid gap-4 xl:grid-cols-[1.05fr_0.95fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="surface-label">Revenue activity</p>
              <p className="mt-2 text-sm text-white/58">The seven-day curve shows persisted owner analytics rather than local-only dashboard math.</p>
            </div>
            <span className="status-pill text-[#d7ffab]">Executive reporting live</span>
          </div>
          <div className="mt-6">
            {isInitialLoading ? (
              <div className="rounded-[24px] border border-white/8 bg-black/20 p-6">
                <Skeleton className="h-44 w-full rounded-[24px]" />
              </div>
            ) : (
              <RevenueChart data={series} />
            )}
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Location performance</p>
            <Building2 className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 space-y-3">
            {isInitialLoading ? (
              <>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><Skeleton className="h-24 w-full" /></div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><Skeleton className="h-24 w-full" /></div>
              </>
            ) : locationPerformance.map((entry) => (
              <div key={entry.location.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="text-lg font-semibold">{entry.location.name}</p>
                    <p className="mt-1 text-sm text-white/55">{entry.location.neighborhood}, {entry.location.city}</p>
                  </div>
                  <span className="status-pill text-[#d7ffab]">{entry.completed} completed</span>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-[20px] border border-white/8 bg-black/25 p-3">
                    <p className="surface-label">Revenue</p>
                    <p className="mt-2 text-2xl font-semibold" data-display="true">{currency(entry.revenue)}</p>
                  </div>
                  <div className="rounded-[20px] border border-white/8 bg-black/25 p-3">
                    <p className="surface-label">Outstanding</p>
                    <p className="mt-2 text-2xl font-semibold" data-display="true">{currency(entry.outstanding)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </section>

      <section className="grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="surface-label">Operational alerts</p>
            <TriangleAlert className="h-5 w-5 text-amber-300" />
          </div>
          <div className="mt-4 space-y-3">
            <div className="rounded-[24px] border border-amber-400/18 bg-amber-400/10 p-4">
              <p className="text-sm font-medium text-amber-100">{overdueRentCount} rent ledger item{overdueRentCount === 1 ? "" : "s"} need owner visibility.</p>
              <p className="mt-2 text-sm text-amber-50/72">Booth-rent exposure stays separated from commission payout obligations.</p>
            </div>
            {auditLogs.slice(0, 3).map((log) => (
              <div key={log.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="font-medium">{log.action}</p>
                  <span className="status-pill text-[#d7ffab]">{log.severity}</span>
                </div>
                <p className="mt-2 text-sm text-white/58">{log.actor} | {log.target}</p>
                <p className="mt-3 text-[11px] uppercase tracking-[0.22em] text-white/38">{log.createdAt}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <p className="surface-label">Recent revenue-driving activity</p>
          <div className="mt-4 space-y-3">
            {isInitialLoading ? (
              <>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><Skeleton className="h-20 w-full" /></div>
                <div className="rounded-[24px] border border-white/8 bg-black/20 p-4"><Skeleton className="h-20 w-full" /></div>
              </>
            ) : workflowEvents.length ? workflowEvents.slice(0, 6).map((activity) => (
              <div key={`${activity.appointmentReference}-${activity.createdAt}`} className="rounded-[24px] border border-white/8 bg-black/20 p-4 transition hover:border-[#7CFF00]/16 hover:bg-black/30">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <p className="font-medium">{activity.title}</p>
                  <span className="status-pill text-[#d7ffab]">{activity.actorRole.replaceAll("_", " ")}</span>
                </div>
                <p className="mt-2 text-sm text-white/58">{activity.detail}</p>
                <p className="mt-3 text-[11px] uppercase tracking-[0.22em] text-white/38">{activity.createdAt}</p>
              </div>
            )) : (
              <div className="empty-state-panel rounded-[24px] p-5 text-sm leading-7 text-white/58">
                New bookings, check-ins, completions, and checkouts will stack here as the operating loop runs through the shop.
              </div>
            )}
          </div>
        </Card>
      </section>
    </div>
  );
}