import { describe, expect, it } from "vitest";
import {
  MarketplacePermissionError,
  createInitialMarketplaceState,
  createServiceDefinition,
  getHaircutNowMatch,
  getPublicBarberProfileByUsername,
  searchMarketplace,
  updateServiceDefinition
} from "@/lib/marketplace/engine";

describe("marketplace engine", () => {
  it("lets the owner update a shop-owned commission service", () => {
    const state = createInitialMarketplaceState();
    const result = updateServiceDefinition(state, { role: "owner" }, "srv-signature", {
      price: 59,
      description: "Sharper premium cut experience."
    });

    expect(result.service.ownerType).toBe("shop");
    expect(result.service.price).toBe(59);
    expect(result.service.description).toContain("Sharper premium cut");
  });

  it("lets a booth-rent barber create and edit a self-owned service", () => {
    const state = createInitialMarketplaceState();
    const created = createServiceDefinition(state, { role: "booth_rent_barber", barberId: "barber-blaze" }, {
      category: "Haircuts",
      name: "Blaze Late Night Detail",
      description: "After-hours premium cleanup.",
      durationMin: 45,
      bufferMin: 5,
      price: 72,
      deposit: 18,
      fullPrepay: false,
      styleTagIds: ["style-executive"]
    });
    const updated = updateServiceDefinition(created.state, { role: "booth_rent_barber", barberId: "barber-blaze" }, created.service.id, {
      price: 76,
      description: "After-hours premium cleanup with hot towel finish."
    });

    expect(created.service.ownerType).toBe("barber");
    expect(created.service.barberId).toBe("barber-blaze");
    expect(updated.service.price).toBe(76);
    expect(updated.service.description).toContain("hot towel");
  });

  it("blocks commission barbers from creating services", () => {
    const state = createInitialMarketplaceState();

    expect(() => createServiceDefinition(state, { role: "commission_barber", barberId: "barber-wave" }, {
      category: "Haircuts",
      name: "Unauthorized Service",
      description: "Should not be allowed.",
      durationMin: 45,
      bufferMin: 5,
      price: 65,
      deposit: 15,
      fullPrepay: false,
      styleTagIds: []
    })).toThrow(MarketplacePermissionError);
  });

  it("blocks managers from editing service definitions", () => {
    const state = createInitialMarketplaceState();

    expect(() => updateServiceDefinition(state, { role: "manager" }, "srv-signature", {
      price: 61
    })).toThrow(MarketplacePermissionError);
  });

  it("resolves the public barber profile with the most booked service", () => {
    const state = createInitialMarketplaceState();
    const profile = getPublicBarberProfileByUsername(state, "wave");

    expect(profile).not.toBeNull();
    expect(profile?.barber.name).toBe("Wave Carter");
    expect(profile?.mostBookedService?.service.name).toBe("Signature Precision Cut");
  });

  it("returns discovery results for service and location searches", () => {
    const state = createInitialMarketplaceState();
    const results = searchMarketplace(state, {
      query: "kids haircut",
      locationId: "loc-hyde"
    });

    expect(results.some((result) => result.username === "fade")).toBe(true);
  });

  it("prioritizes the favorite barber for haircut now", () => {
    const state = createInitialMarketplaceState();
    const match = getHaircutNowMatch(state, "client-jordan", "loc-ybor");

    expect(match).not.toBeNull();
    expect(match?.matchedFrom).toBe("favorite_barber");
    expect(match?.username).toBe("wave");
  });
});