import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { RevenueChart } from "@/components/dashboard/revenue-chart";
import { Card } from "@/components/ui/card";
import { getAuthorizedUser } from "@/lib/auth/guards";
import { demoReviews, revenueSeries } from "@/lib/data/demo";

export default async function ReportsPage() {
  const user = await getAuthorizedUser(["owner", "manager"]);
  return (
    <DashboardShell user={user} activeHref="/reports" title="Reports and analytics" subtitle="Revenue, traffic, reviews, and performance snapshots across the business.">
      <section className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="rounded-[32px] p-6">
          <p className="surface-label">Revenue by day</p>
          <p className="mt-2 text-sm text-white/58">High-level trend visibility for leadership without leaving the reporting lane.</p>
          <div className="mt-6"><RevenueChart data={revenueSeries} /></div>
        </Card>
        <Card className="rounded-[32px] p-6">
          <p className="surface-label">Review trends</p>
          <div className="mt-4 space-y-3">
            {demoReviews.map((review) => (
              <div key={review.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                <p className="font-medium">{review.rating} stars | {review.sentiment}</p>
                <p className="mt-2 text-sm text-white/65">{review.message}</p>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </DashboardShell>
  );
}