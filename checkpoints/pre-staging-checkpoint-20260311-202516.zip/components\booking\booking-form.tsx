"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useSearchParams } from "next/navigation";
import { z } from "zod";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FeedbackBanner } from "@/components/ui/feedback-banner";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { demoBarbers, demoLocations, demoServices } from "@/lib/data/demo";
import { demoBarberProfiles } from "@/lib/data/marketplace";
import { useBookingStore } from "@/lib/data/booking-store";
import { useMarketplaceAnalyticsMutation, useMarketplaceWaitlistMutation } from "@/lib/marketplace/client";
import { useBookAppointmentMutation, useLiveOperationsSnapshot } from "@/lib/operations/live-client";
import { calculateBookingQuote, getSuggestedTimeSlots } from "@/lib/utils/booking";
import { getReadableActionError } from "@/lib/utils/feedback";
import { currency, dateLabel } from "@/lib/utils";
import type { HaircutNowMatch, MarketplaceSourceKind } from "@/types/domain";

const bookingSchema = z.object({
  locationId: z.string().min(1),
  barberId: z.string().min(1),
  serviceId: z.string().min(1),
  addOnId: z.string().optional(),
  appointmentTime: z.string().min(1),
  clientName: z.string().min(2),
  clientPhone: z.string().min(10),
  acknowledgePolicy: z.boolean().refine((value) => value, "Please accept the cancellation policy.")
});

type BookingValues = z.infer<typeof bookingSchema>;

function QuoteRowSkeleton() {
  return (
    <div className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-3">
      <div className="flex items-center justify-between gap-3">
        <Skeleton className="h-4 w-28" />
        <Skeleton className="h-4 w-20" />
      </div>
    </div>
  );
}

function toMarketplaceSource(value: string | null): MarketplaceSourceKind | undefined {
  if (value === "direct" || value === "discovery" || value === "public_profile" || value === "haircut_now" || value === "client_dashboard") {
    return value;
  }

  return undefined;
}

function toMatchedFrom(value: string | null): HaircutNowMatch["matchedFrom"] | undefined {
  if (value === "favorite_barber" || value === "favorite_shop" || value === "nearby" || value === "available_now") {
    return value;
  }

  return undefined;
}

function getSourceLabel(sourceKind?: MarketplaceSourceKind) {
  switch (sourceKind) {
    case "public_profile":
      return "Barber profile booking";
    case "discovery":
      return "Discovery booking";
    case "haircut_now":
      return "Instant match booking";
    case "client_dashboard":
      return "Client dashboard booking";
    default:
      return "Direct booking";
  }
}

export function BookingForm() {
  const searchParams = useSearchParams();
  const { selectedLocationId, selectedBarberId, setLocation, setBarber } = useBookingStore();
  const operationsQuery = useLiveOperationsSnapshot("booking");
  const bookingMutation = useBookAppointmentMutation();
  const analyticsMutation = useMarketplaceAnalyticsMutation();
  const waitlistMutation = useMarketplaceWaitlistMutation();
  const ctaTrackedRef = useRef<string | null>(null);
  const [confirmationId, setConfirmationId] = useState("");
  const [statusUpdate, setStatusUpdate] = useState<{ tone: "success" | "info" | "error"; message: string } | null>(null);

  const sourceKind = toMarketplaceSource(searchParams.get("source"));
  const matchedFrom = toMatchedFrom(searchParams.get("matchedFrom"));
  const query = searchParams.get("query") ?? undefined;
  const preselectedLocationId = searchParams.get("locationId") ?? selectedLocationId;
  const preselectedBarberId = searchParams.get("barberId") ?? selectedBarberId;
  const preselectedUsername = searchParams.get("barber") ?? undefined;

  const form = useForm<BookingValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      locationId: preselectedLocationId,
      barberId: preselectedBarberId,
      serviceId: "srv-signature",
      addOnId: "srv-beard",
      appointmentTime: "2026-03-08T14:00:00-05:00",
      clientName: "Jordan Ellis",
      clientPhone: "8135550190",
      acknowledgePolicy: true
    }
  });

  useEffect(() => {
    if (preselectedLocationId && form.getValues("locationId") !== preselectedLocationId) {
      form.setValue("locationId", preselectedLocationId);
      setLocation(preselectedLocationId);
    }

    if (preselectedBarberId && form.getValues("barberId") !== preselectedBarberId) {
      form.setValue("barberId", preselectedBarberId);
      setBarber(preselectedBarberId);
    }
  }, [form, preselectedBarberId, preselectedLocationId, setBarber, setLocation]);

  useEffect(() => {
    if (!sourceKind || !preselectedBarberId) {
      return;
    }

    const trackingKey = `${sourceKind}:${preselectedBarberId}:${preselectedLocationId ?? "none"}:${query ?? "none"}`;
    if (ctaTrackedRef.current === trackingKey) {
      return;
    }

    ctaTrackedRef.current = trackingKey;
    if (typeof window !== "undefined") {
      const sessionKey = `bvrb3r-marketplace-cta:${trackingKey}`;
      if (window.sessionStorage.getItem(sessionKey)) {
        return;
      }
      window.sessionStorage.setItem(sessionKey, "1");
    }

    analyticsMutation.mutate({
      eventType: "booking_cta_clicked",
      barberId: preselectedBarberId,
      username: preselectedUsername,
      locationId: preselectedLocationId,
      sourceKind,
      sourceReference: preselectedUsername,
      metadata: {
        matchedFrom: matchedFrom ?? null,
        query: query ?? null
      }
    });
  }, [analyticsMutation, matchedFrom, preselectedBarberId, preselectedLocationId, preselectedUsername, query, sourceKind]);

  const watchService = form.watch("serviceId");
  const watchBarber = form.watch("barberId");
  const watchAddOn = form.watch("addOnId");

  const service = demoServices.find((entry) => entry.id === watchService) ?? demoServices[0];
  const addOns = demoServices.filter((entry) => entry.id === watchAddOn);
  const quote = calculateBookingQuote(service, addOns);
  const appointments = operationsQuery.data?.appointments ?? [];
  const suggestedSlots = getSuggestedTimeSlots(watchBarber, watchService, appointments);
  const availableSlots = suggestedSlots.length ? suggestedSlots : [form.getValues("appointmentTime") || "2026-03-08T17:00:00-05:00"];
  const runtimeLabel = operationsQuery.data?.mode === "supabase" ? "Supabase live mode" : "Quick-start demo mode";
  const isInitialLoading = operationsQuery.isLoading && !operationsQuery.data;
  const waitlistPending = waitlistMutation.isPending;
  const currentBarber = demoBarbers.find((entry) => entry.id === watchBarber);
  const currentProfile = demoBarberProfiles.find((entry) => entry.barberId === watchBarber);

  async function handleCreateBooking(values: BookingValues) {
    setStatusUpdate(null);
    setConfirmationId("");

    try {
      const result = await bookingMutation.mutateAsync({
        locationId: values.locationId,
        barberId: values.barberId,
        serviceId: values.serviceId,
        addOnIds: values.addOnId ? [values.addOnId] : [],
        appointmentTime: values.appointmentTime,
        clientName: values.clientName,
        clientPhone: values.clientPhone,
        sourceKind,
        matchedFrom,
        discoveryQuery: query,
        barberUsername: currentProfile?.username ?? preselectedUsername
      });

      setConfirmationId(result.appointment.id);
      setStatusUpdate({
        tone: "success",
        message: sourceKind
          ? "Marketplace booking confirmed. The appointment, attribution, and downstream owner/barber signals are now live."
          : "Appointment confirmed. Your booking is now live across front desk, barber, compensation, and owner views."
      });
    } catch (error) {
      setStatusUpdate({ tone: "error", message: getReadableActionError(error as { code?: string; status?: number; message?: string }) });
    }
  }

  async function handleJoinWaitlist() {
    setStatusUpdate(null);

    try {
      const result = await waitlistMutation.mutateAsync({
        barberId: form.getValues("barberId") || undefined,
        serviceId: form.getValues("serviceId"),
        locationId: form.getValues("locationId"),
        query
      });
      setStatusUpdate({
        tone: "info",
        message: `Waitlist joined. Request ${result.waitlist.id} is now persisted for reminders, instant-booking follow-up, and future availability matching.`
      });
    } catch (error) {
      setStatusUpdate({ tone: "error", message: getReadableActionError(error as { code?: string; status?: number; message?: string }) });
    }
  }

  return (
    <div className="grid gap-4 xl:grid-cols-[1.08fr_0.92fr]">
      <Card className="overflow-hidden rounded-[38px] p-0">
        <div className="border-b border-white/8 px-6 py-6 sm:px-8 sm:py-8">
          <div className="flex flex-wrap items-center gap-2">
            <Badge>Book with BVRB3R</Badge>
            {sourceKind ? <Badge>{getSourceLabel(sourceKind)}</Badge> : null}
          </div>
          <h2 className="mt-5 text-balance text-4xl font-semibold sm:text-5xl" data-display="true">Reserve your chair in minutes.</h2>
          <p className="mt-4 max-w-2xl text-base leading-7 text-white/68">
            Choose a barber, choose a service, lock a time, and confirm. The booking flow writes into the same live operational system the shop uses all day.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-2 text-[11px] uppercase tracking-[0.22em] text-white/48 sm:flex sm:flex-wrap">
            <span className="rounded-full border border-[#7CFF00]/20 bg-[#7CFF00]/10 px-3 py-2 text-[#d7ffab]">01 Choose barber</span>
            <span className="rounded-full border border-white/8 bg-black/25 px-3 py-2">02 Choose service</span>
            <span className="rounded-full border border-white/8 bg-black/25 px-3 py-2">03 Choose time</span>
            <span className="rounded-full border border-white/8 bg-black/25 px-3 py-2">04 Confirm booking</span>
          </div>
          <div className="mt-5 grid gap-3 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center">
            <div className="rounded-[24px] border border-white/8 bg-black/20 px-4 py-3 text-[11px] uppercase tracking-[0.22em] text-[#cfff93]">
              {runtimeLabel}
            </div>
            {currentBarber ? (
              <div className="rounded-[24px] border border-[#7CFF00]/16 bg-[#7CFF00]/8 px-4 py-3 text-sm text-white/78">
                Booking with <span className="text-[#d7ffab]">{currentBarber.name}</span>{matchedFrom ? ` via ${matchedFrom.replaceAll("_", " ")}` : ""}
              </div>
            ) : null}
          </div>
        </div>
        <form className="grid gap-4 p-5 sm:p-8 md:grid-cols-2" onSubmit={form.handleSubmit(handleCreateBooking)}>
          <div className="md:col-span-2">{statusUpdate ? <FeedbackBanner tone={statusUpdate.tone} message={statusUpdate.message} /> : null}</div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4 md:col-span-2">
            <label className="surface-label mb-3 block">Location</label>
            <Select
              {...form.register("locationId")}
              onChange={(event) => {
                form.setValue("locationId", event.target.value);
                setLocation(event.target.value);
              }}
            >
              {demoLocations.map((location) => (
                <option key={location.id} value={location.id}>{location.name}</option>
              ))}
            </Select>
          </div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4">
            <label className="surface-label mb-3 block">Barber</label>
            <Select
              {...form.register("barberId")}
              onChange={(event) => {
                form.setValue("barberId", event.target.value);
                setBarber(event.target.value);
              }}
            >
              {demoBarbers.map((barber) => (
                <option key={barber.id} value={barber.id}>{barber.name}</option>
              ))}
            </Select>
          </div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4">
            <label className="surface-label mb-3 block">Service</label>
            <Select {...form.register("serviceId")}>
              {demoServices.filter((serviceOption) => serviceOption.category !== "Add-ons").map((serviceOption) => (
                <option key={serviceOption.id} value={serviceOption.id}>{serviceOption.name}</option>
              ))}
            </Select>
          </div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4">
            <label className="surface-label mb-3 block">Add-on</label>
            <Select {...form.register("addOnId")}>
              <option value="">No add-on</option>
              {demoServices.filter((serviceOption) => serviceOption.category === "Add-ons" || serviceOption.category === "Treatments").map((serviceOption) => (
                <option key={serviceOption.id} value={serviceOption.id}>{serviceOption.name}</option>
              ))}
            </Select>
          </div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4">
            <label className="surface-label mb-3 block">Time</label>
            <Select {...form.register("appointmentTime")}>
              {availableSlots.map((slot) => (
                <option key={slot} value={slot}>{dateLabel(slot)}</option>
              ))}
            </Select>
          </div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4">
            <label className="surface-label mb-3 block">Client name</label>
            <Input {...form.register("clientName")} />
          </div>
          <div className="rounded-[28px] border border-white/8 bg-black/20 p-4">
            <label className="surface-label mb-3 block">Phone</label>
            <Input type="tel" inputMode="tel" {...form.register("clientPhone")} />
          </div>
          <label className="md:col-span-2 flex items-start gap-3 rounded-[28px] border border-white/8 bg-[linear-gradient(180deg,rgba(21,21,21,0.95),rgba(10,10,10,0.98))] p-5 text-sm leading-7 text-white/72">
            <input type="checkbox" className="mt-1 accent-[#7CFF00]" defaultChecked {...form.register("acknowledgePolicy")} />
            <span>
              I acknowledge the cancellation policy. Deposits may be retained for no-shows or late cancellations, and the rest of the ticket closes at checkout with payment and tip capture.
            </span>
          </label>
          {form.formState.errors.acknowledgePolicy ? (
            <p className="md:col-span-2 text-sm text-rose-200">{form.formState.errors.acknowledgePolicy.message}</p>
          ) : null}
          {confirmationId ? (
            <div className="md:col-span-2 rounded-[28px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-5 text-sm leading-7 text-white/78">
              Booking confirmed. Appointment <span className="text-[#d3ffa0]">{confirmationId}</span> is now live in the operational board.
            </div>
          ) : null}
          <div className="md:col-span-2 sticky bottom-[calc(env(safe-area-inset-bottom,0px)+0.75rem)] z-10 -mx-1 flex flex-col gap-3 rounded-[28px] border border-white/10 bg-[rgba(7,7,7,0.94)] p-3 backdrop-blur sm:mx-0 sm:flex-row md:static md:border-0 md:bg-transparent md:p-0 md:backdrop-blur-none">
            <Button className="h-12 px-6" disabled={bookingMutation.isPending || waitlistPending || operationsQuery.isLoading}>
              {bookingMutation.isPending ? "Creating appointment..." : sourceKind ? "Confirm marketplace booking" : "Create appointment"}
            </Button>
            <Button type="button" variant="secondary" className="h-12 px-6" disabled={bookingMutation.isPending || waitlistPending} onClick={() => void handleJoinWaitlist()}>
              {waitlistPending ? "Joining waitlist..." : "Join waitlist"}
            </Button>
          </div>
        </form>
      </Card>
      <Card className="rounded-[38px] p-6 sm:p-8 xl:sticky xl:top-4">
        <p className="surface-label">Reservation quote</p>
        {isInitialLoading ? <Skeleton className="mt-4 h-12 w-48" /> : <h3 className="mt-4 text-4xl font-semibold" data-display="true">{service.name}</h3>}
        {isInitialLoading ? <Skeleton className="mt-4 h-16 w-full" /> : <p className="mt-4 text-sm leading-7 text-white/64">{service.description}</p>}
        <div className="mt-6 rounded-[24px] border border-white/8 bg-black/20 p-4 text-sm text-white/68">
          <p className="surface-label">Booking context</p>
          <p className="mt-3">{sourceKind ? `${getSourceLabel(sourceKind)} with ${currentBarber?.name ?? "selected barber"}.` : "Direct booking flow with live scheduling and checkout sync."}</p>
          {query ? <p className="mt-2 text-white/52">Search context: {query}</p> : null}
        </div>
        <div className="mt-8 space-y-3 text-sm text-white/72">
          {isInitialLoading ? (
            <>
              <QuoteRowSkeleton />
              <QuoteRowSkeleton />
              <QuoteRowSkeleton />
              <QuoteRowSkeleton />
              <QuoteRowSkeleton />
              <QuoteRowSkeleton />
            </>
          ) : (
            <>
              <div className="flex items-center justify-between rounded-[22px] border border-white/8 bg-black/20 px-4 py-3"><span>Location</span><span>{demoLocations.find((entry) => entry.id === form.watch("locationId"))?.name}</span></div>
              <div className="flex items-center justify-between rounded-[22px] border border-white/8 bg-black/20 px-4 py-3"><span>Duration</span><span>{quote.totalDuration} min including buffer</span></div>
              <div className="flex items-center justify-between rounded-[22px] border border-white/8 bg-black/20 px-4 py-3"><span>Subtotal</span><span>{currency(quote.subtotal)}</span></div>
              <div className="flex items-center justify-between rounded-[22px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 px-4 py-3"><span>Deposit reserved</span><span className="text-[#d3ffa0]">{currency(quote.depositDue)}</span></div>
              <div className="flex items-center justify-between rounded-[22px] border border-white/8 bg-black/20 px-4 py-3"><span>Remaining at checkout</span><span>{currency(Math.max(quote.subtotal - quote.depositDue, 0))}</span></div>
              <div className="flex items-center justify-between rounded-[22px] border border-white/8 bg-black/20 px-4 py-3"><span>Live availability</span><span>{`${appointments.length} scheduled records`}</span></div>
            </>
          )}
        </div>
      </Card>
    </div>
  );
}


