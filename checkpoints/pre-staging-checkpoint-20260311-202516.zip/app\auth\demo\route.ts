import { NextRequest, NextResponse } from "next/server";
import { DEMO_SESSION_COOKIE, findDemoUserByEmail, getDefaultRouteForUser } from "@/lib/auth/demo-auth";

export async function GET(request: NextRequest) {
  const email = request.nextUrl.searchParams.get("email") ?? undefined;
  const user = findDemoUserByEmail(email);

  if (!user) {
    const response = NextResponse.redirect(new URL("/login", request.url));
    response.cookies.delete(DEMO_SESSION_COOKIE);
    return response;
  }

  const response = NextResponse.redirect(new URL(getDefaultRouteForUser(user), request.url));
  response.cookies.set(DEMO_SESSION_COOKIE, user.email, {
    httpOnly: true,
    maxAge: 60 * 60 * 24 * 30,
    path: "/",
    sameSite: "lax"
  });

  return response;
}