import { cookies } from "next/headers";
import { DEMO_SESSION_COOKIE, findDemoUserByEmail, resolveDemoUser } from "@/lib/auth/demo-auth";
import { isDemoMode, runtimeConfig } from "@/lib/config/runtime";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function getCurrentUserFromServer() {
  const cookieStore = await cookies();
  const selectedDemoEmail = cookieStore.get(DEMO_SESSION_COOKIE)?.value;

  if (isDemoMode()) {
    return {
      mode: "demo" as const,
      user: resolveDemoUser(selectedDemoEmail, runtimeConfig.demoEmail)
    };
  }

  const supabase = await createSupabaseServerClient();
  const result = await supabase?.auth.getUser();
  const email = result?.data.user?.email;
  const resolvedDemoUser = findDemoUserByEmail(selectedDemoEmail);

  return {
    mode: "supabase" as const,
    user: findDemoUserByEmail(email) ?? resolvedDemoUser ?? resolveDemoUser(undefined, runtimeConfig.demoEmail)
  };
}