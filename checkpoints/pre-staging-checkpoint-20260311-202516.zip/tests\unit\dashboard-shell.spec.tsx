import { render, screen } from "@testing-library/react";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { getDefaultRouteForUser, resolveDemoUser } from "@/lib/auth/demo-auth";

describe("dashboard shell identity and navigation", () => {
  it.each([
    ["owner@bvrb3r.demo", "Brandon Rivers", "Founder / Owner", "Active role: Owner", ["Owner control", "Network calendar", "Service catalog", "Client base", "Business reports", "Owner settings"]],
    ["manager@bvrb3r.demo", "Mia Torres", "Store Manager", "Active role: Manager", ["Shop command", "Shop schedule", "Client traffic", "Floor reports"]],
    ["frontdesk@bvrb3r.demo", "Kayla Brooks", "Guest Experience Lead", "Active role: Front desk", ["Live board", "Service tickets", "Guest records"]],
    ["wave@bvrb3r.demo", "Wave Carter", "Senior Barber", "Active role: Commission barber", ["My chair", "My schedule", "Service menu"]],
    ["blaze@bvrb3r.demo", "Blaze King", "Booth-Rent Barber", "Active role: Booth-rent barber", ["My chair", "My schedule", "My services"]],
    ["client@bvrb3r.demo", "Jordan Ellis", "Client", "Active role: Client", ["Client home", "Book now"]]
  ])("renders the selected identity for %s", (email, name, title, roleLabel, navLabels) => {
    const user = resolveDemoUser(email);
    const activeHref = getDefaultRouteForUser(user);

    render(
      <DashboardShell user={user} activeHref={activeHref} title="Workspace" subtitle="Testing shell identity.">
        <div>Workspace body</div>
      </DashboardShell>
    );

    expect(screen.getByTestId("shell-identity-name")).toHaveTextContent(name);
    expect(screen.getByTestId("shell-identity-title")).toHaveTextContent(title);
    expect(screen.getByTestId("shell-identity-role")).toHaveTextContent(roleLabel);

    navLabels.forEach((label, index) => {
      const links = screen.getAllByRole("link", { name: new RegExp(label, "i") });
      expect(links.length).toBeGreaterThan(0);
      if (index === 0) {
        expect(links.some((link) => link.getAttribute("href") === activeHref && link.getAttribute("aria-current") === "page")).toBe(true);
      }
    });

    if (email !== "owner@bvrb3r.demo") {
      expect(screen.queryByText("Owner settings")).not.toBeInTheDocument();
      expect(screen.queryByText("Brandon Rivers")).not.toBeInTheDocument();
    }
  });
});
