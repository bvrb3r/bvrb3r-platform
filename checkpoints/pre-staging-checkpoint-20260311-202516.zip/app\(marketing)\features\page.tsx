import { FeatureGrid } from "@/components/marketing/feature-grid";
import { Card } from "@/components/ui/card";

export default function FeaturesPage() {
  return (
    <section className="pb-16">
      <div className="mx-auto max-w-7xl px-6 py-10 lg:px-10">
        <Card className="rounded-[36px] p-8">
          <p className="text-sm uppercase tracking-[0.28em] text-[#baff69]">Features</p>
          <h1 className="mt-3 text-4xl font-semibold tracking-[-0.03em]">Everything needed to run the chair, the floor, and the business.</h1>
          <p className="mt-4 max-w-2xl text-white/65">BVRB3R Platform combines the best operational patterns from modern appointment software with a sharper barbershop-first workflow model.</p>
        </Card>
      </div>
      <FeatureGrid />
    </section>
  );
}