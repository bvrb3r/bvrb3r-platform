import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { runtimeConfig } from "@/lib/config/runtime";
import { demoUsers } from "@/lib/data/demo";

export default function LoginPage() {
  return (
    <section className="mx-auto flex min-h-screen max-w-6xl items-center px-6 py-10 lg:px-10">
      <div className="grid w-full gap-6 lg:grid-cols-[1fr_0.92fr]">
        <Card className="rounded-[38px] p-8 lg:p-10">
          <Badge>Auth runtime</Badge>
          <h1 className="mt-5 text-balance text-5xl font-semibold" data-display="true">Sign in with Supabase or move fast in demo mode.</h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-white/66">Current local default: <span className="text-[#cfff93]">{runtimeConfig.authMode}</span>. In Supabase mode the app reads the authenticated session. In demo mode the selected demo account is stored in a secure cookie so the correct shell, workspace, and identity persist across routes.</p>
          <div className="mt-8 space-y-3 text-sm text-white/72">
            {demoUsers.map((user) => (
              <form key={user.id} action="/auth/demo" method="get">
                <input type="hidden" name="email" value={user.email} />
                <button type="submit" className="flex w-full items-center justify-between rounded-[22px] border border-white/8 bg-black/20 px-4 py-4 text-left hover:border-[#7CFF00]/20 hover:bg-black/30">
                  <span>{user.title}</span>
                  <span className="text-white/42">{user.email}</span>
                </button>
              </form>
            ))}
          </div>
        </Card>
        <Card className="rounded-[38px] p-8 lg:p-10">
          <p className="surface-label">Access platform</p>
          <form action="/auth/demo" method="get" className="mt-6 grid gap-4">
            <Input name="email" placeholder="Email" defaultValue={runtimeConfig.demoEmail} />
            <Input name="password" placeholder="Password" type="password" defaultValue="DevOnly!123" />
            <Button type="submit" className="h-12 w-full">Continue in demo mode</Button>
            <Link href="/signup"><Button type="button" variant="secondary" className="h-12 w-full">Create an account</Button></Link>
            <p className="text-sm leading-7 text-white/52">Deposits and saved card setup stay behind provider-backed routes, keeping sensitive payment handling out of the UI layer.</p>
          </form>
        </Card>
      </div>
    </section>
  );
}