import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { OwnerOverview } from "@/components/operations/owner-overview";
import { getAuthorizedUser } from "@/lib/auth/guards";

export default async function OwnerDashboardPage() {
  const user = await getAuthorizedUser(["owner"]);
  return (
    <DashboardShell
      user={user}
      activeHref="/dashboard/owner"
      title="Owner control center"
      subtitle="Live first-working-version view of booking, service, checkout, compensation, and revenue activity."
    >
      <OwnerOverview />
    </DashboardShell>
  );
}