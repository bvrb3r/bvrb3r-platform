import Link from "next/link";
import { ArrowLeft, Sparkles } from "lucide-react";
import { DiscoveryWorkspace } from "@/components/marketplace/discovery-workspace";
import { Card } from "@/components/ui/card";
import { getCurrentUserFromServer } from "@/lib/auth/session";

export default async function DiscoveryPage() {
  const session = await getCurrentUserFromServer();
  const clientId = session.user.role === "client" ? session.user.clientId : undefined;

  return (
    <main className="app-safe-bottom mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-10 lg:py-8">
      <Card className="rounded-[36px] p-6 sm:p-8">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="surface-label text-[#d7ffab]">Global discovery engine</p>
            <h1 className="mt-4 text-balance text-4xl font-semibold sm:text-5xl" data-display="true">BVRB3R Marketplace</h1>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-white/64">
              The marketplace is the discovery layer on top of the BVRB3R operating system. Clients find trusted barbers here, then move straight into live booking.
            </p>
          </div>
          <div className="grid gap-3 sm:flex sm:flex-wrap">
            <Link href="/" className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/25 px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-white transition hover:border-[#7CFF00]/24 hover:text-[#d7ffab]">
              <ArrowLeft className="h-4 w-4" />
              Back to platform
            </Link>
            <Link href="/booking/new" className="inline-flex items-center gap-2 rounded-full border border-[#cfff93]/40 bg-[linear-gradient(135deg,#7cff00_0%,#b7ff58_100%)] px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-black shadow-[0_14px_34px_rgba(124,255,0,0.24)] transition hover:translate-y-[-1px] hover:shadow-[0_18px_38px_rgba(124,255,0,0.28)]">
              <Sparkles className="h-4 w-4" />
              Book from marketplace
            </Link>
          </div>
        </div>
      </Card>
      <div className="mt-4">
        <DiscoveryWorkspace clientId={clientId} />
      </div>
    </main>
  );
}

