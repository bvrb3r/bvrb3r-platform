﻿/* eslint-disable @typescript-eslint/no-explicit-any */
import { isSupabaseEnabled } from "@/lib/config/runtime";
import {
  demoBoostCampaigns,
  demoCityRollouts,
  demoFeaturedPlacements,
  demoMarketplaceMonetizationEvents,
  demoVerificationUploads
} from "@/lib/data/activation";
import { getMonetizationEligibility, type MarketplaceActivationState } from "@/lib/marketplace/activation";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { buildPublicTrustSignal } from "@/lib/trust/engine";
import { getTrustProvider } from "@/lib/trust/provider";
import type {
  BoostCampaignRecord,
  FeaturedPlacementRecord,
  MarketplaceMonetizationEvent,
  VerificationUploadRecord,
  CityActivationState
} from "@/types/activation";
import type { Role } from "@/types/domain";
import type { BarberVerificationCategory, ShopVerificationCategory } from "@/types/trust";

type SupabaseClient = NonNullable<ReturnType<typeof createSupabaseAdminClient>>;

export interface ActivationActor {
  role: Role;
  barberId?: string;
  userEmail?: string;
}

export class ActivationPermissionError extends Error {
  readonly status = 403;

  constructor(message: string) {
    super(message);
    this.name = "ActivationPermissionError";
  }
}

export class ActivationValidationError extends Error {
  readonly status = 400;

  constructor(message: string) {
    super(message);
    this.name = "ActivationValidationError";
  }
}

export interface MarketplaceActivationProvider {
  kind: "demo" | "supabase";
  readState(): Promise<MarketplaceActivationState>;
  createVerificationUpload(actor: ActivationActor, input: {
    ownerType: "barber" | "shop";
    ownerId?: string;
    category: BarberVerificationCategory | ShopVerificationCategory;
    fileName: string;
    contentType: string;
    fileSizeBytes: number;
    expiresAt?: string;
  }): Promise<{ upload: VerificationUploadRecord }>;
  createBoostCampaign(actor: ActivationActor, input: {
    scopeType: "barber" | "shop";
    scopeId?: string;
    placementLabel: string;
    placementScope: BoostCampaignRecord["placementScope"];
    citySlug?: string;
    categorySlug?: string;
    dailyBudgetCents: number;
    spendCents: number;
    startsAt?: string;
    endsAt?: string;
  }): Promise<{ campaign: BoostCampaignRecord }>;
  createFeaturedPlacement(actor: ActivationActor, input: {
    scopeType: "barber" | "shop";
    scopeId: string;
    label: string;
    placementScope: FeaturedPlacementRecord["placementScope"];
    citySlug?: string;
    categorySlug?: string;
    priority: number;
    startsAt: string;
    endsAt: string;
  }): Promise<{ placement: FeaturedPlacementRecord }>;
  updateCityRollout(actor: ActivationActor, input: {
    citySlug: string;
    activationState?: CityActivationState;
    launchVisible?: boolean;
    densityScore?: number;
    marketNotes?: string;
  }): Promise<{ rollout: MarketplaceActivationState["cityRollouts"][number] }>;
  recordMonetizationEvent(input: Omit<MarketplaceMonetizationEvent, "id" | "createdAt">): Promise<void>;
}

const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;
const nowIso = () => new Date().toISOString();
const makeId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

let demoState: MarketplaceActivationState = {
  verificationUploads: clone(demoVerificationUploads),
  boostCampaigns: clone(demoBoostCampaigns),
  featuredPlacements: clone(demoFeaturedPlacements),
  cityRollouts: clone(demoCityRollouts),
  monetizationEvents: clone(demoMarketplaceMonetizationEvents)
};

function assertOwner(actor: ActivationActor) {
  if (actor.role !== "owner") {
    throw new ActivationPermissionError("Only the owner can manage this activation control.");
  }
}

async function getTrustSignal(scopeType: "barber" | "shop", scopeId: string) {
  const trustProvider = await getTrustProvider();
  const trustState = await trustProvider.readState();
  if (scopeType === "barber") {
    return buildPublicTrustSignal(trustState, scopeId, "shop-bvrb3r");
  }

  const verified = trustState.shopVerifications.some((record) => record.shopId === scopeId && record.verificationStatus === "verified");
  return verified ? { trustScore: 92, verifiedBarber: true, verifiedLicense: true, completionRate: 96, moderationState: "clear" } : undefined;
}

function mapUploadRow(row: any): VerificationUploadRecord {
  return {
    id: row.id,
    ownerType: row.owner_type,
    ownerId: row.owner_reference,
    category: row.category,
    fileName: row.file_name ?? row.storage_path?.split("/").slice(-1)[0] ?? "verification-document",
    contentType: row.content_type ?? "application/octet-stream",
    fileSizeBytes: Number(row.file_size_bytes ?? 0),
    storagePath: row.storage_path,
    secureReference: row.secure_reference ?? `secure://${row.owner_reference}/${row.id}`,
    uploadStatus: row.upload_status ?? "uploaded",
    uploadedByRole: row.uploaded_by_role ?? "owner",
    uploadedAt: row.uploaded_at,
    expiresAt: row.expires_at ?? undefined
  };
}

function campaignToRow(record: BoostCampaignRecord) {
  return {
    id: record.id,
    scope_type: record.scopeType,
    scope_reference: record.scopeId,
    status: record.status,
    placement_label: record.placementLabel,
    placement_scope: record.placementScope,
    city_slug: record.citySlug ?? null,
    category_slug: record.categorySlug ?? null,
    trust_eligible: record.trustEligible,
    trust_reason: record.trustReason,
    spend_cents: record.spendCents,
    daily_budget_cents: record.dailyBudgetCents,
    starts_at: record.startsAt,
    ends_at: record.endsAt,
    created_by_role: record.createdByRole,
    created_by_reference: record.createdById,
    created_at: record.createdAt
  };
}

function placementToRow(record: FeaturedPlacementRecord) {
  return {
    id: record.id,
    scope_type: record.scopeType,
    scope_reference: record.scopeId,
    label: record.label,
    placement_scope: record.placementScope,
    city_slug: record.citySlug ?? null,
    category_slug: record.categorySlug ?? null,
    status: record.status,
    trust_eligible: record.trustEligible,
    starts_at: record.startsAt,
    ends_at: record.endsAt,
    priority: record.priority,
    created_by_role: record.createdByRole,
    created_by_reference: record.createdById,
    created_at: record.createdAt
  };
}

function cityToRow(record: MarketplaceActivationState["cityRollouts"][number]) {
  return {
    id: record.id,
    city_slug: record.citySlug,
    city_label: record.cityLabel,
    state_code: record.stateCode,
    neighborhood_label: record.neighborhoodLabel ?? null,
    activation_state: record.activationState,
    density_score: record.densityScore,
    launch_visible: record.launchVisible,
    featured_barber_ids: record.featuredBarberIds,
    featured_shop_ids: record.featuredShopIds,
    market_notes: record.marketNotes,
    activated_at: record.activatedAt ?? null,
    updated_at: record.updatedAt
  };
}

function monetizationToRow(record: MarketplaceMonetizationEvent) {
  return {
    id: record.id,
    event_type: record.eventType,
    barber_reference: record.barberId ?? null,
    shop_reference: record.shopId ?? null,
    campaign_reference: record.campaignId ?? null,
    placement_reference: record.placementId ?? null,
    city_slug: record.citySlug ?? null,
    source_kind: record.sourceKind,
    reference_id: record.referenceId ?? null,
    metadata: record.metadata,
    created_at: record.createdAt
  };
}

async function ensureSupabaseSeeded(supabase: SupabaseClient) {
  const writes = await Promise.all([
    supabase.from("verification_documents").upsert(
      demoVerificationUploads.map((record) => ({
        id: record.id,
        owner_type: record.ownerType,
        owner_reference: record.ownerId,
        category: record.category,
        storage_path: record.storagePath,
        uploaded_at: record.uploadedAt,
        expires_at: record.expiresAt ?? null,
        file_name: record.fileName,
        content_type: record.contentType,
        file_size_bytes: record.fileSizeBytes,
        upload_status: record.uploadStatus,
        uploaded_by_role: record.uploadedByRole,
        secure_reference: record.secureReference
      })),
      { onConflict: "id" }
    ),
    supabase.from("boost_campaigns").upsert(demoBoostCampaigns.map(campaignToRow), { onConflict: "id" }),
    supabase.from("featured_placements").upsert(demoFeaturedPlacements.map(placementToRow), { onConflict: "id" }),
    supabase.from("city_rollouts").upsert(demoCityRollouts.map(cityToRow), { onConflict: "id" }),
    supabase.from("marketplace_monetization_events").upsert(demoMarketplaceMonetizationEvents.map(monetizationToRow), { onConflict: "id" })
  ]);

  for (const write of writes) {
    if (write.error) {
      throw write.error;
    }
  }
}

async function readSupabaseState(supabase: SupabaseClient): Promise<MarketplaceActivationState> {
  await ensureSupabaseSeeded(supabase);
  const [uploads, campaigns, placements, cities, monetizationEvents] = await Promise.all([
    supabase.from("verification_documents").select("*").not("file_name", "is", null).order("uploaded_at", { ascending: false }),
    supabase.from("boost_campaigns").select("*").order("created_at", { ascending: false }),
    supabase.from("featured_placements").select("*").order("priority", { ascending: true }),
    supabase.from("city_rollouts").select("*").order("density_score", { ascending: false }),
    supabase.from("marketplace_monetization_events").select("*").order("created_at", { ascending: false })
  ]);

  for (const result of [uploads, campaigns, placements, cities, monetizationEvents]) {
    if (result.error) {
      throw result.error;
    }
  }

  return {
    verificationUploads: (uploads.data ?? []).map((row: any) => mapUploadRow(row)),
    boostCampaigns: (campaigns.data ?? []).map((row: any) => ({
      id: row.id,
      scopeType: row.scope_type,
      scopeId: row.scope_reference,
      status: row.status,
      placementLabel: row.placement_label,
      placementScope: row.placement_scope,
      citySlug: row.city_slug ?? undefined,
      categorySlug: row.category_slug ?? undefined,
      trustEligible: row.trust_eligible,
      trustReason: row.trust_reason,
      spendCents: Number(row.spend_cents ?? 0),
      dailyBudgetCents: Number(row.daily_budget_cents ?? 0),
      startsAt: row.starts_at,
      endsAt: row.ends_at,
      createdByRole: row.created_by_role,
      createdById: row.created_by_reference,
      createdAt: row.created_at
    })),
    featuredPlacements: (placements.data ?? []).map((row: any) => ({
      id: row.id,
      scopeType: row.scope_type,
      scopeId: row.scope_reference,
      label: row.label,
      placementScope: row.placement_scope,
      citySlug: row.city_slug ?? undefined,
      categorySlug: row.category_slug ?? undefined,
      status: row.status,
      trustEligible: row.trust_eligible,
      startsAt: row.starts_at,
      endsAt: row.ends_at,
      priority: Number(row.priority ?? 1),
      createdByRole: row.created_by_role,
      createdById: row.created_by_reference,
      createdAt: row.created_at
    })),
    cityRollouts: (cities.data ?? []).map((row: any) => ({
      id: row.id,
      citySlug: row.city_slug,
      cityLabel: row.city_label,
      stateCode: row.state_code,
      neighborhoodLabel: row.neighborhood_label ?? undefined,
      activationState: row.activation_state,
      densityScore: Number(row.density_score ?? 0),
      launchVisible: row.launch_visible,
      featuredBarberIds: row.featured_barber_ids ?? [],
      featuredShopIds: row.featured_shop_ids ?? [],
      marketNotes: row.market_notes,
      activatedAt: row.activated_at ?? undefined,
      updatedAt: row.updated_at
    })),
    monetizationEvents: (monetizationEvents.data ?? []).map((row: any) => ({
      id: row.id,
      eventType: row.event_type,
      barberId: row.barber_reference ?? undefined,
      shopId: row.shop_reference ?? undefined,
      campaignId: row.campaign_reference ?? undefined,
      placementId: row.placement_reference ?? undefined,
      citySlug: row.city_slug ?? undefined,
      sourceKind: row.source_kind,
      referenceId: row.reference_id ?? undefined,
      metadata: row.metadata ?? {},
      createdAt: row.created_at
    }))
  };
}

function getDemoState() {
  return clone(demoState);
}

function createDemoProvider(): MarketplaceActivationProvider {
  return {
    kind: "demo",
    async readState() {
      return getDemoState();
    },
    async createVerificationUpload(actor, input) {
      if (input.ownerType === "barber" && actor.role !== "owner" && actor.barberId !== (input.ownerId ?? actor.barberId)) {
        throw new ActivationPermissionError("You can only upload verification documents for your own barber profile.");
      }
      if (input.ownerType === "shop" && actor.role !== "owner") {
        throw new ActivationPermissionError("Only the owner can upload shop verification documents.");
      }
      const upload: VerificationUploadRecord = {
        id: makeId("upload"),
        ownerType: input.ownerType,
        ownerId: input.ownerId ?? actor.barberId ?? "shop-bvrb3r",
        category: input.category,
        fileName: input.fileName,
        contentType: input.contentType,
        fileSizeBytes: input.fileSizeBytes,
        storagePath: `verification/${input.ownerType}s/${input.ownerId ?? actor.barberId ?? "shop-bvrb3r"}/${input.fileName}`,
        secureReference: `secure://verification/${input.ownerType}/${input.ownerId ?? actor.barberId ?? "shop-bvrb3r"}/${makeId("doc")}`,
        uploadStatus: "uploaded",
        uploadedByRole: actor.role,
        uploadedAt: nowIso(),
        expiresAt: input.expiresAt
      };
      demoState = { ...demoState, verificationUploads: [upload, ...demoState.verificationUploads] };
      return { upload };
    },
    async createBoostCampaign(actor, input) {
      if (!["owner", "commission_barber", "booth_rent_barber"].includes(actor.role)) {
        throw new ActivationPermissionError("Only owner or barber roles can launch boosted visibility.");
      }
      const scopeType = input.scopeType;
      const scopeId = input.scopeId ?? actor.barberId;
      if (!scopeId) {
        throw new ActivationValidationError("A marketplace scope is required for this boost.");
      }
      if (actor.role !== "owner" && scopeType !== "barber") {
        throw new ActivationPermissionError("Barbers can only boost their own public profile.");
      }
      if (actor.role !== "owner" && scopeId !== actor.barberId) {
        throw new ActivationPermissionError("You can only boost your own barber profile.");
      }
      const trustSignal = await getTrustSignal(scopeType, scopeId);
      const eligibility = getMonetizationEligibility(trustSignal as any);
      if (!eligibility.canBoostVisibility) {
        throw new ActivationPermissionError(eligibility.reason);
      }
      const campaign: BoostCampaignRecord = {
        id: makeId("boost"),
        scopeType,
        scopeId,
        status: "active",
        placementLabel: input.placementLabel,
        placementScope: input.placementScope,
        citySlug: input.citySlug,
        categorySlug: input.categorySlug,
        trustEligible: true,
        trustReason: eligibility.reason,
        spendCents: input.spendCents,
        dailyBudgetCents: input.dailyBudgetCents,
        startsAt: input.startsAt ?? nowIso(),
        endsAt: input.endsAt ?? new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString(),
        createdByRole: actor.role,
        createdById: actor.barberId ?? actor.userEmail ?? "owner",
        createdAt: nowIso()
      };
      demoState = { ...demoState, boostCampaigns: [campaign, ...demoState.boostCampaigns] };
      return { campaign };
    },
    async createFeaturedPlacement(actor, input) {
      assertOwner(actor);
      const trustSignal = await getTrustSignal(input.scopeType, input.scopeId);
      const eligibility = getMonetizationEligibility(trustSignal as any);
      if (input.scopeType === "barber" && !eligibility.canUseFeaturedPlacement) {
        throw new ActivationPermissionError(eligibility.reason);
      }
      const placement: FeaturedPlacementRecord = {
        id: makeId("featured"),
        scopeType: input.scopeType,
        scopeId: input.scopeId,
        label: input.label,
        placementScope: input.placementScope,
        citySlug: input.citySlug,
        categorySlug: input.categorySlug,
        status: "active",
        trustEligible: true,
        startsAt: input.startsAt,
        endsAt: input.endsAt,
        priority: input.priority,
        createdByRole: actor.role,
        createdById: actor.userEmail ?? "owner",
        createdAt: nowIso()
      };
      demoState = { ...demoState, featuredPlacements: [placement, ...demoState.featuredPlacements] };
      return { placement };
    },
    async updateCityRollout(actor, input) {
      assertOwner(actor);
      const existing = demoState.cityRollouts.find((rollout) => rollout.citySlug === input.citySlug);
      if (!existing) {
        throw new ActivationValidationError("City rollout not found.");
      }
      const rollout = {
        ...existing,
        activationState: input.activationState ?? existing.activationState,
        launchVisible: input.launchVisible ?? existing.launchVisible,
        densityScore: input.densityScore ?? existing.densityScore,
        marketNotes: input.marketNotes ?? existing.marketNotes,
        updatedAt: nowIso()
      };
      demoState = {
        ...demoState,
        cityRollouts: [rollout, ...demoState.cityRollouts.filter((entry) => entry.citySlug !== input.citySlug)]
      };
      return { rollout };
    },
    async recordMonetizationEvent(input) {
      demoState = {
        ...demoState,
        monetizationEvents: [{ id: makeId("monetize"), createdAt: nowIso(), ...input }, ...demoState.monetizationEvents]
      };
    }
  };
}

function createSupabaseProvider(supabase: SupabaseClient): MarketplaceActivationProvider {
  return {
    kind: "supabase",
    async readState() {
      return readSupabaseState(supabase);
    },
    async createVerificationUpload(actor, input) {
      if (input.ownerType === "shop") {
        assertOwner(actor);
      }
      if (input.ownerType === "barber" && actor.role !== "owner" && actor.barberId !== (input.ownerId ?? actor.barberId)) {
        throw new ActivationPermissionError("You can only upload verification documents for your own barber profile.");
      }
      const upload: VerificationUploadRecord = {
        id: makeId("upload"),
        ownerType: input.ownerType,
        ownerId: input.ownerId ?? actor.barberId ?? "shop-bvrb3r",
        category: input.category,
        fileName: input.fileName,
        contentType: input.contentType,
        fileSizeBytes: input.fileSizeBytes,
        storagePath: `verification/${input.ownerType}s/${input.ownerId ?? actor.barberId ?? "shop-bvrb3r"}/${input.fileName}`,
        secureReference: `secure://verification/${input.ownerType}/${input.ownerId ?? actor.barberId ?? "shop-bvrb3r"}/${makeId("doc")}`,
        uploadStatus: "uploaded",
        uploadedByRole: actor.role,
        uploadedAt: nowIso(),
        expiresAt: input.expiresAt
      };
      const result = await supabase.from("verification_documents").upsert({
        id: upload.id,
        owner_type: upload.ownerType,
        owner_reference: upload.ownerId,
        category: upload.category,
        storage_path: upload.storagePath,
        uploaded_at: upload.uploadedAt,
        expires_at: upload.expiresAt ?? null,
        file_name: upload.fileName,
        content_type: upload.contentType,
        file_size_bytes: upload.fileSizeBytes,
        upload_status: upload.uploadStatus,
        uploaded_by_role: upload.uploadedByRole,
        secure_reference: upload.secureReference
      }, { onConflict: "id" });
      if (result.error) throw result.error;
      return { upload };
    },
    async createBoostCampaign(actor, input) {
      if (!["owner", "commission_barber", "booth_rent_barber"].includes(actor.role)) {
        throw new ActivationPermissionError("Only owner or barber roles can launch boosted visibility.");
      }
      const scopeType = input.scopeType;
      const scopeId = input.scopeId ?? actor.barberId;
      if (!scopeId) {
        throw new ActivationValidationError("A marketplace scope is required for this boost.");
      }
      if (actor.role !== "owner" && (scopeType !== "barber" || scopeId !== actor.barberId)) {
        throw new ActivationPermissionError("Barbers can only boost their own public profile.");
      }
      const trustSignal = await getTrustSignal(scopeType, scopeId);
      const eligibility = getMonetizationEligibility(trustSignal as any);
      if (!eligibility.canBoostVisibility) {
        throw new ActivationPermissionError(eligibility.reason);
      }
      const campaign: BoostCampaignRecord = {
        id: makeId("boost"),
        scopeType,
        scopeId,
        status: "active",
        placementLabel: input.placementLabel,
        placementScope: input.placementScope,
        citySlug: input.citySlug,
        categorySlug: input.categorySlug,
        trustEligible: true,
        trustReason: eligibility.reason,
        spendCents: input.spendCents,
        dailyBudgetCents: input.dailyBudgetCents,
        startsAt: input.startsAt ?? nowIso(),
        endsAt: input.endsAt ?? new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString(),
        createdByRole: actor.role,
        createdById: actor.barberId ?? actor.userEmail ?? "owner",
        createdAt: nowIso()
      };
      const result = await supabase.from("boost_campaigns").upsert(campaignToRow(campaign), { onConflict: "id" });
      if (result.error) throw result.error;
      return { campaign };
    },
    async createFeaturedPlacement(actor, input) {
      assertOwner(actor);
      const trustSignal = await getTrustSignal(input.scopeType, input.scopeId);
      const eligibility = getMonetizationEligibility(trustSignal as any);
      if (input.scopeType === "barber" && !eligibility.canUseFeaturedPlacement) {
        throw new ActivationPermissionError(eligibility.reason);
      }
      const placement: FeaturedPlacementRecord = {
        id: makeId("featured"),
        scopeType: input.scopeType,
        scopeId: input.scopeId,
        label: input.label,
        placementScope: input.placementScope,
        citySlug: input.citySlug,
        categorySlug: input.categorySlug,
        status: "active",
        trustEligible: true,
        startsAt: input.startsAt,
        endsAt: input.endsAt,
        priority: input.priority,
        createdByRole: actor.role,
        createdById: actor.userEmail ?? "owner",
        createdAt: nowIso()
      };
      const result = await supabase.from("featured_placements").upsert(placementToRow(placement), { onConflict: "id" });
      if (result.error) throw result.error;
      return { placement };
    },
    async updateCityRollout(actor, input) {
      assertOwner(actor);
      const current = await readSupabaseState(supabase);
      const existing = current.cityRollouts.find((rollout) => rollout.citySlug === input.citySlug);
      if (!existing) {
        throw new ActivationValidationError("City rollout not found.");
      }
      const rollout = {
        ...existing,
        activationState: input.activationState ?? existing.activationState,
        launchVisible: input.launchVisible ?? existing.launchVisible,
        densityScore: input.densityScore ?? existing.densityScore,
        marketNotes: input.marketNotes ?? existing.marketNotes,
        updatedAt: nowIso()
      };
      const result = await supabase.from("city_rollouts").upsert(cityToRow(rollout), { onConflict: "id" });
      if (result.error) throw result.error;
      return { rollout };
    },
    async recordMonetizationEvent(input) {
      const event: MarketplaceMonetizationEvent = {
        id: makeId("monetize"),
        createdAt: nowIso(),
        ...input
      };
      const result = await supabase.from("marketplace_monetization_events").upsert(monetizationToRow(event), { onConflict: "id" });
      if (result.error) throw result.error;
    }
  };
}

export async function getMarketplaceActivationProvider(): Promise<MarketplaceActivationProvider> {
  if (!isSupabaseEnabled()) {
    return createDemoProvider();
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return createDemoProvider();
  }

  return createSupabaseProvider(supabase);
}


