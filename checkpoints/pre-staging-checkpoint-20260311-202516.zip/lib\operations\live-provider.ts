﻿import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import { isSupabaseEnabled } from "@/lib/config/runtime";
import {
  AppointmentLifecycleMutationInput,
  BookingMutationInput,
  CheckoutMutationInput,
  LiveMutationSuccess,
  LiveOperationConflictError,
  LiveOperationsSnapshot,
  LiveOperationsViewer,
  LiveAppointmentRecord,
  bookAppointmentInSnapshot,
  checkoutAppointmentInSnapshot,
  createInitialLiveOperationsSnapshot,
  scopeLiveOperationsSnapshot,
  transitionAppointmentInSnapshot
} from "@/lib/operations/live-state";
import { Client, WalkInEntry } from "@/types/domain";
import { CompensationSnapshotRecord, OwnerAnalyticsSnapshotRecord, WorkflowEventRecord } from "@/lib/operations/persistence";

type SupabaseClient = NonNullable<ReturnType<typeof createSupabaseAdminClient>>;

interface LiveOperationsProvider {
  kind: "demo" | "supabase";
  readSnapshot(viewer: LiveOperationsViewer): Promise<LiveOperationsSnapshot>;
  createBooking(input: BookingMutationInput): Promise<LiveMutationSuccess>;
  transitionAppointment(input: AppointmentLifecycleMutationInput): Promise<LiveMutationSuccess>;
  checkoutAppointment(input: CheckoutMutationInput): Promise<LiveMutationSuccess>;
}

interface LiveClientRow {
  client_reference: string;
  full_name: string;
  phone: string;
  email: string;
  favorite_barber_reference: string | null;
  loyalty_points: number;
  retention_tag: Client["retentionTag"];
  notes: string[] | null;
}

interface LiveAppointmentRow {
  appointment_reference: string;
  location_reference: string;
  barber_reference: string;
  barber_user_reference: string;
  barber_email: string;
  client_reference: string;
  client_email: string;
  service_reference: string;
  status: LiveAppointmentRecord["status"];
  source: LiveAppointmentRecord["source"];
  starts_at: string;
  ends_at: string;
  chair_label: string | null;
  add_on_references: string[] | null;
  deposit_amount: number | string;
  total_amount: number | string;
  balance_due: number | string;
  tip_amount: number | string;
  client_note: string | null;
  lifecycle_revision: number;
  last_actor_role: LiveAppointmentRecord["lastActorRole"] | null;
  last_event_type: LiveAppointmentRecord["lastEventType"] | null;
  checkout_reference: string | null;
  updated_at: string;
}

interface LiveWalkInRow {
  queue_reference: string;
  location_reference: string;
  client_name: string;
  requested_service: string;
  requested_at: string;
  status: WalkInEntry["status"];
  assigned_barber_reference: string | null;
  wait_minutes: number;
}

function numberValue(value: number | string | null | undefined) {
  return Number(value ?? 0);
}

function toClient(row: LiveClientRow): Client {
  return {
    id: row.client_reference,
    name: row.full_name,
    phone: row.phone,
    email: row.email,
    favoriteBarberId: row.favorite_barber_reference ?? undefined,
    loyaltyPoints: row.loyalty_points,
    retentionTag: row.retention_tag,
    notes: row.notes ?? []
  };
}

function toAppointment(row: LiveAppointmentRow): LiveAppointmentRecord {
  return {
    id: row.appointment_reference,
    locationId: row.location_reference,
    barberId: row.barber_reference,
    clientId: row.client_reference,
    serviceId: row.service_reference,
    status: row.status,
    source: row.source,
    start: row.starts_at,
    end: row.ends_at,
    chair: row.chair_label ?? "Front desk assign",
    addOnIds: row.add_on_references ?? [],
    depositAmount: numberValue(row.deposit_amount),
    totalAmount: numberValue(row.total_amount),
    balanceDue: numberValue(row.balance_due),
    tipAmount: numberValue(row.tip_amount),
    note: row.client_note ?? "",
    revision: row.lifecycle_revision,
    updatedAt: row.updated_at,
    lastActorRole: row.last_actor_role ?? undefined,
    lastEventType: row.last_event_type ?? undefined,
    checkoutReference: row.checkout_reference ?? undefined
  };
}

function toWalkIn(row: LiveWalkInRow): WalkInEntry {
  return {
    id: row.queue_reference,
    locationId: row.location_reference,
    clientName: row.client_name,
    requestedService: row.requested_service,
    requestedAt: row.requested_at,
    status: row.status,
    assignedBarberId: row.assigned_barber_reference ?? undefined,
    waitMinutes: row.wait_minutes
  };
}

function toClientInsert(client: Client) {
  return {
    client_reference: client.id,
    full_name: client.name,
    phone: client.phone,
    email: client.email,
    favorite_barber_reference: client.favoriteBarberId ?? null,
    loyalty_points: client.loyaltyPoints,
    retention_tag: client.retentionTag,
    notes: client.notes,
    updated_at: new Date().toISOString()
  };
}

function toAppointmentInsert(appointment: LiveAppointmentRecord, clientEmail: string) {
  return {
    appointment_reference: appointment.id,
    location_reference: appointment.locationId,
    barber_reference: appointment.barberId,
    barber_user_reference: appointment.barberId,
    barber_email: "",
    client_reference: appointment.clientId,
    client_email: clientEmail,
    service_reference: appointment.serviceId,
    status: appointment.status,
    source: appointment.source,
    starts_at: appointment.start,
    ends_at: appointment.end,
    chair_label: appointment.chair,
    add_on_references: appointment.addOnIds,
    deposit_amount: appointment.depositAmount,
    total_amount: appointment.totalAmount,
    balance_due: appointment.balanceDue,
    tip_amount: appointment.tipAmount,
    client_note: appointment.note,
    lifecycle_revision: appointment.revision,
    last_actor_role: appointment.lastActorRole ?? null,
    last_event_type: appointment.lastEventType ?? null,
    checkout_reference: appointment.checkoutReference ?? null,
    updated_at: appointment.updatedAt
  };
}

function toWorkflowEventInsert(record: WorkflowEventRecord) {
  return {
    appointment_reference: record.appointmentReference,
    location_reference: record.locationReference,
    barber_reference: record.barberReference,
    barber_user_reference: record.barberUserReference,
    barber_email: record.barberEmail,
    client_reference: record.clientReference,
    client_email: record.clientEmail,
    actor_role: record.actorRole,
    event_type: record.eventType,
    title: record.title,
    detail: record.detail,
    event_payload: record.eventPayload,
    created_at: record.createdAt
  };
}

function toCompensationInsert(record: CompensationSnapshotRecord) {
  return {
    appointment_reference: record.appointmentReference,
    location_reference: record.locationReference,
    barber_reference: record.barberReference,
    barber_user_reference: record.barberUserReference,
    barber_email: record.barberEmail,
    client_reference: record.clientReference,
    client_email: record.clientEmail,
    compensation_model: record.compensationModel,
    business_date: record.businessDate,
    gross_service_amount: record.grossServiceAmount,
    deposit_amount: record.depositAmount,
    collected_amount: record.collectedAmount,
    tip_amount: record.tipAmount,
    commission_rate: record.commissionRate,
    commission_amount: record.commissionAmount,
    booth_rent_amount: record.boothRentAmount,
    booth_rent_period_label: record.boothRentPeriodLabel,
    rent_coverage_amount: record.rentCoverageAmount,
    checkout_reference: record.checkoutReference,
    captured_at: record.capturedAt,
    updated_at: new Date().toISOString()
  };
}

function toOwnerAnalyticsInsert(record: OwnerAnalyticsSnapshotRecord) {
  return {
    location_reference: record.locationReference,
    business_date: record.businessDate,
    booked_count: record.bookedCount,
    completed_services_count: record.completedServicesCount,
    paid_appointments_count: record.paidAppointmentsCount,
    revenue_total: record.revenueTotal,
    tip_total: record.tipTotal,
    outstanding_balance: record.outstandingBalance,
    updated_at: record.updatedAt
  };
}

function getBarberEmail(appointment: LiveAppointmentRecord, workflowEvent: WorkflowEventRecord | undefined) {
  return workflowEvent?.barberEmail ?? `${appointment.barberId}@bvrb3r.local`;
}

declare global {
  var __bvrb3rLiveSnapshot: LiveOperationsSnapshot | undefined;
}

function getDemoSnapshot() {
  if (!globalThis.__bvrb3rLiveSnapshot) {
    globalThis.__bvrb3rLiveSnapshot = createInitialLiveOperationsSnapshot("demo");
  }

  return globalThis.__bvrb3rLiveSnapshot;
}

function setDemoSnapshot(snapshot: LiveOperationsSnapshot) {
  globalThis.__bvrb3rLiveSnapshot = snapshot;
}

function createDemoProvider(): LiveOperationsProvider {
  return {
    kind: "demo",
    async readSnapshot(viewer) {
      return scopeLiveOperationsSnapshot(getDemoSnapshot(), viewer);
    },
    async createBooking(input) {
      const result = bookAppointmentInSnapshot(getDemoSnapshot(), input);
      setDemoSnapshot(result.snapshot);
      return result;
    },
    async transitionAppointment(input) {
      const result = transitionAppointmentInSnapshot(getDemoSnapshot(), input);
      setDemoSnapshot(result.snapshot);
      return result;
    },
    async checkoutAppointment(input) {
      const result = checkoutAppointmentInSnapshot(getDemoSnapshot(), input);
      setDemoSnapshot(result.snapshot);
      return result;
    }
  };
}

async function readFullSupabaseSnapshot(supabase: SupabaseClient): Promise<LiveOperationsSnapshot> {
  const [appointmentsResult, clientsResult, walkInsResult, eventsResult, compensationResult, analyticsResult] = await Promise.all([
    supabase.from("live_appointments").select("*").order("starts_at", { ascending: true }),
    supabase.from("live_clients").select("*"),
    supabase.from("live_walk_in_queue").select("*").order("requested_at", { ascending: true }),
    supabase.from("workflow_events").select("*").order("created_at", { ascending: false }).limit(40),
    supabase.from("compensation_snapshots").select("*").order("captured_at", { ascending: false }),
    supabase.from("owner_daily_analytics").select("*").order("business_date", { ascending: false })
  ]);

  if (appointmentsResult.error) {
    throw appointmentsResult.error;
  }
  if (clientsResult.error) {
    throw clientsResult.error;
  }
  if (walkInsResult.error) {
    throw walkInsResult.error;
  }
  if (eventsResult.error) {
    throw eventsResult.error;
  }
  if (compensationResult.error) {
    throw compensationResult.error;
  }
  if (analyticsResult.error) {
    throw analyticsResult.error;
  }

  return {
    mode: "supabase",
    fetchedAt: new Date().toISOString(),
    appointments: (appointmentsResult.data ?? []).map((row) => toAppointment(row as LiveAppointmentRow)),
    clients: (clientsResult.data ?? []).map((row) => toClient(row as LiveClientRow)),
    walkIns: (walkInsResult.data ?? []).map((row) => toWalkIn(row as LiveWalkInRow)),
    workflowEvents: (eventsResult.data ?? []).map((row) => ({
      appointmentReference: row.appointment_reference,
      locationReference: row.location_reference,
      barberReference: row.barber_reference,
      barberUserReference: row.barber_user_reference,
      barberEmail: row.barber_email,
      clientReference: row.client_reference,
      clientEmail: row.client_email,
      actorRole: row.actor_role,
      eventType: row.event_type,
      title: row.title,
      detail: row.detail,
      eventPayload: row.event_payload,
      createdAt: row.created_at
    } as WorkflowEventRecord)),
    compensationSnapshots: (compensationResult.data ?? []).map((row) => ({
      appointmentReference: row.appointment_reference,
      locationReference: row.location_reference,
      barberReference: row.barber_reference,
      barberUserReference: row.barber_user_reference,
      barberEmail: row.barber_email,
      clientReference: row.client_reference,
      clientEmail: row.client_email,
      compensationModel: row.compensation_model,
      businessDate: row.business_date,
      grossServiceAmount: numberValue(row.gross_service_amount),
      depositAmount: numberValue(row.deposit_amount),
      collectedAmount: numberValue(row.collected_amount),
      tipAmount: numberValue(row.tip_amount),
      commissionRate: row.commission_rate === null ? null : numberValue(row.commission_rate),
      commissionAmount: numberValue(row.commission_amount),
      boothRentAmount: row.booth_rent_amount === null ? null : numberValue(row.booth_rent_amount),
      boothRentPeriodLabel: row.booth_rent_period_label,
      rentCoverageAmount: row.rent_coverage_amount === null ? null : numberValue(row.rent_coverage_amount),
      checkoutReference: row.checkout_reference,
      capturedAt: row.captured_at
    } as CompensationSnapshotRecord)),
    ownerAnalytics: (analyticsResult.data ?? []).map((row) => ({
      locationReference: row.location_reference,
      businessDate: row.business_date,
      bookedCount: row.booked_count,
      completedServicesCount: row.completed_services_count,
      paidAppointmentsCount: row.paid_appointments_count,
      revenueTotal: numberValue(row.revenue_total),
      tipTotal: numberValue(row.tip_total),
      outstandingBalance: numberValue(row.outstanding_balance),
      updatedAt: row.updated_at
    } as OwnerAnalyticsSnapshotRecord))
  };
}

async function persistArtifactsForAppointment(
  supabase: SupabaseClient,
  snapshot: LiveOperationsSnapshot,
  appointment: LiveAppointmentRecord
) {
  const workflowEvent = snapshot.workflowEvents.find((entry) => entry.appointmentReference === appointment.id);
  const compensationSnapshot = snapshot.compensationSnapshots.find((entry) => entry.appointmentReference === appointment.id);
  const ownerAnalytics = snapshot.ownerAnalytics.find((entry) => entry.locationReference === appointment.locationId);

  if (workflowEvent) {
    const workflowResult = await supabase.from("workflow_events").insert(toWorkflowEventInsert(workflowEvent));
    if (workflowResult.error) {
      throw workflowResult.error;
    }
  }

  if (compensationSnapshot) {
    const compensationResult = await supabase
      .from("compensation_snapshots")
      .upsert(toCompensationInsert(compensationSnapshot), { onConflict: "appointment_reference" });

    if (compensationResult.error) {
      throw compensationResult.error;
    }
  }

  if (ownerAnalytics) {
    const analyticsResult = await supabase
      .from("owner_daily_analytics")
      .upsert(toOwnerAnalyticsInsert(ownerAnalytics), { onConflict: "location_reference,business_date" });

    if (analyticsResult.error) {
      throw analyticsResult.error;
    }
  }
}

async function getLatestAppointmentOrThrow(supabase: SupabaseClient, appointmentId: string) {
  const latestResult = await supabase
    .from("live_appointments")
    .select("*")
    .eq("appointment_reference", appointmentId)
    .single();

  if (latestResult.error) {
    throw latestResult.error;
  }

  return toAppointment(latestResult.data as LiveAppointmentRow);
}

function createSupabaseProvider(supabase: SupabaseClient): LiveOperationsProvider {
  return {
    kind: "supabase",
    async readSnapshot(viewer) {
      const fullSnapshot = await readFullSupabaseSnapshot(supabase);
      return scopeLiveOperationsSnapshot(fullSnapshot, viewer);
    },
    async createBooking(input) {
      const fullSnapshot = await readFullSupabaseSnapshot(supabase);
      const result = bookAppointmentInSnapshot(fullSnapshot, input);
      const client = result.snapshot.clients.find((entry) => entry.id === result.appointment.clientId);
      const latestEvent = result.snapshot.workflowEvents.find((entry) => entry.appointmentReference === result.appointment.id);
      const appointmentInsert = {
        ...toAppointmentInsert(result.appointment, client?.email ?? `${result.appointment.clientId}@guest.bvrb3r.local`),
        barber_email: getBarberEmail(result.appointment, latestEvent)
      };

      const clientResult = await supabase.from("live_clients").upsert(toClientInsert(client!), { onConflict: "client_reference" });
      if (clientResult.error) {
        throw clientResult.error;
      }

      const appointmentResult = await supabase.from("live_appointments").insert(appointmentInsert);
      if (appointmentResult.error) {
        throw appointmentResult.error;
      }

      await persistArtifactsForAppointment(supabase, result.snapshot, result.appointment);
      return result;
    },
    async transitionAppointment(input) {
      const fullSnapshot = await readFullSupabaseSnapshot(supabase);
      const result = transitionAppointmentInSnapshot(fullSnapshot, input);
      const client = result.snapshot.clients.find((entry) => entry.id === result.appointment.clientId);
      const latestEvent = result.snapshot.workflowEvents.find((entry) => entry.appointmentReference === result.appointment.id);
      const updateResult = await supabase
        .from("live_appointments")
        .update({
          ...toAppointmentInsert(result.appointment, client?.email ?? `${result.appointment.clientId}@guest.bvrb3r.local`),
          barber_email: getBarberEmail(result.appointment, latestEvent)
        })
        .eq("appointment_reference", input.appointmentId)
        .eq("lifecycle_revision", input.expectedRevision)
        .select("appointment_reference")
        .maybeSingle();

      if (updateResult.error) {
        throw updateResult.error;
      }
      if (!updateResult.data) {
        throw new LiveOperationConflictError(
          `Appointment ${input.appointmentId} changed before your update completed.`,
          await getLatestAppointmentOrThrow(supabase, input.appointmentId),
          "stale_revision"
        );
      }

      await persistArtifactsForAppointment(supabase, result.snapshot, result.appointment);
      return result;
    },
    async checkoutAppointment(input) {
      const fullSnapshot = await readFullSupabaseSnapshot(supabase);
      const result = checkoutAppointmentInSnapshot(fullSnapshot, input);
      const client = result.snapshot.clients.find((entry) => entry.id === result.appointment.clientId);
      const latestEvent = result.snapshot.workflowEvents.find((entry) => entry.appointmentReference === result.appointment.id);
      const updateResult = await supabase
        .from("live_appointments")
        .update({
          ...toAppointmentInsert(result.appointment, client?.email ?? `${result.appointment.clientId}@guest.bvrb3r.local`),
          barber_email: getBarberEmail(result.appointment, latestEvent)
        })
        .eq("appointment_reference", input.appointmentId)
        .eq("lifecycle_revision", input.expectedRevision)
        .select("appointment_reference")
        .maybeSingle();

      if (updateResult.error) {
        throw updateResult.error;
      }
      if (!updateResult.data) {
        throw new LiveOperationConflictError(
          `Appointment ${input.appointmentId} changed before checkout completed.`,
          await getLatestAppointmentOrThrow(supabase, input.appointmentId),
          "stale_revision"
        );
      }

      await persistArtifactsForAppointment(supabase, result.snapshot, result.appointment);
      return result;
    }
  };
}

export async function getLiveOperationsProvider(): Promise<LiveOperationsProvider> {
  if (!isSupabaseEnabled()) {
    return createDemoProvider();
  }

  const supabase = createSupabaseAdminClient();
  if (!supabase) {
    return createDemoProvider();
  }

  return createSupabaseProvider(supabase);
}
