import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { ReferralsWorkspace } from "@/components/engagement/referrals-workspace";
import { getAuthorizedUser } from "@/lib/auth/guards";

export default async function ReferralsPage() {
  const user = await getAuthorizedUser(["client"]);

  return (
    <DashboardShell
      user={user}
      activeHref="/referrals"
      title="Referral growth loop"
      subtitle="Turn satisfied visits into new marketplace demand with one clean client-safe referral page."
    >
      <ReferralsWorkspace />
    </DashboardShell>
  );
}
