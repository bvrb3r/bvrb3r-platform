import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export default function SignupPage() {
  return (
    <section className="mx-auto flex min-h-screen max-w-5xl items-center px-6 py-10 lg:px-10">
      <Card className="w-full rounded-[38px] p-8 lg:p-10">
        <Badge>Get started</Badge>
        <h1 className="mt-5 text-balance text-5xl font-semibold" data-display="true">Launch a branded booking and operations stack.</h1>
        <p className="mt-5 max-w-2xl text-base leading-7 text-white/66">Set up a premium client-facing barbershop system with owner controls, team operations, and a sharper booking experience from day one.</p>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <Input placeholder="Full name" />
          <Input placeholder="Business email" />
          <Input placeholder="Business name" />
          <Input placeholder="Primary location" />
        </div>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Link href="/contact"><Button className="h-12 px-6">Request setup</Button></Link>
          <Link href="/login"><Button variant="secondary" className="h-12 px-6">Back to login</Button></Link>
        </div>
      </Card>
    </section>
  );
}