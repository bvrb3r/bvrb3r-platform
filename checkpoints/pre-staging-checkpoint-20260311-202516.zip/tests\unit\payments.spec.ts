import { getPaymentProvider } from "@/lib/payments/provider";

describe("payment provider", () => {
  it("falls back to mock provider for local startup", async () => {
    const provider = await getPaymentProvider();
    const result = await provider.createDepositIntent({
      appointmentId: "appt-local",
      amount: 15,
      customerEmail: "client@bvrb3r.demo",
      customerName: "Jordan Ellis"
    });

    expect(provider.kind).toBe("mock");
    expect(result.provider).toBe("mock");
    expect(result.clientSecret).toContain("mock_deposit");
  });
});