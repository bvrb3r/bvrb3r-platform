import type { Route } from "next";
import { demoUsers } from "@/lib/data/demo";
import { runtimeConfig } from "@/lib/config/runtime";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import type { Role, UserAccount } from "@/types/domain";

export const DEMO_SESSION_COOKIE = "bvrb3r-demo-email";
export const DEFAULT_DEMO_EMAIL = "owner@bvrb3r.demo";

function normalizeDemoEmail(email?: string) {
  if (!email) {
    return undefined;
  }

  const trimmed = email.trim().replace(/^"|"$/g, "");

  try {
    return decodeURIComponent(trimmed);
  } catch {
    return trimmed;
  }
}

export function findDemoUserByEmail(email?: string) {
  const normalizedEmail = normalizeDemoEmail(email);
  return demoUsers.find((user) => user.email === normalizedEmail);
}

export function findDemoUserByRole(role?: Role) {
  return demoUsers.find((user) => user.role === role);
}

export function resolveDemoUser(selectedEmail?: string, fallbackEmail = DEFAULT_DEMO_EMAIL) {
  return findDemoUserByEmail(selectedEmail) ?? findDemoUserByEmail(fallbackEmail) ?? demoUsers[0];
}

export function getDemoUser(email?: string) {
  return resolveDemoUser(email, DEFAULT_DEMO_EMAIL);
}

export function getRoleLabel(role: Role) {
  switch (role) {
    case "owner":
      return "Owner";
    case "manager":
      return "Manager";
    case "front_desk":
      return "Front desk";
    case "commission_barber":
      return "Commission barber";
    case "booth_rent_barber":
      return "Booth-rent barber";
    case "client":
      return "Client";
    default:
      return "User";
  }
}

export function getDefaultRouteForUser(user: UserAccount): Route {
  switch (user.role) {
    case "owner":
      return "/dashboard/owner";
    case "manager":
      return "/dashboard/manager";
    case "front_desk":
      return "/dashboard/front-desk";
    case "commission_barber":
    case "booth_rent_barber":
      return "/dashboard/barber";
    case "client":
      return "/dashboard/client";
    default:
      return "/";
  }
}

export function getLocalRuntimeUser() {
  return resolveDemoUser(undefined, runtimeConfig.demoEmail);
}

export async function signInWithSupabase(email: string, password: string) {
  const supabase = createSupabaseBrowserClient();
  if (!supabase) {
    return { error: "Supabase is not configured. Falling back to demo mode." };
  }

  const { error } = await supabase.auth.signInWithPassword({ email, password });
  return { error: error?.message };
}