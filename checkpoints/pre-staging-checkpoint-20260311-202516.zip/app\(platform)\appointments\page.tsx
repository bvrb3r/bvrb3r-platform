import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { Card } from "@/components/ui/card";
import { getAuthorizedUser } from "@/lib/auth/guards";
import { demoAppointments, demoWalkIns } from "@/lib/data/demo";
import { dateLabel } from "@/lib/utils";

export default async function AppointmentsPage() {
  const user = await getAuthorizedUser(["owner", "manager", "front_desk", "commission_barber", "booth_rent_barber"]);
  return (
    <DashboardShell user={user} activeHref="/appointments" title="Appointments and queue" subtitle="Unified schedule, walk-ins, and status visibility across the floor.">
      <section className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="surface-label">Appointment details</p>
              <p className="mt-2 text-sm text-white/58">Scan time, chair, balance, and current status without leaving the schedule view.</p>
            </div>
            <span className="status-pill text-[#d7ffab]">Live floor visibility</span>
          </div>
          <div className="mt-4 overflow-hidden rounded-3xl border border-white/10 bg-black/20">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 text-white/45">
                <tr>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Time</th>
                  <th className="px-4 py-3">Chair</th>
                  <th className="px-4 py-3">Balance</th>
                </tr>
              </thead>
              <tbody>
                {demoAppointments.map((appointment) => (
                  <tr key={appointment.id} className="border-t border-white/10 text-white/75">
                    <td className="px-4 py-3">{appointment.status.replaceAll("_", " ")}</td>
                    <td className="px-4 py-3">{dateLabel(appointment.start)}</td>
                    <td className="px-4 py-3">{appointment.chair}</td>
                    <td className="px-4 py-3">${appointment.balanceDue}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
        <Card className="rounded-[32px] p-6">
          <p className="surface-label">Walk-in management</p>
          <div className="mt-4 space-y-3">
            {demoWalkIns.map((walkIn) => (
              <div key={walkIn.id} className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                <p className="font-medium">{walkIn.clientName}</p>
                <p className="mt-1 text-sm text-white/50">Requested {walkIn.requestedService}</p>
                <p className="mt-3 text-[11px] uppercase tracking-[0.18em] text-[#baff69]">{walkIn.status} | {walkIn.waitMinutes} minutes</p>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </DashboardShell>
  );
}