﻿import { demoBarbers, demoLocations } from "@/lib/data/demo";
import { demoShops } from "@/lib/data/marketplace";
import { demoBarberVerifications, demoDisputeEvents, demoDisputes, demoModerationActions, demoReliabilityScores, demoReportEvents, demoReviewModeration, demoRiskFlags, demoSafetyReports, demoShopVerifications, demoTrustBadges, demoVerificationDocuments } from "@/lib/data/trust";
import type { Role } from "@/types/domain";
import type { BarberTrustWorkspaceSummary, BarberVerificationCategory, BarberVerificationRecord, BarberVerificationStatusView, DisputeRecord, OwnerTrustWorkspaceSummary, PublicTrustSignal, SafetyReportRecord, SafetyReportStatus, ShopVerificationCategory, ShopVerificationRecord, TrustState, VerificationStatus } from "@/types/trust";

const REPORT_OPEN = new Set<SafetyReportStatus>(["open", "under_review", "escalated"]);
const DISPUTE_OPEN = new Set(["open", "under_review", "escalated"]);
const BARBER_CATEGORIES: BarberVerificationCategory[] = ["identity_verification", "license_verification", "payout_verification", "shop_affiliation_verification"];
const REPORT_SUBJECTS: Record<Role, readonly SafetyReportRecord["subjectType"][]> = { owner: ["client", "barber", "shop", "review", "booking"], manager: ["booking"], front_desk: ["booking"], commission_barber: ["client", "review", "booking"], booth_rent_barber: ["client", "review", "booking"], client: ["barber", "shop", "review", "booking"] };

export interface TrustActor { role: Role; userEmail?: string; clientId?: string; barberId?: string; locationIds?: string[]; }
export interface SubmitBarberVerificationInput { category: BarberVerificationCategory; legalName: string; licenseType?: string; licenseNumber?: string; issuingState?: string; expirationDate?: string; documentPath?: string; }
export interface SubmitShopVerificationInput { shopId: string; category: ShopVerificationCategory; businessName: string; documentPath?: string; }
export interface SubmitSafetyReportInput { subjectType: SafetyReportRecord["subjectType"]; subjectId: string; category: SafetyReportRecord["category"]; details: string; locationId?: string; }
export interface SubmitDisputeInput { disputeType: DisputeRecord["disputeType"]; involvedPartyType: DisputeRecord["involvedPartyType"]; involvedPartyId: string; summary: string; appointmentId?: string; locationId?: string; }

export class TrustPermissionError extends Error { readonly status = 403; constructor(message: string) { super(message); this.name = "TrustPermissionError"; } }
export class TrustValidationError extends Error { readonly status = 400; constructor(message: string) { super(message); this.name = "TrustValidationError"; } }

function cloneState<T>(value: T): T { return JSON.parse(JSON.stringify(value)) as T; }
function createId(prefix: string) { return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; }
function clamp(value: number, min: number, max: number) { return Math.min(max, Math.max(min, value)); }
function uniqueStrings(values: string[]) { return Array.from(new Set(values.filter(Boolean))); }
function getVerificationLabel(category: BarberVerificationCategory) { return category === "identity_verification" ? "Identity verification" : category === "license_verification" ? "License verification" : category === "payout_verification" ? "Payout verification" : "Shop affiliation"; }
function getStatusWeight(status: VerificationStatus) { return status === "verified" ? 1 : status === "pending" ? 0.6 : status === "expired" ? 0.25 : status === "rejected" ? 0.1 : 0; }
function isOpenReport(status: SafetyReportStatus) { return REPORT_OPEN.has(status); }
function isOpenDispute(status: DisputeRecord["disputeStatus"]) { return DISPUTE_OPEN.has(status); }
function getBarberVerificationRecord(state: TrustState, barberId: string, category: BarberVerificationCategory) { return state.barberVerifications.find((record) => record.barberId === barberId && record.category === category); }
function getShopVerified(state: TrustState, shopId?: string) { return !!shopId && state.shopVerifications.some((record) => record.shopId === shopId && record.verificationStatus === "verified"); }
function getReliabilityRecord(state: TrustState, barberId: string) { return state.reliabilityScores.find((record) => record.barberId === barberId); }
function getOpenRiskPenalty(state: TrustState, barberId: string) { return state.riskFlags.filter((flag) => flag.entityType === "barber" && flag.entityId === barberId && flag.open).reduce((sum, flag) => sum + (flag.severity === "high" ? 12 : flag.severity === "medium" ? 6 : 3), 0); }
function getReviewPenalty(state: TrustState, barberId: string) { return state.reviewModeration.filter((record) => record.barberId === barberId && ["flagged", "removed", "under_review"].includes(record.moderationStatus)).reduce((sum, record) => sum + Math.max(2, Math.round((100 - record.integrityScore) / 10)), 0); }

export function createInitialTrustState(): TrustState {
  return cloneState({ barberVerifications: demoBarberVerifications, shopVerifications: demoShopVerifications, verificationDocuments: demoVerificationDocuments, trustBadges: demoTrustBadges, reviewModeration: demoReviewModeration, safetyReports: demoSafetyReports, reportEvents: demoReportEvents, disputes: demoDisputes, disputeEvents: demoDisputeEvents, riskFlags: demoRiskFlags, moderationActions: demoModerationActions, reliabilityScores: demoReliabilityScores });
}

export function buildPublicTrustSignal(state: TrustState, barberId: string, shopId?: string): PublicTrustSignal {
  const identityVerified = (getBarberVerificationRecord(state, barberId, "identity_verification")?.verificationStatus ?? "unverified") === "verified";
  const licenseVerified = (getBarberVerificationRecord(state, barberId, "license_verification")?.verificationStatus ?? "unverified") === "verified";
  const shopVerified = getShopVerified(state, shopId);
  const reliability = getReliabilityRecord(state, barberId);
  const approvedReviews = state.reviewModeration.filter((record) => record.barberId === barberId && record.moderationStatus === "approved");
  const reviewIntegrityScore = approvedReviews.length ? Math.round(approvedReviews.reduce((sum, record) => sum + record.integrityScore, 0) / approvedReviews.length) : Math.round(reliability?.reviewIntegrityScore ?? 82);
  const trustScore = clamp(Math.round((reliability?.overallTrustScore ?? 78) + (identityVerified ? 4 : 0) + (licenseVerified ? 8 : 0) + (shopVerified ? 4 : 0) - getReviewPenalty(state, barberId) - getOpenRiskPenalty(state, barberId)), 48, 100);
  const completionRate = Math.round(reliability?.completionRate ?? 88);
  const trustLabel = trustScore >= 92 ? "Trusted Pro" : trustScore >= 84 ? "Trusted Barber" : undefined;
  const badgeLabels = uniqueStrings([
    identityVerified ? "Verified barber" : "",
    licenseVerified ? "Verified license" : "",
    shopVerified ? "Verified shop" : "",
    ...state.trustBadges.filter((badge) => badge.scopeType === "barber" && badge.scopeId === barberId && badge.publicVisible).map((badge) => badge.label),
    ...state.trustBadges.filter((badge) => badge.scopeType === "shop" && badge.scopeId === shopId && badge.publicVisible).map((badge) => badge.label),
    trustLabel ?? ""
  ]);
  return { barberId, shopId, trustScore, completionRate, reviewIntegrityScore, verifiedBarber: identityVerified, verifiedLicense: licenseVerified, verifiedShop: shopVerified, trustLabel, publicBadgeLabels: badgeLabels, reliabilityLabel: completionRate >= 96 ? "High booking reliability" : completionRate >= 90 ? "Strong completion record" : "Building reliability history", reviewIntegrityLabel: reviewIntegrityScore >= 94 ? "Verified review integrity" : reviewIntegrityScore >= 84 ? "Review integrity monitored" : "Review watch", moderationState: reviewIntegrityScore >= 84 ? "clear" : "watch" };
}

function buildBarberVerificationView(record: BarberVerificationRecord | undefined, fallbackCategory: BarberVerificationCategory): BarberVerificationStatusView {
  const status = record?.verificationStatus ?? "unverified";
  const nextStep = status === "verified" ? "Verification complete." : status === "pending" ? "Waiting on trust review." : status === "expired" ? "Upload a renewal document to restore the badge." : status === "rejected" ? "Review notes and resubmit updated documentation." : "Submit documentation to unlock this trust badge.";
  return { category: record?.category ?? fallbackCategory, label: getVerificationLabel(record?.category ?? fallbackCategory), status, submittedAt: record?.verificationSubmittedAt, reviewedAt: record?.verificationReviewedAt, expiresAt: record?.expirationDate, notes: record?.verificationNotes, nextStep };
}

export function getBarberTrustSummary(state: TrustState, barberId: string): BarberTrustWorkspaceSummary {
  const verificationItems = BARBER_CATEGORIES.map((category) => buildBarberVerificationView(getBarberVerificationRecord(state, barberId, category), category));
  const publicTrust = buildPublicTrustSignal(state, barberId, "shop-bvrb3r");
  const overallStatus = verificationItems.every((item) => item.status === "verified") ? "verified" : verificationItems.some((item) => item.status === "pending") ? "pending" : verificationItems.some((item) => item.status === "expired") ? "expired" : verificationItems.some((item) => item.status === "rejected") ? "rejected" : "unverified";
  const activeRiskFlags = state.riskFlags.filter((flag) => flag.entityType === "barber" && flag.entityId === barberId && flag.open).map((flag) => ({ signalType: flag.signalType, severity: flag.severity, label: flag.notes }));
  return { barberId, overallStatus, verificationProgress: Math.round((verificationItems.reduce((sum, item) => sum + getStatusWeight(item.status), 0) / verificationItems.length) * 100), trustScore: publicTrust.trustScore, completionRate: publicTrust.completionRate, publicBadgePreview: publicTrust.publicBadgeLabels, verificationItems, openReports: state.safetyReports.filter((report) => report.subjectType === "barber" && report.subjectId === barberId && isOpenReport(report.status)).length, openDisputes: state.disputes.filter((dispute) => dispute.involvedPartyType === "barber" && dispute.involvedPartyId === barberId && isOpenDispute(dispute.disputeStatus)).length, activeRiskFlags, reminders: uniqueStrings([verificationItems.filter((item) => item.status !== "verified").map((item) => item.nextStep).join(" "), publicTrust.trustLabel ? `Public trust signal live: ${publicTrust.trustLabel}.` : "", activeRiskFlags.length ? "One or more trust signals need review before they affect long-term ranking performance." : ""]).filter(Boolean) };
}

export function getOwnerTrustSummary(state: TrustState, locationIds: string[]): OwnerTrustWorkspaceSummary {
  const scopedLocations = locationIds.length ? locationIds : demoLocations.map((location) => location.id);
  const scopedBarbers = demoBarbers.filter((barber) => barber.locationIds.some((locationId) => scopedLocations.includes(locationId)));
  const scopedBarberIds = new Set(scopedBarbers.map((barber) => barber.id));
  const allStatuses = scopedBarbers.map((barber) => getBarberTrustSummary(state, barber.id).overallStatus);
  const shopStatuses = demoShops.filter((shop) => shop.locationIds.some((locationId) => scopedLocations.includes(locationId))).map((shop) => { const records = state.shopVerifications.filter((record) => record.shopId === shop.id); const status: VerificationStatus = records.every((record) => record.verificationStatus === "verified") ? "verified" : records.some((record) => record.verificationStatus === "pending") ? "pending" : records.some((record) => record.verificationStatus === "expired") ? "expired" : records.some((record) => record.verificationStatus === "rejected") ? "rejected" : "unverified"; return { shopId: shop.id, shopName: shop.name, status, badgeLabel: status === "verified" ? "Verified shop" : status === "pending" ? "Verification pending" : "Verification needed", verifiedCategories: records.filter((record) => record.verificationStatus === "verified").map((record) => record.category) }; });
  return {
    shopStatuses,
    staffVerification: { verified: allStatuses.filter((status) => status === "verified").length, pending: allStatuses.filter((status) => status === "pending").length, expired: allStatuses.filter((status) => status === "expired").length, rejected: allStatuses.filter((status) => status === "rejected").length, unverified: allStatuses.filter((status) => status === "unverified").length },
    openReports: state.safetyReports.filter((report) => isOpenReport(report.status) && (report.locationId ? scopedLocations.includes(report.locationId) : true)).length,
    openDisputes: state.disputes.filter((dispute) => isOpenDispute(dispute.disputeStatus) && (dispute.locationId ? scopedLocations.includes(dispute.locationId) : true)).length,
    highRiskFlags: state.riskFlags.filter((flag) => flag.open && flag.severity === "high").length,
    reviewIntegrityAlerts: state.reviewModeration.filter((record) => scopedBarberIds.has(record.barberId) && ["flagged", "under_review", "removed"].includes(record.moderationStatus)).length,
    pendingBarbers: scopedBarbers.map((barber) => ({ barber, summary: getBarberTrustSummary(state, barber.id) })).filter((entry) => entry.summary.overallStatus !== "verified").map((entry) => ({ barberId: entry.barber.id, barberName: entry.barber.name, status: entry.summary.overallStatus, nextStep: entry.summary.verificationItems.find((item) => item.status !== "verified")?.nextStep ?? "Review trust checklist." })).slice(0, 4),
    recentQueue: [
      ...state.safetyReports.filter((report) => isOpenReport(report.status) && (report.locationId ? scopedLocations.includes(report.locationId) : true)).map((report) => ({ id: report.id, type: "report" as const, label: `${report.category.replaceAll("_", " ")} report on ${report.subjectType}`, status: report.status, createdAt: report.createdAt })),
      ...state.disputes.filter((dispute) => isOpenDispute(dispute.disputeStatus) && (dispute.locationId ? scopedLocations.includes(dispute.locationId) : true)).map((dispute) => ({ id: dispute.id, type: "dispute" as const, label: `${dispute.disputeType.replaceAll("_", " ")} dispute`, status: dispute.disputeStatus, createdAt: dispute.createdAt })),
      ...state.barberVerifications.filter((record) => scopedBarberIds.has(record.barberId) && record.verificationStatus !== "verified").map((record) => ({ id: record.id, type: "verification" as const, label: `${demoBarbers.find((barber) => barber.id === record.barberId)?.name ?? record.barberId} ${getVerificationLabel(record.category).toLowerCase()}`, status: record.verificationStatus, createdAt: record.verificationSubmittedAt ?? record.updatedAt })),
      ...state.riskFlags.filter((flag) => flag.open).map((flag) => ({ id: flag.id, type: "risk_flag" as const, label: `${flag.signalType.replaceAll("_", " ")} flagged`, status: "under_review" as const, createdAt: flag.createdAt }))
    ].sort((left, right) => right.createdAt.localeCompare(left.createdAt)).slice(0, 6),
    shopTrustBadges: uniqueStrings(state.trustBadges.filter((badge) => badge.scopeType === "shop" && badge.publicVisible).map((badge) => badge.label))
  };
}

export function submitBarberVerification(state: TrustState, actor: TrustActor, input: SubmitBarberVerificationInput) {
  if (!actor.barberId || !["commission_barber", "booth_rent_barber"].includes(actor.role)) throw new TrustPermissionError("Only a barber can submit their own verification updates.");
  if (!input.legalName.trim()) throw new TrustValidationError("A legal name is required to submit verification.");
  if (input.category === "license_verification" && (!input.licenseNumber || !input.issuingState || !input.expirationDate)) throw new TrustValidationError("License number, issuing state, and expiration date are required for license verification.");
  const now = new Date().toISOString();
  const existing = getBarberVerificationRecord(state, actor.barberId, input.category);
  const verification: BarberVerificationRecord = { id: existing?.id ?? createId("barber-verification"), barberId: actor.barberId, category: input.category, legalName: input.legalName.trim(), licenseType: input.licenseType?.trim() || undefined, licenseNumber: input.licenseNumber?.trim() || undefined, issuingState: input.issuingState?.trim() || undefined, expirationDate: input.expirationDate || undefined, verificationStatus: "pending", verificationSubmittedAt: now, verificationReviewedAt: existing?.verificationReviewedAt, verificationNotes: "Submission received and queued for trust review.", documentPath: input.documentPath ?? existing?.documentPath, updatedAt: now };
  const document = input.documentPath ? { id: createId("verification-document"), ownerType: "barber" as const, ownerId: actor.barberId, category: input.category, storagePath: input.documentPath, uploadedAt: now, expiresAt: input.expirationDate } : undefined;
  return { state: { ...state, barberVerifications: [verification, ...state.barberVerifications.filter((record) => !(record.barberId === actor.barberId && record.category === input.category))], verificationDocuments: document ? [document, ...state.verificationDocuments] : state.verificationDocuments }, verification, document };
}

export function submitShopVerification(state: TrustState, actor: TrustActor, input: SubmitShopVerificationInput) {
  if (actor.role !== "owner") throw new TrustPermissionError("Only the owner can submit shop verification updates.");
  if (!input.businessName.trim()) throw new TrustValidationError("A business name is required to submit shop verification.");
  const now = new Date().toISOString();
  const existing = state.shopVerifications.find((record) => record.shopId === input.shopId && record.category === input.category);
  const verification: ShopVerificationRecord = { id: existing?.id ?? createId("shop-verification"), shopId: input.shopId, category: input.category, businessName: input.businessName.trim(), verificationStatus: "pending", verificationSubmittedAt: now, verificationReviewedAt: existing?.verificationReviewedAt, verificationNotes: "Submission received and queued for trust review.", documentPath: input.documentPath ?? existing?.documentPath, updatedAt: now };
  const document = input.documentPath ? { id: createId("verification-document"), ownerType: "shop" as const, ownerId: input.shopId, category: input.category, storagePath: input.documentPath, uploadedAt: now, expiresAt: undefined } : undefined;
  return { state: { ...state, shopVerifications: [verification, ...state.shopVerifications.filter((record) => !(record.shopId === input.shopId && record.category === input.category))], verificationDocuments: document ? [document, ...state.verificationDocuments] : state.verificationDocuments }, verification, document };
}
export function submitSafetyReport(state: TrustState, actor: TrustActor, input: SubmitSafetyReportInput) {
  if (!["client", "commission_barber", "booth_rent_barber", "owner"].includes(actor.role)) throw new TrustPermissionError("You do not have access to submit a safety report.");
  if (!REPORT_SUBJECTS[actor.role].includes(input.subjectType)) throw new TrustPermissionError("This role cannot report that kind of subject.");
  if (input.details.trim().length < 12) throw new TrustValidationError("Please include a short explanation so the trust team can understand the concern.");
  const reporterId = actor.clientId ?? actor.barberId ?? actor.userEmail; if (!reporterId) throw new TrustValidationError("A valid reporting identity is required.");
  const now = new Date().toISOString();
  const report = { id: createId("safety-report"), reporterRole: actor.role, reporterId, reporterEmail: actor.userEmail, subjectType: input.subjectType, subjectId: input.subjectId, category: input.category, details: input.details.trim(), status: "open" as const, locationId: input.locationId, createdAt: now, updatedAt: now };
  const reportEvent = { id: createId("report-event"), reportId: report.id, actorRole: actor.role, actorId: reporterId, actionLabel: "Report submitted", notes: report.details, createdAt: now };
  const riskFlag = input.category === "fake_profile" || input.category === "fake_review" ? { id: createId("risk-flag"), entityType: input.subjectType === "review" ? "review" as const : input.subjectType === "barber" ? "barber" as const : input.subjectType === "shop" ? "shop" as const : "booking" as const, entityId: input.subjectId, signalType: input.category === "fake_review" ? "suspicious_review_pattern" as const : "duplicate_account_indicator" as const, severity: "medium" as const, score: 60, publicImpact: true, open: true, notes: `Raised from ${input.category.replaceAll("_", " ")} report.`, createdAt: now } : undefined;
  return { state: { ...state, safetyReports: [report, ...state.safetyReports], reportEvents: [reportEvent, ...state.reportEvents], riskFlags: riskFlag ? [riskFlag, ...state.riskFlags] : state.riskFlags }, report, reportEvent, riskFlag };
}

export function submitDispute(state: TrustState, actor: TrustActor, input: SubmitDisputeInput) {
  if (!["client", "commission_barber", "booth_rent_barber", "owner"].includes(actor.role)) throw new TrustPermissionError("You do not have access to submit a dispute.");
  if (input.summary.trim().length < 12) throw new TrustValidationError("Please include enough detail for the dispute team to review the request.");
  const submittedById = actor.clientId ?? actor.barberId ?? actor.userEmail; if (!submittedById) throw new TrustValidationError("A valid dispute identity is required.");
  const now = new Date().toISOString();
  const dispute = { id: createId("dispute"), disputeType: input.disputeType, disputeStatus: "open" as const, submittedByRole: actor.role, submittedById, involvedPartyType: input.involvedPartyType, involvedPartyId: input.involvedPartyId, appointmentId: input.appointmentId, locationId: input.locationId, summary: input.summary.trim(), createdAt: now, updatedAt: now };
  const disputeEvent = { id: createId("dispute-event"), disputeId: dispute.id, actorRole: actor.role, actorId: submittedById, actionLabel: "Dispute submitted", notes: dispute.summary, createdAt: now };
  return { state: { ...state, disputes: [dispute, ...state.disputes], disputeEvents: [disputeEvent, ...state.disputeEvents] }, dispute, disputeEvent };
}



