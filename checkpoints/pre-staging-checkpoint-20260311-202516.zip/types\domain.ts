﻿export type Role =
  | "owner"
  | "manager"
  | "front_desk"
  | "commission_barber"
  | "booth_rent_barber"
  | "client";

export type CompensationModel = "commission" | "booth_rent";
export type AppointmentStatus = "booked" | "checked_in" | "in_service" | "completed" | "cancelled" | "no_show";
export type WalkInStatus = "waiting" | "assigned" | "in_service" | "completed";
export type RentStatus = "paid" | "due" | "overdue";
export type ReviewSentiment = "great" | "good" | "watch";
export type AuthRuntimeMode = "supabase" | "demo";
export type PaymentProviderKind = "stripe" | "mock";
export type ServiceOwnerType = "barber" | "shop";
export type MarketplaceBadge = "verified_license" | "verified_identity" | "verified_shop" | "top_barber" | "rising_barber";
export type MarketplaceVisibilityState = "public" | "featured" | "hidden";
export type MarketplaceSourceKind = "direct" | "discovery" | "public_profile" | "haircut_now" | "client_dashboard";
export type MarketplaceConversionEventType =
  | "discovery_impression"
  | "profile_view"
  | "booking_cta_clicked"
  | "booking_created"
  | "booking_completed"
  | "waitlist_joined"
  | "follow_created"
  | "haircut_now_impression"
  | "profile_shared"
  | "referral_shared";

export interface UserAccount {
  id: string;
  role: Role;
  email: string;
  password: string;
  name: string;
  title: string;
  locationIds: string[];
  barberId?: string;
  clientId?: string;
}

export interface Location {
  id: string;
  name: string;
  neighborhood: string;
  city: string;
  state: string;
  phone: string;
  hours: string;
  chairs: number;
  taxRate: number;
  address?: string;
  latitude?: number;
  longitude?: number;
}

export interface Shop {
  id: string;
  name: string;
  brandLine: string;
  phone: string;
  locationIds: string[];
  type: "shop" | "mobile";
}

export interface ServicePopularityMetrics {
  bookingCount: number;
  revenueGenerated: number;
  averageRating: number;
  repeatRate: number;
  popularityRank: number;
}

export interface PersistedServicePopularityRow {
  serviceId: string;
  metrics: ServicePopularityMetrics;
}

export interface BarberRankingInput {
  barberId: string;
  distanceScore: number;
  averageRatingScore: number;
  reviewVolumeScore: number;
  retentionScore: number;
  availabilityScore: number;
  portfolioEngagementScore: number;
  followCount: number;
  reputationScore: number;
  servicePopularityScore: number;
  rebookingScore: number;
  conversionScore: number;
  visibilityScore: number;
  rankingScore: number;
  label?: string;
}

export interface Service {
  id: string;
  category: string;
  name: string;
  description: string;
  durationMin: number;
  bufferMin: number;
  price: number;
  deposit: number;
  fullPrepay: boolean;
  addOnIds: string[];
  ownerType?: ServiceOwnerType;
  barberId?: string;
  shopId?: string;
  styleTagIds?: string[];
}

export interface Barber {
  id: string;
  userId: string;
  name: string;
  role: Extract<Role, "commission_barber" | "booth_rent_barber">;
  locationIds: string[];
  specialties: string[];
  rating: number;
  reviewCount: number;
  compensationModel: CompensationModel;
  commissionRate?: number;
  boothRentAmount?: number;
  boothRentFrequency?: "weekly" | "monthly";
  todayEarnings: number;
  upcomingPayout: number;
  availabilityLabel: string;
  bio: string;
  bookingLink: string;
}

export interface BarberProfile {
  id: string;
  barberId: string;
  username: string;
  photoAccent: string;
  yearsExperience: number;
  shopId?: string;
  headline: string;
  specialties: string[];
  badges: MarketplaceBadge[];
  nextAvailableAt: string;
  serviceAreaLabel: string;
  visibilityState: MarketplaceVisibilityState;
}

export interface BarberPortfolioAsset {
  id: string;
  barberId: string;
  imageUrl: string;
  caption: string;
  styleTagIds: string[];
  featured: boolean;
}

export interface StyleTag {
  id: string;
  name: string;
  slug: string;
  category: "cut" | "beard" | "finish" | "kids" | "style";
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  email: string;
  favoriteBarberId?: string;
  loyaltyPoints: number;
  retentionTag: "new" | "repeat" | "lapsed" | "vip";
  notes: string[];
}

export interface Appointment {
  id: string;
  locationId: string;
  barberId: string;
  clientId: string;
  serviceId: string;
  status: AppointmentStatus;
  start: string;
  end: string;
  chair: string;
  addOnIds: string[];
  depositAmount: number;
  totalAmount: number;
  balanceDue: number;
  tipAmount: number;
  note: string;
  source: "booking" | "walk_in" | "front_desk";
}

export interface WaitlistEntry {
  id: string;
  locationId: string;
  clientId: string;
  serviceId: string;
  requestedDate: string;
  preferredWindow: string;
  barberPreference?: string;
}

export interface WalkInEntry {
  id: string;
  locationId: string;
  clientName: string;
  requestedService: string;
  requestedAt: string;
  status: WalkInStatus;
  assignedBarberId?: string;
  waitMinutes: number;
}

export interface BoothRentLedgerEntry {
  id: string;
  barberId: string;
  periodLabel: string;
  dueDate: string;
  amount: number;
  status: RentStatus;
  paidDate?: string;
}

export interface Review {
  id: string;
  barberId: string;
  clientId: string;
  locationId: string;
  rating: number;
  sentiment: ReviewSentiment;
  message: string;
  createdAt: string;
}

export interface TaskItem {
  id: string;
  locationId: string;
  title: string;
  assignee: string;
  status: "open" | "in_progress" | "done";
  priority: "low" | "medium" | "high";
}

export interface InventoryItem {
  id: string;
  locationId: string;
  name: string;
  stock: number;
  reorderAt: number;
}

export interface NotificationItem {
  id: string;
  audience: Role | "all_staff";
  title: string;
  body: string;
  channel: "in_app" | "sms" | "email";
  scheduledFor: string;
  status: "scheduled" | "sent" | "placeholder";
}

export interface AuditLogItem {
  id: string;
  actor: string;
  action: string;
  target: string;
  createdAt: string;
  severity: "info" | "warning" | "critical";
}

export interface KpiMetric {
  label: string;
  value: string;
  delta: string;
}

export interface RevenuePoint {
  label: string;
  revenue: number;
  appointments: number;
}

export interface PermissionGroup {
  role: Role;
  allows: string[];
  restricted: string[];
}

export interface PaymentCustomerRecord {
  id: string;
  profileId: string;
  provider: PaymentProviderKind;
  providerCustomerId: string;
  defaultPaymentMethodId?: string;
}

export interface SavedPaymentMethodSummary {
  id: string;
  brand: string;
  last4: string;
  expMonth: number;
  expYear: number;
  isDefault: boolean;
}

export interface MarketplaceVisibility {
  barberId: string;
  visibilityState: MarketplaceVisibilityState;
  acceptsInstantBookings: boolean;
  featuredRank?: number;
}

export interface FeaturedProfile {
  id: string;
  barberId: string;
  label: string;
}

export interface SearchHistoryEntry {
  id: string;
  clientId: string;
  query: string;
  filters: Record<string, string | number | boolean | undefined>;
  searchedAt: string;
}

export interface ClientPreference {
  clientId: string;
  favoriteShopId?: string;
  preferredLocationId?: string;
  preferredStyleTagIds: string[];
  prefersInstantBooking: boolean;
}

export interface TrendingStyle {
  id: string;
  styleTagId: string;
  regionLabel: string;
  bookingCount: number;
  rank: number;
}

export interface LocationSearchIndexEntry {
  id: string;
  locationId: string;
  shopId?: string;
  barberId?: string;
  latitude: number;
  longitude: number;
  distanceMiles: number;
}

export interface DiscoveryFilters {
  query?: string;
  locationId?: string;
  styleTagId?: string;
  minRating?: number;
  maxPrice?: number;
  availability?: "any" | "today" | "now";
  specialty?: string;
  maxDistanceMiles?: number;
}

export interface DiscoveryResult {
  barberId: string;
  username: string;
  barberName: string;
  rating: number;
  reviewCount: number;
  priceRange: [number, number];
  nextAvailableAt: string;
  distanceMiles: number;
  shopName?: string;
  specialties: string[];
  mostBookedService?: string;
  badges: MarketplaceBadge[];
  followCount?: number;
  reputationScore?: number;
  reputationTier?: string;
  rankingLabel?: string;
  profileViews?: number;
  trustScore?: number;
  completionRate?: number;
  trustLabel?: string;
  reviewIntegrityLabel?: string;
  featuredLabel?: string;
  boostedLabel?: string;
  cityLabel?: string;
  monetizationEligible?: boolean;
  bookingHref?: string;
}

export interface MapDiscoveryMarker {
  id: string;
  kind: "barber" | "shop" | "mobile_barber";
  label: string;
  latitude: number;
  longitude: number;
  rating: number;
  priceRangeLabel: string;
  nextAvailableAt: string;
  shopName?: string;
  barberId?: string;
  username?: string;
  distanceMiles?: number;
  trustLabel?: string;
  featuredLabel?: string;
  cityLabel?: string;
  bookingHref?: string;
}

export interface HaircutNowMatch {
  barberId: string;
  username: string;
  barberName: string;
  matchedFrom: "favorite_barber" | "favorite_shop" | "nearby" | "available_now";
  matchReason: string;
  appointmentTime: string;
  locationId: string;
  shopName?: string;
  priceFrom: number;
  rating: number;
}

export interface MarketplaceBookingAttribution {
  appointmentId: string;
  barberId: string;
  username?: string;
  clientId?: string;
  clientEmail?: string;
  locationId?: string;
  sourceKind: MarketplaceSourceKind;
  matchedFrom?: HaircutNowMatch["matchedFrom"];
  discoveryQuery?: string;
  createdAt: string;
  metadata?: Record<string, string | number | boolean | null>;
}

export interface MarketplaceConversionEvent {
  id: string;
  eventType: MarketplaceConversionEventType;
  barberId?: string;
  username?: string;
  clientId?: string;
  clientEmail?: string;
  appointmentId?: string;
  locationId?: string;
  sourceKind: MarketplaceSourceKind;
  sourceReference?: string;
  metadata: Record<string, string | number | boolean | null>;
  createdAt: string;
}




