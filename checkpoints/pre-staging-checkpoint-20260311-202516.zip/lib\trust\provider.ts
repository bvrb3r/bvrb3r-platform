﻿/* eslint-disable @typescript-eslint/no-explicit-any */
import { isSupabaseEnabled } from "@/lib/config/runtime";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
import {
  createInitialTrustState,
  submitBarberVerification as submitBarberVerificationInState,
  submitShopVerification as submitShopVerificationInState,
  submitDispute as submitDisputeInState,
  submitSafetyReport as submitSafetyReportInState,
  type SubmitBarberVerificationInput,
  type SubmitDisputeInput,
  type SubmitShopVerificationInput,
  type SubmitSafetyReportInput,
  type TrustActor
} from "@/lib/trust/engine";
import { getTrustState, setTrustState } from "@/lib/trust/state";
import type { TrustState } from "@/types/trust";

type SupabaseClient = NonNullable<ReturnType<typeof createSupabaseAdminClient>>;

type VerificationResult = ReturnType<typeof submitBarberVerificationInState>;
type ShopVerificationResult = ReturnType<typeof submitShopVerificationInState>;
type SafetyReportResult = ReturnType<typeof submitSafetyReportInState>;
type DisputeResult = ReturnType<typeof submitDisputeInState>;

export interface TrustProvider {
  kind: "demo" | "supabase";
  readState(): Promise<TrustState>;
  submitBarberVerification(actor: TrustActor, input: SubmitBarberVerificationInput): Promise<VerificationResult>;
  submitShopVerification(actor: TrustActor, input: SubmitShopVerificationInput): Promise<ShopVerificationResult>;
  submitSafetyReport(actor: TrustActor, input: SubmitSafetyReportInput): Promise<SafetyReportResult>;
  submitDispute(actor: TrustActor, input: SubmitDisputeInput): Promise<DisputeResult>;
}

const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;

function assertNoError(result: { error: unknown }) {
  if (result.error) {
    throw result.error;
  }
}

async function hasRows(supabase: SupabaseClient, table: string) {
  const result = await supabase.from(table).select("*").limit(1);
  assertNoError(result);
  return (result.data ?? []).length > 0;
}

async function insertRows(supabase: SupabaseClient, table: string, rows: Record<string, unknown>[]) {
  if (!rows.length) {
    return;
  }

  const result = await supabase.from(table).insert(rows);
  assertNoError(result);
}

async function upsertRows(supabase: SupabaseClient, table: string, rows: Record<string, unknown>[], onConflict: string) {
  if (!rows.length) {
    return;
  }

  const result = await supabase.from(table).upsert(rows, { onConflict });
  assertNoError(result);
}

async function ensureSupabaseSeeded(supabase: SupabaseClient) {
  if (await hasRows(supabase, "barber_verifications")) {
    return;
  }

  const state = createInitialTrustState();

  await Promise.all([
    upsertRows(
      supabase,
      "barber_verifications",
      state.barberVerifications.map((record) => ({
        id: record.id,
        barber_reference: record.barberId,
        category: record.category,
        legal_name: record.legalName,
        license_type: record.licenseType ?? null,
        license_number: record.licenseNumber ?? null,
        issuing_state: record.issuingState ?? null,
        expiration_date: record.expirationDate ?? null,
        verification_status: record.verificationStatus,
        verification_submitted_at: record.verificationSubmittedAt ?? null,
        verification_reviewed_at: record.verificationReviewedAt ?? null,
        verification_notes: record.verificationNotes ?? null,
        document_path: record.documentPath ?? null,
        updated_at: record.updatedAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "shop_verifications",
      state.shopVerifications.map((record) => ({
        id: record.id,
        shop_reference: record.shopId,
        category: record.category,
        business_name: record.businessName,
        verification_status: record.verificationStatus,
        verification_submitted_at: record.verificationSubmittedAt ?? null,
        verification_reviewed_at: record.verificationReviewedAt ?? null,
        verification_notes: record.verificationNotes ?? null,
        document_path: record.documentPath ?? null,
        updated_at: record.updatedAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "verification_documents",
      state.verificationDocuments.map((record) => ({
        id: record.id,
        owner_type: record.ownerType,
        owner_reference: record.ownerId,
        category: record.category,
        storage_path: record.storagePath,
        uploaded_at: record.uploadedAt,
        expires_at: record.expiresAt ?? null
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "trust_badges",
      state.trustBadges.map((record) => ({
        id: record.id,
        scope_type: record.scopeType,
        scope_reference: record.scopeId,
        badge_kind: record.badge,
        label: record.label,
        public_visible: record.publicVisible,
        granted_at: record.grantedAt,
        expires_at: record.expiresAt ?? null
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "review_moderation",
      state.reviewModeration.map((record) => ({
        id: record.id,
        review_reference: record.reviewId,
        barber_reference: record.barberId,
        client_reference: record.clientId,
        appointment_reference: record.appointmentId ?? null,
        eligible: record.eligible,
        moderation_status: record.moderationStatus,
        suspicious_flags: record.suspiciousFlags,
        abuse_reported: record.abuseReported,
        integrity_score: record.integrityScore,
        reviewed_at: record.reviewedAt ?? null,
        created_at: record.createdAt,
        updated_at: record.updatedAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "safety_reports",
      state.safetyReports.map((record) => ({
        id: record.id,
        reporter_role: record.reporterRole,
        reporter_reference: record.reporterId,
        reporter_email: record.reporterEmail ?? null,
        subject_type: record.subjectType,
        subject_reference: record.subjectId,
        category: record.category,
        details: record.details,
        status: record.status,
        location_reference: record.locationId ?? null,
        created_at: record.createdAt,
        updated_at: record.updatedAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "report_events",
      state.reportEvents.map((record) => ({
        id: record.id,
        report_reference: record.reportId,
        actor_role: record.actorRole,
        actor_reference: record.actorId,
        action_label: record.actionLabel,
        notes: record.notes ?? null,
        created_at: record.createdAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "disputes",
      state.disputes.map((record) => ({
        id: record.id,
        dispute_type: record.disputeType,
        dispute_status: record.disputeStatus,
        submitted_by_role: record.submittedByRole,
        submitted_by_reference: record.submittedById,
        involved_party_type: record.involvedPartyType,
        involved_party_reference: record.involvedPartyId,
        appointment_reference: record.appointmentId ?? null,
        location_reference: record.locationId ?? null,
        summary: record.summary,
        resolution_notes: record.resolutionNotes ?? null,
        created_at: record.createdAt,
        updated_at: record.updatedAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "dispute_events",
      state.disputeEvents.map((record) => ({
        id: record.id,
        dispute_reference: record.disputeId,
        actor_role: record.actorRole,
        actor_reference: record.actorId,
        action_label: record.actionLabel,
        notes: record.notes ?? null,
        created_at: record.createdAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "risk_flags",
      state.riskFlags.map((record) => ({
        id: record.id,
        entity_type: record.entityType,
        entity_reference: record.entityId,
        signal_type: record.signalType,
        severity: record.severity,
        score: record.score,
        public_impact: record.publicImpact,
        is_open: record.open,
        notes: record.notes,
        created_at: record.createdAt,
        resolved_at: record.resolvedAt ?? null
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "moderation_actions",
      state.moderationActions.map((record) => ({
        id: record.id,
        target_type: record.targetType,
        target_reference: record.targetId,
        action_label: record.actionLabel,
        actor_role: record.actorRole,
        actor_reference: record.actorId,
        created_at: record.createdAt
      })),
      "id"
    ),
    upsertRows(
      supabase,
      "reliability_scores",
      state.reliabilityScores.map((record) => ({
        barber_reference: record.barberId,
        completion_rate: record.completionRate,
        on_time_rate: record.onTimeRate,
        rebooking_rate: record.rebookingRate,
        review_integrity_score: record.reviewIntegrityScore,
        overall_trust_score: record.overallTrustScore,
        updated_at: record.updatedAt
      })),
      "barber_reference"
    )
  ]);
}

async function readSupabaseState(supabase: SupabaseClient): Promise<TrustState> {
  await ensureSupabaseSeeded(supabase);

  const results = await Promise.all([
    supabase.from("barber_verifications").select("*").order("updated_at", { ascending: false }),
    supabase.from("shop_verifications").select("*").order("updated_at", { ascending: false }),
    supabase.from("verification_documents").select("*").order("uploaded_at", { ascending: false }),
    supabase.from("trust_badges").select("*").order("granted_at", { ascending: false }),
    supabase.from("review_moderation").select("*").order("updated_at", { ascending: false }),
    supabase.from("safety_reports").select("*").order("created_at", { ascending: false }),
    supabase.from("report_events").select("*").order("created_at", { ascending: false }),
    supabase.from("disputes").select("*").order("created_at", { ascending: false }),
    supabase.from("dispute_events").select("*").order("created_at", { ascending: false }),
    supabase.from("risk_flags").select("*").order("created_at", { ascending: false }),
    supabase.from("moderation_actions").select("*").order("created_at", { ascending: false }),
    supabase.from("reliability_scores").select("*").order("updated_at", { ascending: false })
  ]);

  results.forEach(assertNoError);

  const [
    barberVerifications,
    shopVerifications,
    verificationDocuments,
    trustBadges,
    reviewModeration,
    safetyReports,
    reportEvents,
    disputes,
    disputeEvents,
    riskFlags,
    moderationActions,
    reliabilityScores
  ] = results;

  return {
    barberVerifications: (barberVerifications.data ?? []).map((record: any) => ({
      id: record.id,
      barberId: record.barber_reference,
      category: record.category,
      legalName: record.legal_name,
      licenseType: record.license_type ?? undefined,
      licenseNumber: record.license_number ?? undefined,
      issuingState: record.issuing_state ?? undefined,
      expirationDate: record.expiration_date ?? undefined,
      verificationStatus: record.verification_status,
      verificationSubmittedAt: record.verification_submitted_at ?? undefined,
      verificationReviewedAt: record.verification_reviewed_at ?? undefined,
      verificationNotes: record.verification_notes ?? undefined,
      documentPath: record.document_path ?? undefined,
      updatedAt: record.updated_at
    })),
    shopVerifications: (shopVerifications.data ?? []).map((record: any) => ({
      id: record.id,
      shopId: record.shop_reference,
      category: record.category,
      businessName: record.business_name,
      verificationStatus: record.verification_status,
      verificationSubmittedAt: record.verification_submitted_at ?? undefined,
      verificationReviewedAt: record.verification_reviewed_at ?? undefined,
      verificationNotes: record.verification_notes ?? undefined,
      documentPath: record.document_path ?? undefined,
      updatedAt: record.updated_at
    })),
    verificationDocuments: (verificationDocuments.data ?? []).map((record: any) => ({
      id: record.id,
      ownerType: record.owner_type,
      ownerId: record.owner_reference,
      category: record.category,
      storagePath: record.storage_path,
      uploadedAt: record.uploaded_at,
      expiresAt: record.expires_at ?? undefined
    })),
    trustBadges: (trustBadges.data ?? []).map((record: any) => ({
      id: record.id,
      scopeType: record.scope_type,
      scopeId: record.scope_reference,
      badge: record.badge_kind,
      label: record.label,
      publicVisible: record.public_visible,
      grantedAt: record.granted_at,
      expiresAt: record.expires_at ?? undefined
    })),
    reviewModeration: (reviewModeration.data ?? []).map((record: any) => ({
      id: record.id,
      reviewId: record.review_reference,
      barberId: record.barber_reference,
      clientId: record.client_reference,
      appointmentId: record.appointment_reference ?? undefined,
      eligible: record.eligible,
      moderationStatus: record.moderation_status,
      suspiciousFlags: record.suspicious_flags ?? [],
      abuseReported: record.abuse_reported,
      integrityScore: Number(record.integrity_score ?? 0),
      reviewedAt: record.reviewed_at ?? undefined,
      createdAt: record.created_at,
      updatedAt: record.updated_at
    })),
    safetyReports: (safetyReports.data ?? []).map((record: any) => ({
      id: record.id,
      reporterRole: record.reporter_role,
      reporterId: record.reporter_reference,
      reporterEmail: record.reporter_email ?? undefined,
      subjectType: record.subject_type,
      subjectId: record.subject_reference,
      category: record.category,
      details: record.details,
      status: record.status,
      locationId: record.location_reference ?? undefined,
      createdAt: record.created_at,
      updatedAt: record.updated_at
    })),
    reportEvents: (reportEvents.data ?? []).map((record: any) => ({
      id: record.id,
      reportId: record.report_reference,
      actorRole: record.actor_role,
      actorId: record.actor_reference,
      actionLabel: record.action_label,
      notes: record.notes ?? undefined,
      createdAt: record.created_at
    })),
    disputes: (disputes.data ?? []).map((record: any) => ({
      id: record.id,
      disputeType: record.dispute_type,
      disputeStatus: record.dispute_status,
      submittedByRole: record.submitted_by_role,
      submittedById: record.submitted_by_reference,
      involvedPartyType: record.involved_party_type,
      involvedPartyId: record.involved_party_reference,
      appointmentId: record.appointment_reference ?? undefined,
      locationId: record.location_reference ?? undefined,
      summary: record.summary,
      resolutionNotes: record.resolution_notes ?? undefined,
      createdAt: record.created_at,
      updatedAt: record.updated_at
    })),
    disputeEvents: (disputeEvents.data ?? []).map((record: any) => ({
      id: record.id,
      disputeId: record.dispute_reference,
      actorRole: record.actor_role,
      actorId: record.actor_reference,
      actionLabel: record.action_label,
      notes: record.notes ?? undefined,
      createdAt: record.created_at
    })),
    riskFlags: (riskFlags.data ?? []).map((record: any) => ({
      id: record.id,
      entityType: record.entity_type,
      entityId: record.entity_reference,
      signalType: record.signal_type,
      severity: record.severity,
      score: Number(record.score ?? 0),
      publicImpact: record.public_impact,
      open: record.is_open,
      notes: record.notes,
      createdAt: record.created_at,
      resolvedAt: record.resolved_at ?? undefined
    })),
    moderationActions: (moderationActions.data ?? []).map((record: any) => ({
      id: record.id,
      targetType: record.target_type,
      targetId: record.target_reference,
      actionLabel: record.action_label,
      actorRole: record.actor_role,
      actorId: record.actor_reference,
      createdAt: record.created_at
    })),
    reliabilityScores: (reliabilityScores.data ?? []).map((record: any) => ({
      barberId: record.barber_reference,
      completionRate: Number(record.completion_rate ?? 0),
      onTimeRate: Number(record.on_time_rate ?? 0),
      rebookingRate: Number(record.rebooking_rate ?? 0),
      reviewIntegrityScore: Number(record.review_integrity_score ?? 0),
      overallTrustScore: Number(record.overall_trust_score ?? 0),
      updatedAt: record.updated_at
    }))
  };
}

function createDemoProvider(): TrustProvider {
  return {
    kind: "demo",
    async readState() {
      return clone(getTrustState());
    },
    async submitBarberVerification(actor, input) {
      const result = submitBarberVerificationInState(getTrustState(), actor, input);
      setTrustState(result.state);
      return result;
    },
    async submitShopVerification(actor, input) {
      const result = submitShopVerificationInState(getTrustState(), actor, input);
      setTrustState(result.state);
      return result;
    },
    async submitSafetyReport(actor, input) {
      const result = submitSafetyReportInState(getTrustState(), actor, input);
      setTrustState(result.state);
      return result;
    },
    async submitDispute(actor, input) {
      const result = submitDisputeInState(getTrustState(), actor, input);
      setTrustState(result.state);
      return result;
    }
  };
}

function createSupabaseProvider(supabase: SupabaseClient): TrustProvider {
  return {
    kind: "supabase",
    async readState() {
      return readSupabaseState(supabase);
    },
    async submitBarberVerification(actor, input) {
      const result = submitBarberVerificationInState(await readSupabaseState(supabase), actor, input);

      await upsertRows(
        supabase,
        "barber_verifications",
        [{
          id: result.verification.id,
          barber_reference: result.verification.barberId,
          category: result.verification.category,
          legal_name: result.verification.legalName,
          license_type: result.verification.licenseType ?? null,
          license_number: result.verification.licenseNumber ?? null,
          issuing_state: result.verification.issuingState ?? null,
          expiration_date: result.verification.expirationDate ?? null,
          verification_status: result.verification.verificationStatus,
          verification_submitted_at: result.verification.verificationSubmittedAt ?? null,
          verification_reviewed_at: result.verification.verificationReviewedAt ?? null,
          verification_notes: result.verification.verificationNotes ?? null,
          document_path: result.verification.documentPath ?? null,
          updated_at: result.verification.updatedAt
        }],
        "id"
      );

      if (result.document) {
        await upsertRows(
          supabase,
          "verification_documents",
          [{
            id: result.document.id,
            owner_type: result.document.ownerType,
            owner_reference: result.document.ownerId,
            category: result.document.category,
            storage_path: result.document.storagePath,
            uploaded_at: result.document.uploadedAt,
            expires_at: result.document.expiresAt ?? null
          }],
          "id"
        );
      }

      return result;
    },
    async submitShopVerification(actor, input) {
      const result = submitShopVerificationInState(await readSupabaseState(supabase), actor, input);

      await upsertRows(
        supabase,
        "shop_verifications",
        [{
          id: result.verification.id,
          shop_reference: result.verification.shopId,
          category: result.verification.category,
          business_name: result.verification.businessName,
          verification_status: result.verification.verificationStatus,
          verification_submitted_at: result.verification.verificationSubmittedAt ?? null,
          verification_reviewed_at: result.verification.verificationReviewedAt ?? null,
          verification_notes: result.verification.verificationNotes ?? null,
          document_path: result.verification.documentPath ?? null,
          updated_at: result.verification.updatedAt
        }],
        "id"
      );

      if (result.document) {
        await upsertRows(
          supabase,
          "verification_documents",
          [{
            id: result.document.id,
            owner_type: result.document.ownerType,
            owner_reference: result.document.ownerId,
            category: result.document.category,
            storage_path: result.document.storagePath,
            uploaded_at: result.document.uploadedAt,
            expires_at: result.document.expiresAt ?? null
          }],
          "id"
        );
      }

      return result;
    },
    async submitSafetyReport(actor, input) {
      const result = submitSafetyReportInState(await readSupabaseState(supabase), actor, input);

      await insertRows(supabase, "safety_reports", [{
        id: result.report.id,
        reporter_role: result.report.reporterRole,
        reporter_reference: result.report.reporterId,
        reporter_email: result.report.reporterEmail ?? null,
        subject_type: result.report.subjectType,
        subject_reference: result.report.subjectId,
        category: result.report.category,
        details: result.report.details,
        status: result.report.status,
        location_reference: result.report.locationId ?? null,
        created_at: result.report.createdAt,
        updated_at: result.report.updatedAt
      }]);

      await insertRows(supabase, "report_events", [{
        id: result.reportEvent.id,
        report_reference: result.reportEvent.reportId,
        actor_role: result.reportEvent.actorRole,
        actor_reference: result.reportEvent.actorId,
        action_label: result.reportEvent.actionLabel,
        notes: result.reportEvent.notes ?? null,
        created_at: result.reportEvent.createdAt
      }]);

      if (result.riskFlag) {
        await insertRows(supabase, "risk_flags", [{
          id: result.riskFlag.id,
          entity_type: result.riskFlag.entityType,
          entity_reference: result.riskFlag.entityId,
          signal_type: result.riskFlag.signalType,
          severity: result.riskFlag.severity,
          score: result.riskFlag.score,
          public_impact: result.riskFlag.publicImpact,
          is_open: result.riskFlag.open,
          notes: result.riskFlag.notes,
          created_at: result.riskFlag.createdAt,
          resolved_at: null
        }]);
      }

      return result;
    },
    async submitDispute(actor, input) {
      const result = submitDisputeInState(await readSupabaseState(supabase), actor, input);

      await insertRows(supabase, "disputes", [{
        id: result.dispute.id,
        dispute_type: result.dispute.disputeType,
        dispute_status: result.dispute.disputeStatus,
        submitted_by_role: result.dispute.submittedByRole,
        submitted_by_reference: result.dispute.submittedById,
        involved_party_type: result.dispute.involvedPartyType,
        involved_party_reference: result.dispute.involvedPartyId,
        appointment_reference: result.dispute.appointmentId ?? null,
        location_reference: result.dispute.locationId ?? null,
        summary: result.dispute.summary,
        resolution_notes: null,
        created_at: result.dispute.createdAt,
        updated_at: result.dispute.updatedAt
      }]);

      await insertRows(supabase, "dispute_events", [{
        id: result.disputeEvent.id,
        dispute_reference: result.disputeEvent.disputeId,
        actor_role: result.disputeEvent.actorRole,
        actor_reference: result.disputeEvent.actorId,
        action_label: result.disputeEvent.actionLabel,
        notes: result.disputeEvent.notes ?? null,
        created_at: result.disputeEvent.createdAt
      }]);

      return result;
    }
  };
}

export async function getTrustProvider(): Promise<TrustProvider> {
  if (!isSupabaseEnabled()) {
    return createDemoProvider();
  }

  const supabase = createSupabaseAdminClient();

  if (!supabase) {
    return createDemoProvider();
  }

  return createSupabaseProvider(supabase);
}





