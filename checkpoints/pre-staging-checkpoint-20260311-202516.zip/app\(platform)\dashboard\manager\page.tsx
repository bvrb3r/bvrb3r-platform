import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { ManagerOverview } from "@/components/operations/manager-overview";
import { getAuthorizedUser } from "@/lib/auth/guards";

export default async function ManagerDashboardPage() {
  const user = await getAuthorizedUser(["manager"]);
  return (
    <DashboardShell
      user={user}
      activeHref="/dashboard/manager"
      title="Shop command center"
      subtitle="Run the entire floor, monitor every chair, direct walk-ins, and keep the shop moving without exposing owner-only controls."
    >
      <ManagerOverview locationIds={user.locationIds} />
    </DashboardShell>
  );
}