import { redirect } from "next/navigation";
import { getDefaultRouteForUser } from "@/lib/auth/demo-auth";
import { getCurrentUserFromServer } from "@/lib/auth/session";
import { Role } from "@/types/domain";

export async function getAuthorizedUser(allowedRoles: Role[]) {
  const { user } = await getCurrentUserFromServer();

  if (!allowedRoles.includes(user.role)) {
    redirect(getDefaultRouteForUser(user));
  }

  return user;
}