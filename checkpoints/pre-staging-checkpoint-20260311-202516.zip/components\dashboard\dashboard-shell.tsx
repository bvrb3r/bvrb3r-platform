import type { Route } from "next";
import Link from "next/link";
import { ArrowUpRight, Bell, CalendarDays, ClipboardList, LayoutDashboard, MapPinned, Scissors, Settings, ShieldCheck, Sparkles, Users } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card";
import { getDefaultRouteForUser, getRoleLabel } from "@/lib/auth/demo-auth";
import { demoLocations } from "@/lib/data/demo";
import { cn } from "@/lib/utils";
import type { Role, UserAccount } from "@/types/domain";

type NavItem = {
  href: Route;
  label: string;
  icon: LucideIcon;
};

function getHomeLabel(role: Role) {
  switch (role) {
    case "owner":
      return "Owner control";
    case "manager":
      return "Shop command";
    case "front_desk":
      return "Live board";
    case "commission_barber":
    case "booth_rent_barber":
      return "My chair";
    case "client":
      return "Client home";
    default:
      return "Dashboard";
  }
}

function getAppointmentsLabel(role: Role) {
  switch (role) {
    case "owner":
      return "Network calendar";
    case "manager":
      return "Shop schedule";
    case "front_desk":
      return "Service tickets";
    case "commission_barber":
    case "booth_rent_barber":
      return "My schedule";
    default:
      return "Appointments";
  }
}

function getServicesLabel(role: Role) {
  switch (role) {
    case "owner":
      return "Service catalog";
    case "commission_barber":
      return "Service menu";
    case "booth_rent_barber":
      return "My services";
    default:
      return "Services";
  }
}

function getClientsLabel(role: Role) {
  switch (role) {
    case "owner":
      return "Client base";
    case "manager":
      return "Client traffic";
    case "front_desk":
      return "Guest records";
    default:
      return "Clients";
  }
}

function getReportsLabel(role: Role) {
  return role === "manager" ? "Floor reports" : "Business reports";
}

function getAlertLabel(role: Role) {
  switch (role) {
    case "owner":
      return "3 strategic alerts pending";
    case "manager":
      return "4 floor alerts pending";
    case "front_desk":
      return "5 desk actions pending";
    case "commission_barber":
    case "booth_rent_barber":
      return "2 chair updates pending";
    case "client":
      return "1 booking reminder pending";
    default:
      return "3 alerts pending";
  }
}

function getLocationScopeLabel(role: Role) {
  switch (role) {
    case "owner":
      return "Business footprint";
    case "manager":
      return "Assigned shop";
    case "front_desk":
      return "Desk coverage";
    case "commission_barber":
    case "booth_rent_barber":
      return "Chair territory";
    case "client":
      return "Preferred shop";
    default:
      return "Location scope";
  }
}

function getPrimaryFocusLabel(role: Role) {
  switch (role) {
    case "owner":
      return "See the business clearly, protect the structure, and move on the numbers first.";
    case "manager":
      return "Run the floor, direct capacity, and keep every chair, queue, and handoff moving.";
    case "front_desk":
      return "Keep the line flowing from arrival to payment with zero confusion at the desk.";
    case "commission_barber":
    case "booth_rent_barber":
      return "Stay focused on your chair, your clients, and exactly how your money moves.";
    case "client":
      return "Book fast, manage your visits, and come back without digging through shop tools.";
    default:
      return "Stay oriented, move quickly, and keep the next action obvious.";
  }
}

function getBoundaryCopy(role: Role) {
  switch (role) {
    case "owner":
      return "Full financial visibility, owner controls, permissions, and structural settings.";
    case "manager":
      return "Floor control, team visibility, and limited approvals without owner-only billing or legal controls.";
    case "front_desk":
      return "Operational ticket flow, client support, queue routing, and checkout only.";
    case "commission_barber":
    case "booth_rent_barber":
      return "Only your appointments, your money, your profile, and your performance stay visible here.";
    case "client":
      return "Only client actions, appointment history, favorites, and booking tools are visible here.";
    default:
      return "Relevant tools only.";
  }
}

function getNavigation(user: UserAccount): NavItem[] {
  const items: NavItem[] = [{ href: getDefaultRouteForUser(user), label: getHomeLabel(user.role), icon: LayoutDashboard }];

  if (user.role === "owner" || user.role === "manager" || user.role === "front_desk" || user.role === "commission_barber" || user.role === "booth_rent_barber") {
    items.push({ href: "/appointments", label: getAppointmentsLabel(user.role), icon: CalendarDays });
  }

  if (user.role === "owner" || user.role === "commission_barber" || user.role === "booth_rent_barber") {
    items.push({ href: "/services", label: getServicesLabel(user.role), icon: Scissors });
  }

  if (user.role === "owner" || user.role === "manager" || user.role === "front_desk") {
    items.push({ href: "/clients", label: getClientsLabel(user.role), icon: Users });
  }

  if (user.role === "owner" || user.role === "manager") {
    items.push({ href: "/reports", label: getReportsLabel(user.role), icon: ClipboardList });
  }

  if (user.role === "owner") {
    items.push({ href: "/settings", label: "Owner settings", icon: Settings });
  }

  if (user.role === "client") {
    items.push({ href: "/booking/new", label: "Book now", icon: Sparkles });
  }

  return items;
}

export function DashboardShell({
  user,
  title,
  subtitle,
  activeHref,
  children
}: {
  user: UserAccount;
  title: string;
  subtitle: string;
  activeHref?: Route;
  children: React.ReactNode;
}) {
  const nav = getNavigation(user);
  const activeRole = getRoleLabel(user.role);
  const visibleLocations = demoLocations.filter((location) => user.locationIds.includes(location.id));
  const mobileNav = nav.slice(0, Math.min(nav.length, 5));

  return (
    <div className="min-h-screen px-3 py-3 pb-[calc(env(safe-area-inset-bottom,0px)+6.5rem)] lg:px-6 lg:py-5 xl:pb-5">
      <div className="mx-auto grid max-w-7xl gap-4 xl:grid-cols-[300px_1fr]">
        <Card className="hidden h-fit rounded-[34px] bg-[linear-gradient(180deg,rgba(16,16,16,0.98),rgba(8,8,8,0.98))] p-4 xl:sticky xl:top-4 xl:block">
          <div className="rounded-[28px] border border-[#7CFF00]/16 bg-[linear-gradient(180deg,rgba(124,255,0,0.12),rgba(124,255,0,0.04))] p-5">
            <p className="surface-label text-[#cfff93]">The BVRB3R Shop(TM)</p>
            <h1 className="mt-3 text-3xl font-semibold" data-display="true">BVRB3R Platform</h1>
            <p className="mt-4 text-sm text-white/60" data-testid="shell-identity-name">{user.name}</p>
            <p className="mt-1 text-[11px] uppercase tracking-[0.22em] text-white/40" data-testid="shell-identity-title">{user.title}</p>
            <div className="mt-4 inline-flex items-center rounded-full border border-white/10 bg-black/35 px-3 py-2 text-[10px] uppercase tracking-[0.22em] text-[#cfff93]" data-testid="shell-identity-role">
              Active role: {activeRole}
            </div>
          </div>

          <div className="mt-5 rounded-[28px] border border-white/8 bg-[linear-gradient(180deg,rgba(20,20,20,0.92),rgba(8,8,8,0.96))] p-4">
            <div className="flex items-start gap-3">
              <div className="mt-1 rounded-full border border-[#7CFF00]/18 bg-[#7CFF00]/10 p-2 text-[#d7ffab]">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <p className="surface-label">Primary focus</p>
                <p className="mt-3 text-sm leading-6 text-white/82">{getPrimaryFocusLabel(user.role)}</p>
                <p className="mt-3 text-sm leading-6 text-white/54">{getBoundaryCopy(user.role)}</p>
              </div>
            </div>
          </div>

          <div className="mt-6">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="surface-label">Navigation</p>
              <span className="rounded-full border border-white/8 bg-black/20 px-3 py-1.5 text-[10px] uppercase tracking-[0.24em] text-white/46">
                {nav.length} lanes
              </span>
            </div>
            <div className="space-y-2">
              {nav.map((item) => {
                const Icon = item.icon;
                const isActive = item.href === activeHref;

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    aria-current={isActive ? "page" : undefined}
                    className={cn(
                      "group flex items-center justify-between rounded-[22px] border px-4 py-3 text-[11px] uppercase tracking-[0.22em] transition hover:-translate-y-0.5",
                      isActive
                        ? "border-[#7CFF00]/28 bg-[linear-gradient(135deg,rgba(124,255,0,0.16),rgba(16,16,16,0.94))] text-white shadow-[0_18px_40px_rgba(124,255,0,0.08)]"
                        : "border-white/6 bg-black/20 text-white/72 hover:border-[#7CFF00]/20 hover:bg-[#121212] hover:text-white"
                    )}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className={cn("h-4 w-4 transition", isActive ? "text-[#d7ffab]" : "text-[#baff69] group-hover:scale-105")} />
                      {item.label}
                    </span>
                    {isActive ? <ArrowUpRight className="h-4 w-4 text-[#d7ffab]" /> : <span className="h-1.5 w-1.5 rounded-full bg-white/12 transition group-hover:bg-[#7cff00]" />}
                  </Link>
                );
              })}
            </div>
          </div>

          <div className="mt-6 rounded-[28px] border border-white/8 bg-[linear-gradient(180deg,rgba(26,26,26,0.9),rgba(10,10,10,0.96))] p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="surface-label">{getLocationScopeLabel(user.role)}</p>
              <MapPinned className="h-4 w-4 text-[#baff69]" />
            </div>
            <div className="mt-4 space-y-3 text-sm text-white/78">
              {visibleLocations.length ? visibleLocations.map((location) => (
                <div key={location.id} className="flex items-center justify-between gap-3 rounded-[20px] border border-white/6 bg-black/25 px-3 py-3">
                  <span>{location.name}</span>
                  <span className="text-[10px] uppercase tracking-[0.22em] text-[#cfff93]">{location.city}</span>
                </div>
              )) : (
                <div className="rounded-[20px] border border-dashed border-white/10 bg-black/25 px-3 py-3 text-white/52">
                  No assigned locations yet.
                </div>
              )}
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="rounded-[30px] border border-white/8 bg-[linear-gradient(180deg,rgba(18,18,18,0.98),rgba(8,8,8,0.98))] p-4 xl:hidden">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="surface-label text-[#cfff93]">The BVRB3R Shop(TM)</p>
                <p className="mt-2 text-2xl font-semibold" data-display="true">BVRB3R Platform</p>
                <p className="mt-3 text-sm text-white/68" data-testid="shell-mobile-identity-name">{user.name}</p>
                <p className="mt-1 text-[11px] uppercase tracking-[0.22em] text-white/40" data-testid="shell-mobile-identity-title">{user.title}</p>
              </div>
              <div className="rounded-[20px] border border-[#7CFF00]/16 bg-[#7CFF00]/8 px-3 py-3 text-right">
                <p className="surface-label text-[#d7ffab]">Active role</p>
                <p className="mt-2 text-sm font-medium text-white" data-testid="shell-mobile-identity-role">{activeRole}</p>
              </div>
            </div>
            <div className="mt-4 rounded-[24px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Primary focus</p>
              <p className="mt-3 text-sm leading-6 text-white/76">{getPrimaryFocusLabel(user.role)}</p>
            </div>
            <div className="mt-4 flex gap-2 overflow-x-auto pb-1 hide-scrollbar">
              {nav.map((item) => {
                const Icon = item.icon;
                const isActive = item.href === activeHref;
                return (
                  <Link
                    key={`mobile-top-${item.href}`}
                    href={item.href}
                    aria-label={`Open mobile ${item.label}`}
                    className={cn(
                      "inline-flex min-w-[9.25rem] items-center gap-3 rounded-[22px] border px-4 py-3 transition",
                      isActive
                        ? "border-[#7CFF00]/26 bg-[#7CFF00]/10 text-white"
                        : "border-white/8 bg-black/20 text-white/70"
                    )}
                  >
                    <Icon className={cn("h-4 w-4", isActive ? "text-[#d7ffab]" : "text-[#baff69]")} />
                    <span aria-hidden="true" className="text-[11px] font-semibold uppercase tracking-[0.22em]">{item.label}</span>
                  </Link>
                );
              })}
            </div>
            <div className="mt-4 flex flex-wrap gap-2 text-[11px] uppercase tracking-[0.22em] text-white/48">
              {visibleLocations.length ? visibleLocations.map((location) => (
                <span key={`mobile-location-${location.id}`} className="status-pill text-white/72">{location.name}</span>
              )) : <span className="status-pill text-white/52">No assigned locations yet</span>}
            </div>
          </Card>

          <Card className="rounded-[34px] bg-[linear-gradient(180deg,rgba(16,16,16,0.98),rgba(8,8,8,0.98))] p-5 sm:p-6">
            <div className="flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
              <div>
                <div className="editorial-kicker">
                  <span className="accent-rule" />
                  Role workspace
                </div>
                <h2 className="mt-3 text-3xl font-semibold sm:text-5xl" data-display="true">{title}</h2>
                <p className="mt-4 max-w-2xl text-sm leading-7 text-white/62">{subtitle}</p>
              </div>
              <div className="grid gap-3 sm:grid-cols-2 xl:w-[26rem]">
                <div className="rounded-[24px] border border-white/8 bg-black/25 p-4">
                  <p className="surface-label">Operating as</p>
                  <p className="mt-3 text-lg font-medium">{activeRole}</p>
                  <p className="mt-2 text-sm text-white/56">{user.name} is seeing only role-relevant tools and data.</p>
                </div>
                <div className="rounded-[24px] border border-white/8 bg-black/25 p-4">
                  <div className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/35 px-3 py-2 text-[10px] uppercase tracking-[0.22em] text-white/68">
                    <Bell className="h-4 w-4 text-[#baff69]" />
                    {getAlertLabel(user.role)}
                  </div>
                  <p className="mt-3 text-sm leading-6 text-white/56">{getBoundaryCopy(user.role)}</p>
                </div>
              </div>
            </div>
          </Card>
          {children}
        </div>
      </div>

      <div className="fixed inset-x-3 bottom-[calc(env(safe-area-inset-bottom,0px)+0.75rem)] z-40 xl:hidden">
        <div className="mobile-dock mx-auto max-w-7xl rounded-[28px] border border-white/10 px-3 py-3 shadow-[0_22px_44px_rgba(0,0,0,0.42)]">
          <div className="flex gap-2 overflow-x-auto hide-scrollbar">
            {mobileNav.map((item) => {
              const Icon = item.icon;
              const isActive = item.href === activeHref;
              return (
                <Link
                  key={`mobile-dock-${item.href}`}
                  href={item.href}
                  aria-label={`Open mobile dock ${item.label}`}
                  aria-current={isActive ? "page" : undefined}
                  className={cn(
                    "flex min-w-[5.7rem] flex-1 flex-col items-center justify-center gap-1 rounded-[22px] border px-3 py-3 text-center transition",
                    isActive
                      ? "border-[#7CFF00]/26 bg-[#7CFF00]/10 text-white"
                      : "border-white/8 bg-black/18 text-white/66 hover:border-[#7CFF00]/20 hover:text-white"
                  )}
                >
                  <Icon className={cn("h-4 w-4", isActive ? "text-[#d7ffab]" : "text-[#baff69]")} />
                  <span aria-hidden="true" className="text-[10px] font-semibold uppercase tracking-[0.18em]">{item.label}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}



