import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { Card } from "@/components/ui/card";
import { getAuthorizedUser } from "@/lib/auth/guards";
import { permissionMatrix } from "@/lib/data/demo";

export default async function SettingsPage() {
  const user = await getAuthorizedUser(["owner"]);
  return (
    <DashboardShell user={user} activeHref="/settings" title="Settings and permissions" subtitle="Owner-protected configuration, permission scoping, and future-ready module flags.">
      <section className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
        <Card className="rounded-[32px] p-6">
          <p className="surface-label">Protected controls</p>
          <div className="mt-4 space-y-3 text-sm text-white/70">
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">Location configuration</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">Commission and booth-rent structures</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">Billing, subscriptions, and payout rules</div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">Franchise and expansion placeholders</div>
          </div>
        </Card>
        <Card className="rounded-[32px] p-6">
          <p className="surface-label">Permission matrix</p>
          <div className="mt-4 space-y-4">
            {permissionMatrix.map((group) => (
              <div key={group.role} className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                <p className="font-medium uppercase tracking-[0.18em] text-[#baff69]">{group.role.replaceAll("_", " ")}</p>
                <p className="mt-3 text-sm text-white/65">Allowed: {group.allows.join(", ")}</p>
                <p className="mt-2 text-sm text-white/45">Restricted: {group.restricted.join(", ") || "None"}</p>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </DashboardShell>
  );
}