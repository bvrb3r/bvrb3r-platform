import { notFound } from "next/navigation";
import { PublicBarberProfile } from "@/components/marketplace/public-barber-profile";
import { getCurrentUserFromServer } from "@/lib/auth/session";
import { getEngagementProvider } from "@/lib/engagement/provider";
import { decoratePublicProfileWithActivation } from "@/lib/marketplace/activation";
import { getMarketplaceActivationProvider } from "@/lib/marketplace/activation-provider";
import { buildPublicProfilePayload, getMarketplaceProvider } from "@/lib/marketplace/provider";
import { getTrustProvider } from "@/lib/trust/provider";

export default async function PublicBarberProfilePage({ params }: { params: Promise<{ username: string }>; }) {
  const { username } = await params;
  const [marketplaceProvider, engagementProvider, trustProvider, activationProvider, session] = await Promise.all([
    getMarketplaceProvider(),
    getEngagementProvider(),
    getTrustProvider(),
    getMarketplaceActivationProvider(),
    getCurrentUserFromServer()
  ]);
  const [runtime, engagementState, trustState, activationState] = await Promise.all([
    marketplaceProvider.readRuntime(),
    engagementProvider.readState(),
    trustProvider.readState(),
    activationProvider.readState()
  ]);
  const profile = buildPublicProfilePayload(runtime, engagementState, trustState, username);
  if (!profile) notFound();
  const decoratedProfile = decoratePublicProfileWithActivation(profile, activationState);
  try {
    await marketplaceProvider.recordProfileView({ barberId: decoratedProfile.barber.id, username, clientId: session.user.role === "client" ? session.user.clientId : undefined });
  } catch {}
  const canReport = ["client", "commission_barber", "booth_rent_barber", "owner"].includes(session.user.role);
  return <PublicBarberProfile profile={decoratedProfile} viewerCanFollow={session.user.role === "client"} viewerCanReport={canReport} />;
}
