import { NextRequest, NextResponse } from "next/server";
import { getPaymentProvider } from "@/lib/payments/provider";

export async function POST(request: NextRequest) {
  const body = await request.json();
  const provider = await getPaymentProvider();
  const intent = await provider.createSavedPaymentMethodSetup({
    customerEmail: body.customerEmail,
    customerName: body.customerName
  });

  return NextResponse.json(intent);
}