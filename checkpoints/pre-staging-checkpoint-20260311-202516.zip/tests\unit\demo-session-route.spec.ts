import { NextRequest } from "next/server";
import { DEMO_SESSION_COOKIE } from "@/lib/auth/demo-auth";
import { GET } from "@/app/auth/demo/route";

describe("demo session route", () => {
  it.each([
    ["owner@bvrb3r.demo", "/dashboard/owner"],
    ["manager@bvrb3r.demo", "/dashboard/manager"],
    ["frontdesk@bvrb3r.demo", "/dashboard/front-desk"],
    ["wave@bvrb3r.demo", "/dashboard/barber"],
    ["blaze@bvrb3r.demo", "/dashboard/barber"],
    ["client@bvrb3r.demo", "/dashboard/client"]
  ])("redirects %s to %s and persists the demo cookie", async (email, route) => {
    const request = new NextRequest(`https://bvrb3r.demo/auth/demo?email=${encodeURIComponent(email)}`);
    const response = await GET(request);

    expect(response.headers.get("location")).toBe(`https://bvrb3r.demo${route}`);
    expect(response.cookies.get(DEMO_SESSION_COOKIE)?.value).toBe(email);
  });
});