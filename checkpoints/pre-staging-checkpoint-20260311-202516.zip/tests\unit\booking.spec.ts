import { calculateBookingQuote, hasScheduleConflict } from "@/lib/utils/booking";
import { demoServices } from "@/lib/data/demo";

describe("booking logic", () => {
  it("calculates deposit and duration including add-ons", () => {
    const service = demoServices.find((entry) => entry.id === "srv-signature");
    const addOn = demoServices.find((entry) => entry.id === "srv-beard");

    expect(service).toBeDefined();
    expect(addOn).toBeDefined();

    const result = calculateBookingQuote(service!, [addOn!]);

    expect(result.subtotal).toBe(73);
    expect(result.depositDue).toBe(15);
    expect(result.totalDuration).toBe(95);
  });

  it("detects overlapping appointments", () => {
    const hasConflict = hasScheduleConflict({
      barberId: "barber-wave",
      serviceId: "srv-signature",
      addOnIds: [],
      start: "2026-03-08T10:30:00-05:00"
    });

    expect(hasConflict).toBe(true);
  });
});