import { beforeEach, describe, expect, it, vi } from "vitest";

const { cookiesMock, isDemoModeMock, createSupabaseServerClientMock, authGetUserMock } = vi.hoisted(() => ({
  cookiesMock: vi.fn(),
  isDemoModeMock: vi.fn(),
  createSupabaseServerClientMock: vi.fn(),
  authGetUserMock: vi.fn()
}));

vi.mock("next/headers", () => ({
  cookies: cookiesMock
}));

vi.mock("@/lib/config/runtime", () => ({
  isDemoMode: isDemoModeMock,
  runtimeConfig: {
    demoEmail: "owner@bvrb3r.demo"
  }
}));

vi.mock("@/lib/supabase/server", () => ({
  createSupabaseServerClient: createSupabaseServerClientMock
}));

import { getCurrentUserFromServer } from "@/lib/auth/session";

describe("server session resolution", () => {
  beforeEach(() => {
    cookiesMock.mockReset();
    isDemoModeMock.mockReset();
    createSupabaseServerClientMock.mockReset();
    authGetUserMock.mockReset();
  });

  it("uses the selected demo cookie in demo mode", async () => {
    isDemoModeMock.mockReturnValue(true);
    cookiesMock.mockResolvedValue({
      get: vi.fn(() => ({ value: "wave%40bvrb3r.demo" }))
    });

    const result = await getCurrentUserFromServer();

    expect(result.mode).toBe("demo");
    expect(result.user.email).toBe("wave@bvrb3r.demo");
  });

  it("uses the selected demo cookie as a fallback in supabase mode when no auth user exists", async () => {
    isDemoModeMock.mockReturnValue(false);
    cookiesMock.mockResolvedValue({
      get: vi.fn(() => ({ value: "manager%40bvrb3r.demo" }))
    });
    authGetUserMock.mockResolvedValue({ data: { user: null } });
    createSupabaseServerClientMock.mockResolvedValue({
      auth: {
        getUser: authGetUserMock
      }
    });

    const result = await getCurrentUserFromServer();

    expect(result.mode).toBe("supabase");
    expect(result.user.email).toBe("manager@bvrb3r.demo");
  });

  it("prefers the authenticated supabase user over the demo cookie", async () => {
    isDemoModeMock.mockReturnValue(false);
    cookiesMock.mockResolvedValue({
      get: vi.fn(() => ({ value: "owner%40bvrb3r.demo" }))
    });
    authGetUserMock.mockResolvedValue({ data: { user: { email: "client@bvrb3r.demo" } } });
    createSupabaseServerClientMock.mockResolvedValue({
      auth: {
        getUser: authGetUserMock
      }
    });

    const result = await getCurrentUserFromServer();

    expect(result.mode).toBe("supabase");
    expect(result.user.email).toBe("client@bvrb3r.demo");
  });
});