"use client";

import { useState } from "react";
import { ArrowUpRight, CircleDollarSign, Scissors, Star, WalletCards } from "lucide-react";
import { StatCard } from "@/components/dashboard/stat-card";
import { BarberEngagementPanel } from "@/components/engagement/barber-engagement-panel";
import { StatusBadge } from "@/components/dashboard/status-badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FeedbackBanner } from "@/components/ui/feedback-banner";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { boothRentLedger, demoBarbers, demoReviews, demoServices } from "@/lib/data/demo";
import { useAppointmentTransitionMutation, useCheckoutAppointmentMutation, useLiveOperationsSnapshot, type OperationsApiError } from "@/lib/operations/live-client";
import { getBarberCompensationSummary } from "@/lib/operations/metrics";
import type { CompensationSnapshotRecord } from "@/lib/operations/persistence";
import { useOperationsStore } from "@/lib/store/operations-store";
import { getReadableActionError } from "@/lib/utils/feedback";
import { currency, dateLabel } from "@/lib/utils";
import { getAppointmentViewModel, isAppointmentPaid, isReadyForCheckout } from "@/lib/utils/operations";

function buildCompensationHistory(rows: CompensationSnapshotRecord[]) {
  const grouped = new Map<string, { businessDate: string; gross: number; tips: number; commission: number; appointments: number }>();

  for (const row of rows) {
    const current = grouped.get(row.businessDate) ?? {
      businessDate: row.businessDate,
      gross: 0,
      tips: 0,
      commission: 0,
      appointments: 0
    };

    current.gross += row.grossServiceAmount;
    current.tips += row.tipAmount;
    current.commission += row.commissionAmount;
    current.appointments += 1;
    grouped.set(row.businessDate, current);
  }

  return [...grouped.values()].sort((left, right) => right.businessDate.localeCompare(left.businessDate)).slice(0, 3);
}

function MetricSkeleton() {
  return (
    <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
      <Skeleton className="h-3 w-24" />
      <Skeleton className="mt-4 h-10 w-20" />
      <Skeleton className="mt-4 h-4 w-32" />
    </div>
  );
}

function TimelineSkeleton() {
  return (
    <div className="rounded-[26px] border border-white/8 bg-black/20 p-4">
      <Skeleton className="h-6 w-40" />
      <Skeleton className="mt-3 h-4 w-52" />
      <Skeleton className="mt-4 h-4 w-40" />
      <div className="mt-4 flex gap-2">
        <Skeleton className="h-11 w-28 rounded-full" />
        <Skeleton className="h-11 w-32 rounded-full" />
      </div>
    </div>
  );
}

export function BarberWorkspace({ barberId }: { barberId: string }) {
  const operationsQuery = useLiveOperationsSnapshot("barber");
  const transitionMutation = useAppointmentTransitionMutation();
  const checkoutMutation = useCheckoutAppointmentMutation();
  const selectedAppointmentId = useOperationsStore((state) => state.selectedAppointmentId);
  const tipAmount = useOperationsStore((state) => state.tipAmount);
  const paymentMethod = useOperationsStore((state) => state.paymentMethod);
  const pendingAppointmentIds = useOperationsStore((state) => state.pendingAppointmentIds);
  const conflictMessage = useOperationsStore((state) => state.conflictMessage);
  const setSelectedAppointmentId = useOperationsStore((state) => state.setSelectedAppointmentId);
  const setTipAmount = useOperationsStore((state) => state.setTipAmount);
  const setPaymentMethod = useOperationsStore((state) => state.setPaymentMethod);
  const setPending = useOperationsStore((state) => state.setPending);
  const setConflict = useOperationsStore((state) => state.setConflict);
  const resetCheckoutPanel = useOperationsStore((state) => state.resetCheckoutPanel);
  const [statusUpdate, setStatusUpdate] = useState<{ tone: "success" | "info"; message: string } | null>(null);

  const barber = demoBarbers.find((entry) => entry.id === barberId) ?? demoBarbers[0];
  const appointments = [...(operationsQuery.data?.appointments ?? [])].sort((left, right) => new Date(left.start).getTime() - new Date(right.start).getTime());
  const clients = operationsQuery.data?.clients ?? [];
  const compensationSnapshots = (operationsQuery.data?.compensationSnapshots ?? []).filter((entry) => entry.barberReference === barber.id);
  const barberAppointments = appointments.filter((appointment) => appointment.barberId === barber.id);
  const metrics = getBarberCompensationSummary(barber.id, barberAppointments, compensationSnapshots);
  const modeLabel = operationsQuery.data?.mode === "supabase" ? "Supabase realtime active" : "Quick-start demo state";
  const isInitialLoading = operationsQuery.isLoading && !operationsQuery.data;
  const businessDateAppointments = barberAppointments.filter((appointment) => appointment.start.slice(0, 10) === metrics.businessDate);
  const timeline = businessDateAppointments.length ? businessDateAppointments : barberAppointments;
  const allowBarberCheckout = barber.compensationModel === "booth_rent";
  const checkoutTarget = allowBarberCheckout
    ? timeline.find((appointment) => appointment.id === selectedAppointmentId) ?? timeline.find(isReadyForCheckout)
    : undefined;
  const checkoutView = checkoutTarget ? getAppointmentViewModel(checkoutTarget, clients) : undefined;
  const payoutHistory = buildCompensationHistory(compensationSnapshots);
  const rentEntries = boothRentLedger.filter((entry) => entry.barberId === barber.id).sort((left, right) => right.dueDate.localeCompare(left.dueDate));
  const relatedClients = clients.filter((client) => timeline.some((appointment) => appointment.clientId === client.id));
  const reviewRows = demoReviews.filter((review) => review.barberId === barber.id);
  const averageTicket = compensationSnapshots.length
    ? compensationSnapshots.reduce((sum, entry) => sum + entry.grossServiceAmount + entry.tipAmount, 0) / compensationSnapshots.length
    : 0;
  const rebookingRate = relatedClients.length
    ? Math.round((relatedClients.filter((client) => client.favoriteBarberId === barber.id).length / relatedClients.length) * 100)
    : 0;
  const clientRetentionRate = relatedClients.length
    ? Math.round((relatedClients.filter((client) => client.retentionTag === "repeat" || client.retentionTag === "vip").length / relatedClients.length) * 100)
    : 0;
  const newClientCount = relatedClients.filter((client) => client.retentionTag === "new").length;
  const reviewScore = reviewRows.length
    ? (reviewRows.reduce((sum, review) => sum + review.rating, 0) / reviewRows.length).toFixed(1)
    : barber.rating.toFixed(1);
  const topServices = Object.entries(
    timeline.reduce<Record<string, number>>((accumulator, appointment) => {
      accumulator[appointment.serviceId] = (accumulator[appointment.serviceId] ?? 0) + 1;
      return accumulator;
    }, {})
  )
    .sort((left, right) => right[1] - left[1])
    .map(([serviceId, count]) => ({
      service: demoServices.find((entry) => entry.id === serviceId),
      count
    }))
    .filter((entry) => entry.service)
    .slice(0, 3);
  const serviceMenu = Array.from(new Set(timeline.map((appointment) => appointment.serviceId)))
    .map((serviceId) => demoServices.find((entry) => entry.id === serviceId))
    .filter((service): service is NonNullable<typeof service> => Boolean(service))
    .slice(0, 4);
  const nextAppointment = timeline.find((appointment) => ["booked", "checked_in", "in_service"].includes(appointment.status));
  const nextAppointmentView = nextAppointment ? getAppointmentViewModel(nextAppointment, clients) : undefined;

  async function handleTransition(appointmentId: string, expectedRevision: number, action: "service_start" | "service_complete") {
    setStatusUpdate(null);
    setConflict(undefined);
    setPending(appointmentId, true);
    try {
      await transitionMutation.mutateAsync({ appointmentId, expectedRevision, action });
      setStatusUpdate({
        tone: "success",
        message: action === "service_start"
          ? "Service started. Your chair is now marked in service."
          : "Service completed. The ticket is now ready for checkout."
      });
    } catch (error) {
      const apiError = error as OperationsApiError;
      setConflict(getReadableActionError(apiError), apiError.latestAppointment?.id ?? appointmentId);
    } finally {
      setPending(appointmentId, false);
    }
  }

  async function handleCheckout() {
    if (!checkoutTarget) {
      return;
    }

    setStatusUpdate(null);
    setConflict(undefined);
    setPending(checkoutTarget.id, true);
    try {
      await checkoutMutation.mutateAsync({
        appointmentId: checkoutTarget.id,
        expectedRevision: checkoutTarget.revision,
        tipAmount: Number(tipAmount) || 0,
        paymentMethod
      });
      resetCheckoutPanel();
      setStatusUpdate({ tone: "success", message: "Payment and tip captured. Your chair totals refreshed successfully." });
    } catch (error) {
      const apiError = error as OperationsApiError;
      setConflict(getReadableActionError(apiError), apiError.latestAppointment?.id ?? checkoutTarget.id);
      if (apiError.latestAppointment?.id) {
        setSelectedAppointmentId(apiError.latestAppointment.id);
      }
    } finally {
      setPending(checkoutTarget.id, false);
    }
  }

  return (
    <div className="space-y-4" data-testid="barber-workspace">
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {isInitialLoading ? (
          <>
            <MetricSkeleton />
            <MetricSkeleton />
            <MetricSkeleton />
            <MetricSkeleton />
          </>
        ) : (
          <>
            <StatCard label="Active chair tickets" value={String(metrics.activeCount)} detail={`${timeline.filter((appointment) => appointment.status === "booked").length} more appointments are on deck`} />
            <StatCard label="Service revenue today" value={currency(metrics.serviceRevenueToday)} detail={`${metrics.completedPaidCount} posted service${metrics.completedPaidCount === 1 ? "" : "s"} in this view`} />
            <StatCard label="Tip income today" value={currency(metrics.tipsToday)} detail={`${reviewScore} average review score attached to your chair`} />
            <StatCard label="Average ticket" value={currency(averageTicket)} detail={`${rebookingRate}% rebooking rate from your visible client history`} />
          </>
        )}
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="surface-label">Today at your chair</p>
              <h3 className="mt-3 text-4xl font-semibold sm:text-5xl" data-display="true">{nextAppointmentView ? nextAppointmentView.client?.name ?? nextAppointment?.clientId : "You are clear right now"}</h3>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-white/62">
                This workspace shows only your schedule, your clients, and your money. Nothing from the rest of the shop leaks into your chair view.
              </p>
            </div>
            <div className="rounded-[24px] border border-white/8 bg-black/20 p-4 text-sm text-white/68">
              <div className="inline-flex items-center gap-2 rounded-full border border-[#7CFF00]/20 bg-[#7CFF00]/10 px-3 py-2 text-[10px] uppercase tracking-[0.22em] text-[#d7ffab]">
                <Scissors className="h-4 w-4" />
                {modeLabel}
              </div>
              <p className="mt-4 text-[11px] uppercase tracking-[0.22em] text-white/42">{barber.availabilityLabel}</p>
            </div>
          </div>

          <div className="mt-5 space-y-3">
            {statusUpdate ? <FeedbackBanner tone={statusUpdate.tone} message={statusUpdate.message} /> : null}
            {conflictMessage ? <FeedbackBanner tone="error" message={conflictMessage} /> : null}
          </div>

          <div className="mt-5 rounded-[24px] border border-white/8 bg-black/20 p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="surface-label">Next appointment</p>
                <p className="mt-2 text-lg font-semibold">{nextAppointmentView ? `${nextAppointmentView.service?.name} with ${nextAppointmentView.client?.name ?? nextAppointment?.clientId}` : "No guest waiting on your chair right now"}</p>
              </div>
              <span className="status-pill text-[#d7ffab]">{barber.compensationModel === "commission" ? "Front desk checkout" : "Barber checkout enabled"}</span>
            </div>
            <p className="mt-3 text-sm text-white/58">
              {nextAppointment
                ? `${dateLabel(nextAppointment.start)} | ${nextAppointment.chair} | ${nextAppointment.note}`
                : "Your next booked guest will surface here automatically as the day fills in."}
            </p>
          </div>

          <div className="mt-5 space-y-3">
            {isInitialLoading ? (
              <><TimelineSkeleton /><TimelineSkeleton /><TimelineSkeleton /></>
            ) : timeline.length ? timeline.map((appointment) => {
              const view = getAppointmentViewModel(appointment, clients);
              const isPending = pendingAppointmentIds.includes(appointment.id);
              return (
                <div key={appointment.id} className="rounded-[26px] border border-white/8 bg-black/20 p-4 transition hover:-translate-y-0.5 hover:border-[#7CFF00]/16 hover:bg-black/30">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-lg font-semibold">{view.client?.name ?? appointment.clientId}</p>
                      <p className="mt-1 text-sm text-white/52">{view.service?.name} | {dateLabel(appointment.start)} | {appointment.chair}</p>
                    </div>
                    <StatusBadge appointment={appointment} />
                  </div>
                  <p className="mt-3 text-sm text-white/62">{appointment.note}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {appointment.status === "checked_in" ? (
                      <Button className="h-11 px-4" disabled={isPending} onClick={() => void handleTransition(appointment.id, appointment.revision, "service_start")}>
                        {isPending ? "Starting..." : "Start service"}
                      </Button>
                    ) : null}
                    {appointment.status === "in_service" ? (
                      <Button className="h-11 px-4" disabled={isPending} onClick={() => void handleTransition(appointment.id, appointment.revision, "service_complete")}>
                        {isPending ? "Completing..." : "Mark complete"}
                      </Button>
                    ) : null}
                    {appointment.status === "booked" ? <span className="status-pill text-white/62">Awaiting check-in</span> : null}
                    {isReadyForCheckout(appointment) && allowBarberCheckout ? (
                      <Button variant="secondary" className="h-11 px-4" onClick={() => setSelectedAppointmentId(appointment.id)}>Open self-checkout</Button>
                    ) : null}
                    {isReadyForCheckout(appointment) && !allowBarberCheckout ? <span className="status-pill text-amber-300">Send to front desk checkout</span> : null}
                    {isAppointmentPaid(appointment) ? <span className="status-pill text-[#d7ffab]">Paid</span> : null}
                  </div>
                </div>
              );
            }) : (
              <div className="empty-state-panel rounded-[26px] p-6 text-sm leading-7 text-white/58">
                No live appointments are assigned to your chair right now.
              </div>
            )}
          </div>
        </Card>

        <div className="grid gap-4">
          <Card className="rounded-[32px] p-6">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="surface-label">Personal money overview</p>
                <p className="mt-2 text-sm text-white/58">Financial visibility stays personal, simple, and tied directly to your work.</p>
              </div>
              <CircleDollarSign className="h-5 w-5 text-[#baff69]" />
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                <p className="surface-label">Today&apos;s service revenue</p>
                <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.serviceRevenueToday)}</p>
              </div>
              <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                <p className="surface-label">Today&apos;s tips</p>
                <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.tipsToday)}</p>
              </div>
              {barber.compensationModel === "commission" ? (
                <>
                  <div className="rounded-[24px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4">
                    <p className="surface-label text-[#d7ffab]">Commission earned</p>
                    <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.commissionToday)}</p>
                  </div>
                  <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                    <p className="surface-label">Pending payout</p>
                    <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(barber.upcomingPayout || metrics.projectedPayout)}</p>
                  </div>
                </>
              ) : (
                <>
                  <div className="rounded-[24px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4">
                    <p className="surface-label text-[#d7ffab]">Gross collected</p>
                    <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.serviceRevenueToday + metrics.tipsToday)}</p>
                  </div>
                  <div className="rounded-[24px] border border-white/8 bg-black/20 p-4">
                    <p className="surface-label">Booth rent status</p>
                    <p className="mt-3 text-3xl font-semibold" data-display="true">{currency(metrics.nextRent?.amount ?? 0)}</p>
                    <p className="mt-2 text-sm text-white/55">{metrics.nextRent?.status ?? "Paid up"}{metrics.nextRent?.dueDate ? ` | due ${metrics.nextRent.dueDate}` : ""}</p>
                  </div>
                </>
              )}
            </div>
            <div className="mt-4 rounded-[24px] border border-white/8 bg-black/20 p-4 text-sm leading-6 text-white/66">
              {barber.compensationModel === "commission"
                ? "Client payment lands in the shop, your split applies automatically, and your share moves into pending payout history."
                : "Client payment lands on your chair revenue, booth rent stays separate, and your ledger shows what is due and what is already covered."}
            </div>
            <div className="mt-4 space-y-3">
              {barber.compensationModel === "commission" ? payoutHistory.map((entry) => (
                <div key={entry.businessDate} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-3">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-medium">{entry.businessDate}</p>
                    <span className="status-pill text-[#d7ffab]">{entry.appointments} tickets</span>
                  </div>
                  <p className="mt-2 text-sm text-white/55">Gross {currency(entry.gross)} | Tips {currency(entry.tips)}</p>
                  <p className="mt-2 text-sm text-white/72">Commission posted {currency(entry.commission)}</p>
                </div>
              )) : rentEntries.slice(0, 3).map((entry) => (
                <div key={entry.id} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-3">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-medium">{entry.periodLabel}</p>
                    <span className="status-pill text-[#d7ffab]">{entry.status}</span>
                  </div>
                  <p className="mt-2 text-sm text-white/55">Rent {currency(entry.amount)}</p>
                  <p className="mt-2 text-sm text-white/72">Due {entry.dueDate}{entry.paidDate ? ` | paid ${entry.paidDate}` : ""}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card className="rounded-[32px] p-6">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="surface-label">Money movement</p>
                <p className="mt-2 text-sm text-white/58">A simple view of how your work turns into recorded earnings.</p>
              </div>
              <WalletCards className="h-5 w-5 text-[#baff69]" />
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-1">
              {(barber.compensationModel === "commission"
                ? [
                    "Client payment captured",
                    "Service completion recorded",
                    "Shop split applied",
                    "Barber share marked pending",
                    "Payout released"
                  ]
                : [
                    "Client payment captured",
                    "Revenue recorded to your chair",
                    "Booth rent ledger updated",
                    "Personal totals refreshed",
                    "History available for payout or bookkeeping"
                  ]).map((step, index) => (
                <div key={step} className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-3">
                  <p className="surface-label">Step {index + 1}</p>
                  <p className="mt-2 text-sm text-white/72">{step}</p>
                </div>
              ))}
            </div>
            <div className="mt-4 rounded-[24px] border border-white/8 bg-black/20 p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="surface-label">Checkout control</p>
                <ArrowUpRight className="h-4 w-4 text-[#d7ffab]" />
              </div>
              {allowBarberCheckout ? (
                <div className="mt-4 space-y-4">
                  {checkoutTarget && checkoutView ? (
                    <>
                      <div className="rounded-[22px] border border-[#7CFF00]/18 bg-[#7CFF00]/8 p-4">
                        <p className="font-medium">{checkoutView.client?.name ?? checkoutTarget.clientId}</p>
                        <p className="mt-1 text-sm text-white/55">{checkoutView.service?.name}</p>
                        <p className="mt-3 text-2xl font-semibold" data-display="true">{currency(checkoutTarget.balanceDue)}</p>
                        <p className="mt-2 text-sm text-white/68">Ready to collect from your chair</p>
                      </div>
                      <div>
                        <label className="mb-3 block surface-label">Tip amount</label>
                        <Input type="number" value={tipAmount} onChange={(event) => setTipAmount(event.target.value)} />
                      </div>
                      <div>
                        <label className="mb-3 block surface-label">Payment method</label>
                        <Select value={paymentMethod} onChange={(event) => setPaymentMethod(event.target.value as "card_on_file" | "tap_to_pay" | "manual")}>
                          <option value="tap_to_pay">Tap to pay</option>
                          <option value="card_on_file">Card on file</option>
                          <option value="manual">Manual entry</option>
                        </Select>
                      </div>
                      <Button className="h-12 w-full" disabled={pendingAppointmentIds.includes(checkoutTarget.id)} onClick={() => void handleCheckout()}>
                        {pendingAppointmentIds.includes(checkoutTarget.id) ? "Capturing..." : "Capture payment and tip"}
                      </Button>
                    </>
                  ) : (
                    <div className="empty-state-panel mt-4 rounded-[22px] p-5 text-sm leading-7 text-white/58">
                      Completed services waiting on payment will appear here when self-checkout is enabled for your chair.
                    </div>
                  )}
                </div>
              ) : (
                <div className="empty-state-panel mt-4 rounded-[22px] p-5 text-sm leading-7 text-white/58">
                  Front desk checkout is enabled for this chair. Complete the service here and the desk closes the ticket with payment and tip capture.
                </div>
              )}
            </div>
          </Card>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
        <Card className="rounded-[32px] p-6">
          <div className="flex items-start gap-4">
            <div className="flex h-20 w-20 items-center justify-center rounded-full border border-[#7CFF00]/18 bg-[#7CFF00]/10 text-2xl font-semibold text-[#d7ffab]">
              {barber.name.charAt(0)}
            </div>
            <div>
              <p className="surface-label">Barber profile</p>
              <p className="mt-2 text-2xl font-semibold">{barber.name}</p>
              <p className="mt-2 text-sm text-white/55">{barber.bio}</p>
              <p className="mt-3 inline-flex items-center rounded-full border border-white/10 bg-black/25 px-3 py-2 text-[11px] uppercase tracking-[0.22em] text-[#d7ffab]">{barber.bookingLink}</p>
            </div>
          </div>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Specialties</p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs uppercase tracking-[0.18em] text-white/72">
                {barber.specialties.map((specialty) => (
                  <span key={specialty} className="rounded-full border border-white/10 px-3 py-2">{specialty}</span>
                ))}
              </div>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Availability</p>
              <p className="mt-3 text-sm text-white/72">{barber.availabilityLabel}</p>
              <p className="mt-2 text-sm text-white/55">Upcoming appointments: {timeline.length}</p>
            </div>
          </div>
          <div className="mt-4 rounded-[22px] border border-white/8 bg-black/20 p-4">
            <p className="surface-label">Service menu</p>
            <div className="mt-3 space-y-2 text-sm text-white/72">
              {(serviceMenu.length ? serviceMenu : demoServices.slice(0, 3)).map((service) => (
                <div key={service.id} className="flex items-center justify-between gap-3 rounded-[18px] border border-white/8 bg-black/25 px-3 py-3">
                  <span>{service.name}</span>
                  <span className="status-pill text-[#d7ffab]">{currency(service.price)}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4 rounded-[22px] border border-dashed border-white/10 bg-black/15 p-4 text-sm text-white/58">
            Portfolio uploads, before-and-after media, and richer booking profile modules are scaffolded for the next product phase.
          </div>
        </Card>

        <Card className="rounded-[32px] p-6">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="surface-label">Personal performance only</p>
              <p className="mt-2 text-sm text-white/58">No team comparison noise. These are your numbers only.</p>
            </div>
            <Star className="h-5 w-5 text-[#baff69]" />
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Completed services</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{timeline.filter((appointment) => appointment.status === "completed").length}</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Client retention</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{clientRetentionRate}%</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">New clients</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{newClientCount}</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Review score</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{reviewScore}</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Rebooking rate</p>
              <p className="mt-3 text-3xl font-semibold" data-display="true">{rebookingRate}%</p>
            </div>
            <div className="rounded-[22px] border border-white/8 bg-black/20 p-4">
              <p className="surface-label">Top service</p>
              <p className="mt-3 text-lg font-semibold">{topServices[0]?.service?.name ?? "Building history"}</p>
            </div>
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            {topServices.length ? topServices.map((entry) => (
              <div key={entry.service?.id} className="rounded-[22px] border border-white/8 bg-black/20 p-4">
                <p className="font-medium">{entry.service?.name}</p>
                <p className="mt-2 text-sm text-white/55">{entry.count} visits in this view</p>
              </div>
            )) : (
              <div className="empty-state-panel rounded-[22px] p-5 text-sm text-white/55 md:col-span-3">
                Personal top services will populate as more appointments run through your chair.
              </div>
            )}
          </div>
        </Card>
      </section>

      <BarberEngagementPanel />
    </div>
  );
}
