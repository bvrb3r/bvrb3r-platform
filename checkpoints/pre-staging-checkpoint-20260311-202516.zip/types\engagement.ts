import type { BarberActivationSummary, OwnerMarketplaceActivationSummary } from "@/types/activation";
import type { Role } from "@/types/domain";
import type { BarberTrustWorkspaceSummary, OwnerTrustWorkspaceSummary } from "@/types/trust";

export type LoyaltyTier = "core" | "vip" | "elite";
export type LoyaltyTransactionReason =
  | "completed_booking"
  | "review"
  | "referral"
  | "reward_redemption"
  | "manual_adjustment";
export type ReferralStatus = "invited" | "completed" | "credited";
export type EngagementEventType =
  | "appointment_booked"
  | "appointment_rebooked"
  | "waitlist_joined"
  | "barber_followed"
  | "barber_reviewed"
  | "reward_redeemed"
  | "service_completed"
  | "review_received"
  | "payout_released"
  | "profile_updated"
  | "portfolio_updated"
  | "booking_accepted";
export type NotificationChannel = "in_app" | "sms" | "email" | "push";
export type NotificationStatus = "queued" | "scheduled" | "sent" | "placeholder";
export type RebookingRecommendationStatus = "suggested" | "queued" | "sent" | "accepted";
export type ReputationTier = "standard" | "trusted" | "elite";
export type RankingDimension = "most_booked" | "highest_rated" | "fastest_growing" | "style_leader";
export type GrowthRecommendationStatus = "open" | "in_progress" | "resolved";
export type EngagementNotificationType =
  | "rebooking_reminder"
  | "loyalty_milestone"
  | "new_follower"
  | "booking_alert"
  | "review_alert"
  | "payout_alert"
  | "instant_booking_alert"
  | "waitlist_opening"
  | "referral_reward"
  | "verification_update"
  | "trust_status_update"
  | "boost_update"
  | "featured_placement_update"
  | "barber_opportunity";

export interface LoyaltyAccountRecord {
  id: string;
  clientId: string;
  pointsBalance: number;
  lifetimePoints: number;
  tier: LoyaltyTier;
  referralCredits: number;
  updatedAt: string;
}

export interface LoyaltyTransactionRecord {
  id: string;
  clientId: string;
  reason: LoyaltyTransactionReason;
  pointsDelta: number;
  label: string;
  referenceId?: string;
  createdAt: string;
}

export interface ReferralCodeRecord {
  id: string;
  clientId: string;
  code: string;
  rewardPoints: number;
  active: boolean;
  createdAt: string;
}

export interface ReferralEventRecord {
  id: string;
  referralCodeId: string;
  referrerClientId: string;
  referredClientEmail: string;
  status: ReferralStatus;
  rewardPoints: number;
  createdAt: string;
  completedAt?: string;
}

export interface BarberFollowRecord {
  id: string;
  clientId: string;
  barberId: string;
  notifyOnAvailability: boolean;
  notifyOnPortfolio: boolean;
  createdAt: string;
}

export interface EngagementEventRecord {
  id: string;
  actorRole: Role;
  actorId: string;
  targetType: "client" | "barber" | "owner" | "location" | "referral" | "service";
  targetId: string;
  eventType: EngagementEventType;
  metadata: Record<string, string | number | boolean | null>;
  createdAt: string;
}

export interface RebookingCycleRecord {
  id: string;
  clientId: string;
  barberId?: string;
  serviceId?: string;
  averageCycleDays: number;
  confidence: "low" | "medium" | "high";
  lastCompletedAt: string;
  nextSuggestedAt: string;
}

export interface RebookingRecommendationRecord {
  id: string;
  clientId: string;
  barberId?: string;
  serviceId?: string;
  message: string;
  remindAt: string;
  status: RebookingRecommendationStatus;
  reason: string;
  createdAt: string;
}

export interface NotificationPreferenceRecord {
  id: string;
  userEmail: string;
  role: Role;
  clientId?: string;
  barberId?: string;
  inAppEnabled: boolean;
  smsEnabled: boolean;
  emailEnabled: boolean;
  pushEnabled: boolean;
  updatedAt: string;
}

export interface EngagementNotificationRecord {
  id: string;
  userEmail: string;
  role: Role;
  clientId?: string;
  barberId?: string;
  locationId?: string;
  channel: NotificationChannel;
  type: EngagementNotificationType;
  title: string;
  body: string;
  status: NotificationStatus;
  createdAt: string;
  scheduledFor?: string;
}

export interface ReputationScoreRecord {
  barberId: string;
  reviewScore: number;
  punctualityScore: number;
  completionScore: number;
  retentionScore: number;
  overallScore: number;
  tier: ReputationTier;
  updatedAt: string;
}

export interface RankingSnapshotRecord {
  id: string;
  barberId: string;
  dimension: RankingDimension;
  rankPosition: number;
  score: number;
  label: string;
  observedAt: string;
}

export interface GrowthRecommendationRecord {
  id: string;
  barberId: string;
  title: string;
  description: string;
  focusArea: "portfolio" | "availability" | "punctuality" | "rebooking" | "reviews";
  priority: "low" | "medium" | "high";
  status: GrowthRecommendationStatus;
  actionLabel: string;
  createdAt: string;
}

export interface ClientRewardOption {
  id: string;
  title: string;
  pointsRequired: number;
  unlocked: boolean;
}

export interface ClientBarberFollowState {
  barberId: string;
  isFollowing: boolean;
  notifyOnAvailability: boolean;
  notifyOnPortfolio: boolean;
  followerCount: number;
}

export interface ClientReferralSummary {
  clientId: string;
  referralCode?: ReferralCodeRecord;
  inviteLink: string;
  shareMessage: string;
  totals: {
    invited: number;
    completed: number;
    credited: number;
    rewardPointsEarned: number;
  };
  recentReferrals: ReferralEventRecord[];
}

export interface ClientEngagementSummary {
  clientId: string;
  pointsBalance: number;
  lifetimePoints: number;
  tier: LoyaltyTier;
  referralCredits: number;
  completedBookings: number;
  favoriteBarberName?: string;
  rebookingRecommendation: RebookingRecommendationRecord | null;
  followedBarbers: Array<{
    barberId: string;
    barberName: string;
    username?: string;
    nextAvailableAt?: string;
    notifyOnAvailability: boolean;
  }>;
  followSuggestions: Array<{
    barberId: string;
    barberName: string;
    username?: string;
    reason: string;
  }>;
  rewards: ClientRewardOption[];
  referralCode?: ReferralCodeRecord;
  recentTransactions: LoyaltyTransactionRecord[];
  recentNotifications: EngagementNotificationRecord[];
  recentEvents: EngagementEventRecord[];
}

export interface BarberEngagementSummary {
  barberId: string;
  followerCount: number;
  earnings: {
    today: number;
    week: number;
    month: number;
    averageTip: number;
  };
  socialProof: {
    rating: number;
    reviewCount: number;
    cutsCompleted: number;
    trendingBadge?: string;
  };
  clientInsights: {
    repeatClients: number;
    retentionRate: number;
    highestTipperName?: string;
    averageTip: number;
  };
  reputation: ReputationScoreRecord | null;
  rankings: RankingSnapshotRecord[];
  growthRecommendations: GrowthRecommendationRecord[];
  recentEvents: EngagementEventRecord[];
  marketplace: {
    profileViews: number;
    bookingClicks: number;
    bookingsCreated: number;
    bookingsCompleted: number;
    conversionRate: number;
    shareCount: number;
  };
  trust?: BarberTrustWorkspaceSummary;
  activation?: BarberActivationSummary;
}

export interface OwnerIntelligenceSummary {
  assignedLocationIds: string[];
  network: {
    revenue: number;
    chairUtilization: number;
    activeBarbers: number;
    completedServices: number;
  };
  retention: {
    repeatClientRate: number;
    loyaltyParticipants: number;
    loyaltyPointsIssued: number;
    referralConversions: number;
    rebookingEffectiveness: number;
  };
  bookingTrends: Array<{
    label: string;
    value: number;
  }>;
  topBarbers: Array<{
    barberId: string;
    barberName: string;
    followerCount: number;
    reputationScore: number;
    revenue: number;
  }>;
  recentNotifications: EngagementNotificationRecord[];
  marketplace: {
    discoveryImpressions: number;
    profileViews: number;
    bookingClicks: number;
    bookingsCreated: number;
    bookingsCompleted: number;
    followsCreated: number;
    haircutNowImpressions: number;
    shareCount: number;
    referralInvites: number;
    topSources: Array<{
      sourceKind: string;
      count: number;
    }>;
  };
  trust?: OwnerTrustWorkspaceSummary;
  activation?: OwnerMarketplaceActivationSummary;
}

export interface EngagementState {
  loyaltyAccounts: LoyaltyAccountRecord[];
  loyaltyTransactions: LoyaltyTransactionRecord[];
  referralCodes: ReferralCodeRecord[];
  referralEvents: ReferralEventRecord[];
  barberFollows: BarberFollowRecord[];
  engagementEvents: EngagementEventRecord[];
  rebookingCycles: RebookingCycleRecord[];
  rebookingRecommendations: RebookingRecommendationRecord[];
  notificationPreferences: NotificationPreferenceRecord[];
  notifications: EngagementNotificationRecord[];
  reputationScores: ReputationScoreRecord[];
  rankingSnapshots: RankingSnapshotRecord[];
  growthRecommendations: GrowthRecommendationRecord[];
}
